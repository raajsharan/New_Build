import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ConfigProvider } from './context/ConfigContext';
import { BrandingProvider } from './context/BrandingContext';
import Layout from './components/Layout';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import DashboardPage from './pages/DashboardPage';
import AssetListCombinedPage from './pages/AssetListCombinedPage';
import ExtAssetListCombinedPage from './pages/ExtAssetListCombinedPage';
import ConfigurationPage from './pages/ConfigurationPage';
import UsersPage from './pages/UsersPage';
import PasswordControlPage from './pages/PasswordControlPage';
import BrandingPage from './pages/BrandingPage';
import CustomFieldsPage from './pages/CustomFieldsPage';
import ProfilePage from './pages/ProfilePage';
import PhysicalAssetPage from './pages/PhysicalAssetPage';
import PhysicalServerListPage from './pages/PhysicalServerListPage';
import PhysicalAssetCustomFieldsPage from './pages/PhysicalAssetCustomFieldsPage';
import ExtendedCustomFieldsPage from './pages/ExtendedCustomFieldsPage';
import TransferToInventoryPage from './pages/TransferToInventoryPage';
import DeptRangeManagementPage from './pages/DeptRangeManagementPage';
import DashboardIconsPage from './pages/DashboardIconsPage';
import CopyrightPage from './pages/CopyrightPage';
import BackupPage from './pages/BackupPage';
import AssetDetailPage from './pages/AssetDetailPage';
import ExtAssetDetailPage from './pages/ExtAssetDetailPage';
import EmailNotificationsPage from './pages/EmailNotificationsPage';
import ColumnConfigPage from './pages/ColumnConfigPage';

function Guard({ children, pageKey, adminOnly }) {
  const { user, loading, canViewPage, isAdmin } = useAuth();
  if (loading) return <div className="min-h-screen flex items-center justify-center text-gray-400 text-sm animate-pulse">Loading…</div>;
  if (!user) return <Navigate to="/login" replace />;
  if (adminOnly && !isAdmin) return <Blocked msg="Admin access required" />;
  if (pageKey && !canViewPage(pageKey)) return <Blocked msg="You don't have permission to view this page." />;
  return children;
}

function Blocked({ msg }) {
  return (
    <div className="flex flex-col items-center justify-center min-h-[400px] gap-3">
      <div className="text-5xl">🔒</div>
      <p className="text-lg font-semibold text-gray-700">Access Restricted</p>
      <p className="text-sm text-gray-500">{msg}</p>
    </div>
  );
}

function AppRoutes() {
  const { user, loading } = useAuth();
  if (loading) return <div className="min-h-screen flex items-center justify-center bg-gray-50 text-gray-400 animate-pulse">Starting…</div>;
  return (
    <Routes>
      <Route path="/login"    element={!user ? <LoginPage />    : <Navigate to="/dashboard" replace />} />
      <Route path="/register" element={!user ? <RegisterPage /> : <Navigate to="/dashboard" replace />} />
      <Route path="/copyright" element={<CopyrightPage />} />
      <Route path="/" element={<Guard><Layout /></Guard>}>
        <Route index element={<Navigate to="/dashboard" replace />} />
        <Route path="dashboard"        element={<Guard pageKey="dashboard"><DashboardPage /></Guard>} />
        {/* Combined pages */}
        <Route path="asset-list"       element={<Guard pageKey="asset-list"><AssetListCombinedPage /></Guard>} />
        <Route path="ext-asset-list"   element={<Guard pageKey="extended-inventory"><ExtAssetListCombinedPage /></Guard>} />
        {/* Legacy routes — redirect to combined pages */}
        <Route path="add-asset"              element={<Navigate to="/asset-list?tab=add" replace />} />
        <Route path="add-extended-inventory" element={<Navigate to="/ext-asset-list?tab=add" replace />} />
        <Route path="extended-inventory"     element={<Navigate to="/ext-asset-list?tab=list" replace />} />
        {/* Physical assets */}
        <Route path="physical-assets"       element={<Guard pageKey="physical-assets"><PhysicalAssetPage /></Guard>} />
        <Route path="physical-server-list"  element={<Guard pageKey="physical-assets"><PhysicalServerListPage /></Guard>} />
        {/* Settings */}
        <Route path="configuration"    element={<Guard pageKey="configuration"><ConfigurationPage /></Guard>} />
        <Route path="profile"          element={<Guard><ProfilePage /></Guard>} />
        {/* Admin */}
        <Route path="users"            element={<Guard adminOnly><UsersPage /></Guard>} />
        <Route path="password-control" element={<Guard adminOnly><PasswordControlPage /></Guard>} />
        <Route path="branding"         element={<Guard adminOnly><BrandingPage /></Guard>} />
        <Route path="custom-fields"    element={<Guard adminOnly><CustomFieldsPage /></Guard>} />
        <Route path="physical-asset-custom-fields" element={<Guard adminOnly><PhysicalAssetCustomFieldsPage /></Guard>} />
        <Route path="extended-custom-fields"       element={<Guard adminOnly><ExtendedCustomFieldsPage /></Guard>} />
        <Route path="transfer-to-inventory"        element={<Guard adminOnly><TransferToInventoryPage /></Guard>} />
        <Route path="dept-range-management"         element={<Guard adminOnly><DeptRangeManagementPage /></Guard>} />
        <Route path="dashboard-icons"               element={<Guard adminOnly><DashboardIconsPage /></Guard>} />
        <Route path="backup"                         element={<Guard adminOnly><BackupPage /></Guard>} />
        <Route path="email-notifications"            element={<Guard adminOnly><EmailNotificationsPage /></Guard>} />
        <Route path="column-config"                    element={<Guard adminOnly><ColumnConfigPage /></Guard>} />
        <Route path="assets/:id"                     element={<Guard pageKey="asset-list"><AssetDetailPage /></Guard>} />
        <Route path="ext-assets/:id"                 element={<Guard pageKey="extended-inventory"><ExtAssetDetailPage /></Guard>} />
      </Route>
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrandingProvider>
        <ConfigProvider>
          <BrowserRouter>
            <Toaster position="top-right" toastOptions={{ duration: 4000, style: { fontSize: '13px' } }} />
            <AppRoutes />
          </BrowserRouter>
        </ConfigProvider>
      </BrandingProvider>
    </AuthProvider>
  );
}
