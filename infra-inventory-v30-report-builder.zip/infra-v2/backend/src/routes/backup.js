/**
 * /api/backup — Backup management (PostgreSQL dump + CSV schedule)
 */
const router  = require('express').Router();
const pool    = require('../config/database');
const { auth, requireAdmin } = require('../middleware/auth');
const { exec } = require('child_process');
const path    = require('path');
const fs      = require('fs');
const os      = require('os');

// ── Backup log table (in-memory for session, persisted to app_settings) ──────
async function getBackupLog() {
  try {
    const r = await pool.query("SELECT setting_value FROM app_settings WHERE setting_key='backup_log'");
    if (r.rows.length) return JSON.parse(r.rows[0].setting_value || '[]');
  } catch {}
  return [];
}
async function appendBackupLog(entry) {
  try {
    const log = await getBackupLog();
    log.unshift(entry); // newest first
    const trimmed = log.slice(0, 50); // keep last 50
    await pool.query(
      `INSERT INTO app_settings (setting_key, setting_value) VALUES ('backup_log', $1)
       ON CONFLICT (setting_key) DO UPDATE SET setting_value=$1, updated_at=NOW()`,
      [JSON.stringify(trimmed)]
    );
  } catch {}
}

// ── GET /api/backup/schedule — get current schedule settings ─────────────────
router.get('/schedule', auth, requireAdmin, async (req, res) => {
  try {
    const r = await pool.query("SELECT setting_value FROM app_settings WHERE setting_key='backup_schedule'");
    const defaults = {
      pg_enabled: false, pg_frequency: 'daily', pg_time: '02:00', pg_retain_days: 7,
      csv_enabled: false, csv_frequency: 'daily', csv_time: '03:00',
      csv_include_assets: true, csv_include_ext: true,
    };
    const saved = r.rows.length ? JSON.parse(r.rows[0].setting_value || '{}') : {};
    res.json({ ...defaults, ...saved });
  } catch { res.status(500).json({ error: 'Server error' }); }
});

// ── PUT /api/backup/schedule — save schedule settings ────────────────────────
router.put('/schedule', auth, requireAdmin, async (req, res) => {
  try {
    await pool.query(
      `INSERT INTO app_settings (setting_key, setting_value) VALUES ('backup_schedule', $1)
       ON CONFLICT (setting_key) DO UPDATE SET setting_value=$1, updated_at=NOW()`,
      [JSON.stringify(req.body)]
    );
    res.json({ message: 'Schedule saved' });
  } catch { res.status(500).json({ error: 'Server error' }); }
});

// ── GET /api/backup/log — backup history ─────────────────────────────────────
router.get('/log', auth, requireAdmin, async (req, res) => {
  try { res.json(await getBackupLog()); }
  catch { res.json([]); }
});

// ── POST /api/backup/pg-dump — trigger a manual PostgreSQL dump ───────────────
router.post('/pg-dump', auth, requireAdmin, async (req, res) => {
  const dbConfig = {
    host:     process.env.DB_HOST     || 'localhost',
    port:     process.env.DB_PORT     || '5432',
    database: process.env.DB_NAME     || 'infrastructure_inventory',
    user:     process.env.DB_USER     || 'infra_admin',
    password: process.env.DB_PASSWORD || '',
  };

  const timestamp  = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const filename   = `infra_backup_${timestamp}.sql`;
  const tmpPath    = path.join(os.tmpdir(), filename);

  const env = { ...process.env, PGPASSWORD: dbConfig.password };
  const cmd = `pg_dump -h ${dbConfig.host} -p ${dbConfig.port} -U ${dbConfig.user} -d ${dbConfig.database} -F p --no-password`;

  exec(cmd, { env, maxBuffer: 100 * 1024 * 1024 }, async (err, stdout, stderr) => {
    if (err) {
      const entry = { type: 'pg_dump', status: 'error', filename, timestamp: new Date().toISOString(), error: stderr || err.message };
      await appendBackupLog(entry);
      return res.status(500).json({ error: 'pg_dump failed: ' + (stderr || err.message) });
    }
    fs.writeFileSync(tmpPath, stdout);
    const sizeMB = (Buffer.byteLength(stdout, 'utf8') / 1024 / 1024).toFixed(2);
    const entry = { type: 'pg_dump', status: 'success', filename, size_mb: sizeMB, timestamp: new Date().toISOString(), triggered_by: req.user?.username };
    await appendBackupLog(entry);

    res.setHeader('Content-Type', 'application/octet-stream');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('X-Backup-Size', sizeMB + ' MB');
    res.send(stdout);

    // Cleanup temp file
    try { fs.unlinkSync(tmpPath); } catch {}
  });
});

// ── POST /api/backup/csv-export — export both asset and ext inventory CSV ─────
router.post('/csv-export', auth, requireAdmin, async (req, res) => {
  const { include_assets = true, include_ext = true } = req.body;
  try {
    const results = {};

    if (include_assets) {
      const r = await pool.query(`
        SELECT a.id, a.vm_name, a.os_hostname, a.ip_address,
          at.name AS asset_type, ot.name AS os_type, ov.name AS os_version,
          a.assigned_user, d.name AS department, a.business_purpose,
          ss.name AS server_status, pt.name AS patching_type,
          ps.name AS patching_schedule, spt.name AS server_patch_type,
          l.name AS location, a.serial_number, a.eol_status, a.asset_tag,
          a.hosted_ip, a.asset_username, a.additional_remarks,
          a.me_installed_status, a.tenable_installed_status, a.oem_status,
          a.submitted_by, a.created_at, a.updated_at
        FROM assets a
        LEFT JOIN asset_types at    ON a.asset_type_id    = at.id
        LEFT JOIN os_types ot       ON a.os_type_id       = ot.id
        LEFT JOIN os_versions ov    ON a.os_version_id    = ov.id
        LEFT JOIN departments d     ON a.department_id    = d.id
        LEFT JOIN server_status ss  ON a.server_status_id = ss.id
        LEFT JOIN patching_types pt ON a.patching_type_id = pt.id
        LEFT JOIN patching_schedules ps ON a.patching_schedule_id = ps.id
        LEFT JOIN server_patch_types spt ON a.server_patch_type_id = spt.id
        LEFT JOIN locations l       ON a.location_id      = l.id
        ORDER BY a.created_at DESC`);
      results.assets = r.rows;
    }

    if (include_ext) {
      const extPool = require('../config/database').extPool;
      const r = await extPool.query(`
        SELECT i.id, i.vm_name, i.asset_name, i.os_hostname, i.ip_address,
          i.asset_type, i.assigned_user, i.business_purpose,
          i.status, i.additional_remarks,
          i.me_installed_status, i.tenable_installed_status,
          i.serial_number, i.asset_tag, i.hosted_ip, i.eol_status,
          i.asset_username, i.submitted_by, i.created_at, i.updated_at,
          d.name AS department, l.name AS location
        FROM items i
        LEFT JOIN public.departments d ON i.department_id = d.id
        LEFT JOIN public.locations   l ON i.location_id   = l.id
        ORDER BY i.created_at DESC`);
      results.ext = r.rows;
    }

    const esc = v => {
      if (v === null || v === undefined || v === false) return '';
      if (v === true) return 'Yes';
      const s = String(v).replace(/"/g, '""');
      return s.includes(',') || s.includes('"') || s.includes('\n') ? `"${s}"` : s;
    };

    const toCSV = (rows) => {
      if (!rows?.length) return '';
      const headers = Object.keys(rows[0]);
      return [headers.join(','), ...rows.map(r => headers.map(h => esc(r[h])).join(','))].join('\n');
    };

    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const csvSections = [];
    if (results.assets) csvSections.push({ name: `asset_inventory_${timestamp}.csv`, csv: toCSV(results.assets), count: results.assets.length });
    if (results.ext)    csvSections.push({ name: `ext_inventory_${timestamp}.csv`,   csv: toCSV(results.ext),    count: results.ext.length });

    const entry = {
      type: 'csv_export', status: 'success', timestamp: new Date().toISOString(),
      triggered_by: req.user?.username,
      details: csvSections.map(s => `${s.name} (${s.count} rows)`).join(', '),
    };
    await appendBackupLog(entry);

    res.json({ files: csvSections });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'CSV export failed: ' + e.message });
  }
});

module.exports = router;
