const router = require('express').Router();
const pool    = require('../config/database');
const extPool = require('../config/database').extPool;
const { auth } = require('../middleware/auth');

// GET /api/dashboard/stats — main stats + all 3 dashboard views
router.get('/stats', auth, async (req, res) => {
  try {
    // ── Main summary stats ──
    const summary = await pool.query(`
      SELECT
        COUNT(*)                                                   AS total_assets,
        COUNT(*) FILTER (WHERE at.name='VM')                      AS vm_count,
        COUNT(*) FILTER (WHERE at.name='Physical Server')         AS physical_server_count,
        COUNT(*) FILTER (WHERE a.me_installed_status=TRUE)        AS me_installed_count,
        COUNT(*) FILTER (WHERE a.tenable_installed_status=TRUE)   AS tenable_installed_count,
        COUNT(*) FILTER (WHERE pt.name='Auto')                    AS auto_patch_count,
        COUNT(*) FILTER (WHERE pt.name='Manual')                  AS manual_patch_count,
        COUNT(*) FILTER (WHERE pt.name='Exception')               AS exception_count,
        COUNT(*) FILTER (WHERE pt.name='Beijing IT Team')         AS beijing_count,
        COUNT(*) FILTER (WHERE pt.name='EOL - No Patches')        AS eol_no_patch_count,
        COUNT(*) FILTER (WHERE pt.name='Onboard Pending')         AS onboard_pending_count,
        COUNT(*) FILTER (WHERE pt.name='On Hold')                 AS on_hold_count,
        COUNT(*) FILTER (WHERE ss.name='Alive')                   AS alive_servers,
        COUNT(*) FILTER (WHERE ss.name='Powered Off')             AS powered_off_servers,
        COUNT(*) FILTER (WHERE ss.name='Not Alive')               AS not_alive_servers
      FROM assets a
      LEFT JOIN asset_types at    ON a.asset_type_id    = at.id
      LEFT JOIN patching_types pt ON a.patching_type_id = pt.id
      LEFT JOIN server_status ss  ON a.server_status_id = ss.id
    `);

    // ── Location distribution ──
    const locationDist = await pool.query(`
      SELECT l.name AS location, COUNT(*) AS count
      FROM assets a LEFT JOIN locations l ON a.location_id=l.id
      WHERE l.name IS NOT NULL
      GROUP BY l.name ORDER BY count DESC
    `);

    // ── Dashboard 1: Department-wise breakdown ──
    const deptStats = await pool.query(`
      SELECT
        COALESCE(d.name,'Unassigned') AS department,
        COUNT(*)                                                 AS total,
        COUNT(*) FILTER (WHERE pt.name='Auto')                  AS auto_count,
        COUNT(*) FILTER (WHERE pt.name='Manual')                AS manual_count,
        COUNT(*) FILTER (WHERE pt.name='Exception')             AS exception_count,
        COUNT(*) FILTER (WHERE pt.name='Beijing IT Team')       AS beijing_count,
        COUNT(*) FILTER (WHERE pt.name='EOL - No Patches')      AS eol_count,
        COUNT(*) FILTER (WHERE pt.name='Onboard Pending')       AS onboard_pending_count,
        COUNT(*) FILTER (WHERE pt.name='On Hold')               AS on_hold_count
      FROM assets a
      LEFT JOIN departments d     ON a.department_id    = d.id
      LEFT JOIN patching_types pt ON a.patching_type_id = pt.id
      GROUP BY COALESCE(d.name,'Unassigned')
      ORDER BY total DESC
    `);

    // ── Dashboard 2: Auto Patching Compliance % ──
    const compliance = await pool.query(`
      SELECT
        COUNT(*) FILTER (WHERE ss.name='Alive')                                   AS total_alive,
        COUNT(*) FILTER (WHERE pt.name='Auto'           AND ss.name='Alive')      AS auto_alive,
        COUNT(*) FILTER (WHERE pt.name='Manual'         AND ss.name='Alive')      AS manual_alive,
        COUNT(*) FILTER (WHERE pt.name='EOL - No Patches')                        AS eol_count,
        COUNT(*) FILTER (WHERE pt.name='Exception')                               AS exception_count,
        COUNT(*) FILTER (WHERE pt.name='Beijing IT Team')                         AS beijing_count,
        COUNT(*) FILTER (WHERE pt.name='Onboard Pending')                         AS onboard_pending_count,
        COUNT(*) FILTER (WHERE pt.name='On Hold')                                 AS on_hold_count,
        COUNT(*)                                                                   AS grand_total
      FROM assets a
      LEFT JOIN patching_types pt ON a.patching_type_id = pt.id
      LEFT JOIN server_status  ss ON a.server_status_id = ss.id
    `);

    // ── Dashboard 3: Location-wise patching breakdown ──
    const allLocations = await pool.query('SELECT name FROM locations ORDER BY name');
    const locationStats = await pool.query(`
      SELECT
        COALESCE(l.name,'Unassigned') AS location,
        COUNT(*)                                                 AS total,
        COUNT(*) FILTER (WHERE at.name='VM')                    AS vm_count,
        COUNT(*) FILTER (WHERE at.name='Physical Server')       AS physical_count,
        COUNT(*) FILTER (WHERE pt.name='Auto')                  AS auto_count,
        COUNT(*) FILTER (WHERE pt.name='Manual')                AS manual_count,
        COUNT(*) FILTER (WHERE pt.name='Beijing IT Team')       AS beijing_count,
        COUNT(*) FILTER (WHERE pt.name='Onboard Pending')       AS onboard_pending_count,
        COUNT(*) FILTER (WHERE pt.name='Exception')             AS exception_count,
        COUNT(*) FILTER (WHERE pt.name='EOL - No Patches')      AS eol_count,
        COUNT(*) FILTER (WHERE pt.name='On Hold')               AS on_hold_count,
        COUNT(*) FILTER (WHERE ss.name='Alive')                 AS alive_count
      FROM assets a
      LEFT JOIN locations      l  ON a.location_id      = l.id
      LEFT JOIN patching_types pt ON a.patching_type_id = pt.id
      LEFT JOIN asset_types    at ON a.asset_type_id    = at.id
      LEFT JOIN server_status  ss ON a.server_status_id = ss.id
      GROUP BY COALESCE(l.name,'Unassigned')
      ORDER BY total DESC
    `);

    const locMap = {};
    locationStats.rows.forEach(r => { locMap[r.location] = r; });
    const zeroRow = (name) => ({
      location: name, total: '0', vm_count: '0', physical_count: '0',
      auto_count: '0', manual_count: '0', beijing_count: '0',
      onboard_pending_count: '0', exception_count: '0', eol_count: '0',
      on_hold_count: '0', alive_count: '0'
    });
    const fullLocationStats = allLocations.rows.map(l => locMap[l.name] || zeroRow(l.name));

    const c = compliance.rows[0];
    const totalAlive   = parseInt(c.total_alive)  || 0;
    const autoAlive    = parseInt(c.auto_alive)   || 0;
    const manualAlive  = parseInt(c.manual_alive) || 0;
    const compliancePct = totalAlive > 0 ? Math.round(((autoAlive + manualAlive) / totalAlive) * 100) : 0;

    // ── Extended Inventory stats ──
    let extStats = { total: 0, active: 0, inactive: 0, decommissioned: 0, maintenance: 0, me_count: 0, tenable_count: 0 };
    let extDeptStats = [], extLocationStats = [], extCompliance = { compliance_pct: 0, total_alive: 0, auto_alive: 0, manual_alive: 0, grand_total: 0 };
    try {
      const [extSummary, extDept, extLoc, extComp] = await Promise.all([
        extPool.query(`
          SELECT
            COUNT(*)                                                   AS total,
            COUNT(*) FILTER (WHERE status='Active')                    AS active,
            COUNT(*) FILTER (WHERE status='Inactive')                  AS inactive,
            COUNT(*) FILTER (WHERE status='Decommissioned')            AS decommissioned,
            COUNT(*) FILTER (WHERE status='Maintenance')               AS maintenance,
            COUNT(*) FILTER (WHERE me_installed_status=TRUE)           AS me_count,
            COUNT(*) FILTER (WHERE tenable_installed_status=TRUE)      AS tenable_count
          FROM items`),
        extPool.query(`
          SELECT
            COALESCE(d.name,'Unassigned') AS department,
            COUNT(*)                                                   AS total,
            COUNT(*) FILTER (WHERE i.status='Active')                  AS active_count,
            COUNT(*) FILTER (WHERE i.status='Inactive')                AS inactive_count,
            COUNT(*) FILTER (WHERE i.me_installed_status=TRUE)         AS me_count,
            COUNT(*) FILTER (WHERE i.tenable_installed_status=TRUE)    AS tenable_count
          FROM items i
          LEFT JOIN public.departments d ON i.department_id = d.id
          GROUP BY COALESCE(d.name,'Unassigned')
          ORDER BY total DESC`),
        extPool.query(`
          SELECT
            COALESCE(l.name,'Unassigned') AS location,
            COUNT(*)                                                   AS total,
            COUNT(*) FILTER (WHERE i.status='Active')                  AS active_count,
            COUNT(*) FILTER (WHERE i.status='Inactive')                AS inactive_count,
            COUNT(*) FILTER (WHERE i.me_installed_status=TRUE)         AS me_count,
            COUNT(*) FILTER (WHERE i.tenable_installed_status=TRUE)    AS tenable_count
          FROM items i
          LEFT JOIN public.locations l ON i.location_id = l.id
          GROUP BY COALESCE(l.name,'Unassigned')
          ORDER BY total DESC`),
        extPool.query(`
          SELECT
            COUNT(*) FILTER (WHERE ss.name='Alive')                    AS total_alive,
            COUNT(*) FILTER (WHERE i.patching_type_id IS NOT NULL AND ss.name='Alive') AS auto_alive,
            COUNT(*)                                                    AS grand_total
          FROM items i
          LEFT JOIN public.server_status ss ON i.server_status_id = ss.id`),
      ]);
      extStats = extSummary.rows[0];
      extDeptStats = extDept.rows;
      extLocationStats = extLoc.rows;
      const ec = extComp.rows[0];
      const etAlive = parseInt(ec.total_alive) || 0;
      const eaAlive = parseInt(ec.auto_alive)  || 0;
      extCompliance = { ...ec, compliance_pct: etAlive > 0 ? Math.round((eaAlive / etAlive) * 100) : 0 };
    } catch (e) { console.warn('Extended inventory stats failed:', e.message); }

    res.json({
      ...summary.rows[0],
      location_distribution: locationDist.rows,
      dept_stats: deptStats.rows,
      compliance: { ...c, compliance_pct: compliancePct },
      location_stats: fullLocationStats,
      ext_stats:          extStats,
      ext_dept_stats:     extDeptStats,
      ext_location_stats: extLocationStats,
      ext_compliance:     extCompliance,
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;


// GET /api/dashboard/stats — main stats + all 3 dashboard views
router.get('/stats', auth, async (req, res) => {
  try {
    // ── Main summary stats ──
    const summary = await pool.query(`
      SELECT
        COUNT(*)                                                   AS total_assets,
        COUNT(*) FILTER (WHERE at.name='VM')                      AS vm_count,
        COUNT(*) FILTER (WHERE at.name='Physical Server')         AS physical_server_count,
        COUNT(*) FILTER (WHERE a.me_installed_status=TRUE)        AS me_installed_count,
        COUNT(*) FILTER (WHERE a.tenable_installed_status=TRUE)   AS tenable_installed_count,
        COUNT(*) FILTER (WHERE pt.name='Auto')                    AS auto_patch_count,
        COUNT(*) FILTER (WHERE pt.name='Manual')                  AS manual_patch_count,
        COUNT(*) FILTER (WHERE pt.name='Exception')               AS exception_count,
        COUNT(*) FILTER (WHERE pt.name='Beijing IT Team')         AS beijing_count,
        COUNT(*) FILTER (WHERE pt.name='EOL - No Patches')        AS eol_no_patch_count,
        COUNT(*) FILTER (WHERE pt.name='Onboard Pending')         AS onboard_pending_count,
        COUNT(*) FILTER (WHERE pt.name='On Hold')                 AS on_hold_count,
        COUNT(*) FILTER (WHERE ss.name='Alive')                   AS alive_servers,
        COUNT(*) FILTER (WHERE ss.name='Powered Off')             AS powered_off_servers,
        COUNT(*) FILTER (WHERE ss.name='Not Alive')               AS not_alive_servers
      FROM assets a
      LEFT JOIN asset_types at    ON a.asset_type_id    = at.id
      LEFT JOIN patching_types pt ON a.patching_type_id = pt.id
      LEFT JOIN server_status ss  ON a.server_status_id = ss.id
    `);

    // ── Location distribution (original) ──
    const locationDist = await pool.query(`
      SELECT l.name AS location, COUNT(*) AS count
      FROM assets a LEFT JOIN locations l ON a.location_id=l.id
      WHERE l.name IS NOT NULL
      GROUP BY l.name ORDER BY count DESC
    `);

    // ── Dashboard 1: Department-wise breakdown ──
    const deptStats = await pool.query(`
      SELECT
        COALESCE(d.name,'Unassigned') AS department,
        COUNT(*)                                                 AS total,
        COUNT(*) FILTER (WHERE pt.name='Auto')                  AS auto_count,
        COUNT(*) FILTER (WHERE pt.name='Manual')                AS manual_count,
        COUNT(*) FILTER (WHERE pt.name='Exception')             AS exception_count,
        COUNT(*) FILTER (WHERE pt.name='Beijing IT Team')       AS beijing_count,
        COUNT(*) FILTER (WHERE pt.name='EOL - No Patches')      AS eol_count,
        COUNT(*) FILTER (WHERE pt.name='Onboard Pending')       AS onboard_pending_count,
        COUNT(*) FILTER (WHERE pt.name='On Hold')               AS on_hold_count
      FROM assets a
      LEFT JOIN departments d     ON a.department_id    = d.id
      LEFT JOIN patching_types pt ON a.patching_type_id = pt.id
      GROUP BY COALESCE(d.name,'Unassigned')
      ORDER BY total DESC
    `);

    // ── Dashboard 2: Auto Patching Compliance % ──
    // Compliance = (Auto + Manual) / Total Alive * 100
    const compliance = await pool.query(`
      SELECT
        COUNT(*) FILTER (WHERE ss.name='Alive')                                   AS total_alive,
        COUNT(*) FILTER (WHERE pt.name='Auto'           AND ss.name='Alive')      AS auto_alive,
        COUNT(*) FILTER (WHERE pt.name='Manual'         AND ss.name='Alive')      AS manual_alive,
        COUNT(*) FILTER (WHERE pt.name='EOL - No Patches')                        AS eol_count,
        COUNT(*) FILTER (WHERE pt.name='Exception')                               AS exception_count,
        COUNT(*) FILTER (WHERE pt.name='Beijing IT Team')                         AS beijing_count,
        COUNT(*) FILTER (WHERE pt.name='Onboard Pending')                         AS onboard_pending_count,
        COUNT(*) FILTER (WHERE pt.name='On Hold')                                 AS on_hold_count,
        COUNT(*)                                                                   AS grand_total
      FROM assets a
      LEFT JOIN patching_types pt ON a.patching_type_id = pt.id
      LEFT JOIN server_status  ss ON a.server_status_id = ss.id
    `);

    // ── Dashboard 3: Location-wise patching breakdown ──
    // Get all locations first so we can show zeros
    const allLocations = await pool.query('SELECT name FROM locations ORDER BY name');
    const locationStats = await pool.query(`
      SELECT
        COALESCE(l.name,'Unassigned') AS location,
        COUNT(*)                                                 AS total,
        COUNT(*) FILTER (WHERE at.name='VM')                    AS vm_count,
        COUNT(*) FILTER (WHERE at.name='Physical Server')       AS physical_count,
        COUNT(*) FILTER (WHERE pt.name='Auto')                  AS auto_count,
        COUNT(*) FILTER (WHERE pt.name='Manual')                AS manual_count,
        COUNT(*) FILTER (WHERE pt.name='Beijing IT Team')       AS beijing_count,
        COUNT(*) FILTER (WHERE pt.name='Onboard Pending')       AS onboard_pending_count,
        COUNT(*) FILTER (WHERE pt.name='Exception')             AS exception_count,
        COUNT(*) FILTER (WHERE pt.name='EOL - No Patches')      AS eol_count,
        COUNT(*) FILTER (WHERE pt.name='On Hold')               AS on_hold_count,
        COUNT(*) FILTER (WHERE ss.name='Alive')                 AS alive_count
      FROM assets a
      LEFT JOIN locations      l  ON a.location_id      = l.id
      LEFT JOIN patching_types pt ON a.patching_type_id = pt.id
      LEFT JOIN asset_types    at ON a.asset_type_id    = at.id
      LEFT JOIN server_status  ss ON a.server_status_id = ss.id
      GROUP BY COALESCE(l.name,'Unassigned')
      ORDER BY total DESC
    `);

    // Merge all locations (including zero-count ones) into locationStats
    const locMap = {};
    locationStats.rows.forEach(r => { locMap[r.location] = r; });
    const zeroRow = (name) => ({
      location: name, total: '0', vm_count: '0', physical_count: '0',
      auto_count: '0', manual_count: '0', beijing_count: '0',
      onboard_pending_count: '0', exception_count: '0', eol_count: '0',
      on_hold_count: '0', alive_count: '0'
    });
    const fullLocationStats = allLocations.rows.map(l => locMap[l.name] || zeroRow(l.name));

    // Compute compliance percentage
    const c = compliance.rows[0];
    const totalAlive = parseInt(c.total_alive) || 0;
    const autoAlive = parseInt(c.auto_alive) || 0;
    const manualAlive = parseInt(c.manual_alive) || 0;
    const compliancePct = totalAlive > 0
      ? Math.round(((autoAlive + manualAlive) / totalAlive) * 100)
      : 0;

    res.json({
      ...summary.rows[0],
      location_distribution: locationDist.rows,
      dept_stats: deptStats.rows,
      compliance: {
        ...c,
        compliance_pct: compliancePct,
      },
      location_stats: fullLocationStats,
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
