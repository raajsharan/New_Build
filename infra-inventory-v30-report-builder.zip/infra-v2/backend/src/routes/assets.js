const router = require('express').Router();
const pool = require('../config/database');
const multer = require('multer');
const { parse } = require('csv-parse/sync');
const { auth, requireWrite } = require('../middleware/auth');

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });

const ASSET_SELECT = `
  SELECT a.*,
    at.name AS asset_type, ot.name AS os_type, ov.name AS os_version,
    d.name AS department, ss.name AS server_status,
    ps.name AS patching_schedule, pt.name AS patching_type,
    spt.name AS server_patch_type, l.name AS location
  FROM assets a
  LEFT JOIN asset_types at         ON a.asset_type_id       = at.id
  LEFT JOIN os_types ot            ON a.os_type_id          = ot.id
  LEFT JOIN os_versions ov         ON a.os_version_id       = ov.id
  LEFT JOIN departments d          ON a.department_id       = d.id
  LEFT JOIN server_status ss       ON a.server_status_id    = ss.id
  LEFT JOIN patching_schedules ps  ON a.patching_schedule_id = ps.id
  LEFT JOIN patching_types pt      ON a.patching_type_id    = pt.id
  LEFT JOIN server_patch_types spt ON a.server_patch_type_id = spt.id
  LEFT JOIN locations l            ON a.location_id         = l.id
`;

// IP-only duplicate check (hostname duplicates are allowed)
async function checkIPDuplicate(ip_address, excludeId = null) {
  if (!ip_address?.trim()) return null;
  const q = excludeId
    ? await pool.query('SELECT id,vm_name,os_hostname FROM assets WHERE LOWER(ip_address)=LOWER($1) AND id!=$2', [ip_address.trim(), excludeId])
    : await pool.query('SELECT id,vm_name,os_hostname FROM assets WHERE LOWER(ip_address)=LOWER($1)', [ip_address.trim()]);
  if (q.rows.length) {
    const a = q.rows[0];
    return `IP "${ip_address}" already assigned to "${a.vm_name || a.os_hostname || 'ID:'+a.id}"`;
  }
  return null;
}

// GET /api/assets
router.get('/', auth, async (req, res) => {
  try {
    const { search, location, department, server_status, asset_type, page = 1, limit = 20 } = req.query;
    const conds = [], params = [];
    let i = 1;
    if (search) {
      conds.push(`(a.os_hostname ILIKE $${i} OR a.ip_address ILIKE $${i} OR a.assigned_user ILIKE $${i} OR a.vm_name ILIKE $${i})`);
      params.push(`%${search}%`); i++;
    }
    if (location)      { conds.push(`l.name=$${i++}`); params.push(location); }
    if (department)    { conds.push(`d.name=$${i++}`); params.push(department); }
    if (server_status) { conds.push(`ss.name=$${i++}`); params.push(server_status); }
    if (asset_type)    { conds.push(`at.name=$${i++}`); params.push(asset_type); }

    const joins = `LEFT JOIN asset_types at ON a.asset_type_id=at.id LEFT JOIN departments d ON a.department_id=d.id LEFT JOIN server_status ss ON a.server_status_id=ss.id LEFT JOIN locations l ON a.location_id=l.id LEFT JOIN patching_types pt ON a.patching_type_id=pt.id LEFT JOIN patching_schedules ps ON a.patching_schedule_id=ps.id LEFT JOIN server_patch_types spt ON a.server_patch_type_id=spt.id LEFT JOIN os_types ot ON a.os_type_id=ot.id LEFT JOIN os_versions ov ON a.os_version_id=ov.id`;
    const where = conds.length ? 'WHERE ' + conds.join(' AND ') : '';

    const countR = await pool.query(`SELECT COUNT(*) FROM assets a ${joins} ${where}`, params);
    const offset = (page - 1) * limit;
    const dataR  = await pool.query(`${ASSET_SELECT} ${where} ORDER BY a.created_at DESC LIMIT $${i} OFFSET $${i+1}`, [...params, parseInt(limit), parseInt(offset)]);

    // Mask passwords
    const canView = req.user.role === 'admin' ||
      (await pool.query('SELECT can_view_passwords FROM password_visibility_settings WHERE user_id=$1', [req.user.id])).rows[0]?.can_view_passwords;
    if (!canView) dataR.rows.forEach(r => { if (r.asset_password) r.asset_password = '••••••••'; });

    res.json({ assets: dataR.rows, total: parseInt(countR.rows[0].count), page: parseInt(page), limit: parseInt(limit) });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Server error' }); }
});

// GET /api/assets/check-duplicate — IP only
router.get('/check-duplicate', auth, async (req, res) => {
  try {
    const { ip_address, exclude_id } = req.query;
    const err = await checkIPDuplicate(ip_address, exclude_id ? parseInt(exclude_id) : null);
    res.json({ duplicate: !!err, errors: err ? [err] : [] });
  } catch { res.status(500).json({ error: 'Server error' }); }
});

// GET /api/assets/:id
router.get('/:id', auth, async (req, res) => {
  try {
    const r = await pool.query(`${ASSET_SELECT} WHERE a.id=$1`, [req.params.id]);
    if (!r.rows.length) return res.status(404).json({ error: 'Asset not found' });
    res.json(r.rows[0]);
  } catch { res.status(500).json({ error: 'Server error' }); }
});

// POST /api/assets
router.post('/', auth, requireWrite, async (req, res) => {
  try {
    const {
      vm_name, os_hostname, ip_address, asset_type_id, os_type_id, os_version_id,
      assigned_user, department_id, business_purpose, server_status_id,
      me_installed_status, tenable_installed_status, patching_schedule_id,
      patching_type_id, server_patch_type_id, location_id, additional_remarks,
      serial_number, idrac_enabled, idrac_ip, eol_status,
      asset_username, asset_password, custom_field_values,
      hosted_ip, asset_tag, oem_status
    } = req.body;

    const ipErr = await checkIPDuplicate(ip_address);
    if (ipErr) return res.status(409).json({ error: ipErr, duplicate: true });

    const r = await pool.query(`
      INSERT INTO assets (vm_name,os_hostname,ip_address,asset_type_id,os_type_id,os_version_id,
        assigned_user,department_id,business_purpose,server_status_id,
        me_installed_status,tenable_installed_status,patching_schedule_id,
        patching_type_id,server_patch_type_id,location_id,additional_remarks,
        serial_number,idrac_enabled,idrac_ip,eol_status,asset_username,asset_password,
        custom_field_values,submitted_by,hosted_ip,asset_tag,oem_status)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28)
      RETURNING id`,
      [vm_name,os_hostname,ip_address,asset_type_id||null,os_type_id||null,os_version_id||null,
       assigned_user,department_id||null,business_purpose,server_status_id||null,
       me_installed_status||false,tenable_installed_status||false,patching_schedule_id||null,
       patching_type_id||null,server_patch_type_id||null,location_id||null,additional_remarks,
       serial_number,idrac_enabled||false,idrac_ip||null,eol_status||'InSupport',
       asset_username,asset_password,JSON.stringify(custom_field_values||{}),
       req.user.username, hosted_ip||'', asset_tag||'', oem_status||'']
    );
    const created = await pool.query(`${ASSET_SELECT} WHERE a.id=$1`, [r.rows[0].id]);
    res.status(201).json(created.rows[0]);
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ error: 'Duplicate IP address', duplicate: true });
    console.error(e); res.status(500).json({ error: 'Server error' });
  }
});

// PUT /api/assets/:id
router.put('/:id', auth, requireWrite, async (req, res) => {
  try {
    const {
      vm_name, os_hostname, ip_address, asset_type_id, os_type_id, os_version_id,
      assigned_user, department_id, business_purpose, server_status_id,
      me_installed_status, tenable_installed_status, patching_schedule_id,
      patching_type_id, server_patch_type_id, location_id, additional_remarks,
      serial_number, idrac_enabled, idrac_ip, eol_status,
      asset_username, asset_password, custom_field_values,
      hosted_ip, asset_tag, oem_status
    } = req.body;

    const ipErr = await checkIPDuplicate(ip_address, parseInt(req.params.id));
    if (ipErr) return res.status(409).json({ error: ipErr, duplicate: true });

    await pool.query(`
      UPDATE assets SET vm_name=$1,os_hostname=$2,ip_address=$3,asset_type_id=$4,os_type_id=$5,os_version_id=$6,
        assigned_user=$7,department_id=$8,business_purpose=$9,server_status_id=$10,
        me_installed_status=$11,tenable_installed_status=$12,patching_schedule_id=$13,
        patching_type_id=$14,server_patch_type_id=$15,location_id=$16,additional_remarks=$17,
        serial_number=$18,idrac_enabled=$19,idrac_ip=$20,eol_status=$21,
        asset_username=$22,asset_password=$23,custom_field_values=$24,
        submitted_by=$25,hosted_ip=$26,asset_tag=$27,oem_status=$28,updated_at=NOW()
      WHERE id=$29`,
      [vm_name,os_hostname,ip_address,asset_type_id||null,os_type_id||null,os_version_id||null,
       assigned_user,department_id||null,business_purpose,server_status_id||null,
       me_installed_status||false,tenable_installed_status||false,patching_schedule_id||null,
       patching_type_id||null,server_patch_type_id||null,location_id||null,additional_remarks,
       serial_number,idrac_enabled||false,idrac_ip||null,eol_status||'InSupport',
       asset_username,asset_password,JSON.stringify(custom_field_values||{}),
       req.user.username, hosted_ip||'', asset_tag||'', oem_status||'', req.params.id]
    );
    const updated = await pool.query(`${ASSET_SELECT} WHERE a.id=$1`, [req.params.id]);
    res.json(updated.rows[0]);
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ error: 'Duplicate IP address', duplicate: true });
    res.status(500).json({ error: 'Server error' });
  }
});

// DELETE /api/assets/:id
router.delete('/:id', auth, requireWrite, async (req, res) => {
  try {
    const r = await pool.query('DELETE FROM assets WHERE id=$1 RETURNING id', [req.params.id]);
    if (!r.rows.length) return res.status(404).json({ error: 'Not found' });
    res.json({ message: 'Deleted', id: req.params.id });
  } catch { res.status(500).json({ error: 'Server error' }); }
});

// GET /api/assets/export/csv
router.get('/export/csv', auth, async (req, res) => {
  try {
    const { search, location, department, server_status, asset_type } = req.query;
    const conds = [], params = [];
    let i = 1;
    if (search)        { conds.push(`(a.os_hostname ILIKE $${i} OR a.ip_address ILIKE $${i} OR a.vm_name ILIKE $${i})`); params.push(`%${search}%`); i++; }
    if (location)      { conds.push(`l.name=$${i++}`); params.push(location); }
    if (department)    { conds.push(`d.name=$${i++}`); params.push(department); }
    if (server_status) { conds.push(`ss.name=$${i++}`); params.push(server_status); }
    if (asset_type)    { conds.push(`at.name=$${i++}`); params.push(asset_type); }
    const where = conds.length ? 'WHERE ' + conds.join(' AND ') : '';
    const r = await pool.query(`${ASSET_SELECT} ${where} ORDER BY a.created_at DESC`, params);

    const esc = v => { if (!v && v !== 0) return ''; const s = String(v).replace(/"/g,'""'); return s.includes(',') || s.includes('"') ? `"${s}"` : s; };
    const headers = ['ID','VM Name','Hostname','IP','Asset Type','OS','Version','User','Dept',
      'Status','Patch Type','Sched','Location','Serial','iDRAC','iDRAC IP','EOL',
      'ME','Tenable','Hosted IP','Asset Tag','Submitted By','Created'];
    const rows = r.rows.map(a => [
      a.id,a.vm_name,a.os_hostname,a.ip_address,a.asset_type,a.os_type,a.os_version,
      a.assigned_user,a.department,a.server_status,a.patching_type,a.patching_schedule,
      a.location,a.serial_number,a.idrac_enabled?'Yes':'No',a.idrac_ip,a.eol_status,
      a.me_installed_status?'Yes':'No',a.tenable_installed_status?'Yes':'No',
      a.hosted_ip,a.asset_tag,a.submitted_by,
      new Date(a.created_at).toISOString().split('T')[0]
    ].map(esc).join(','));

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="inventory-${new Date().toISOString().split('T')[0]}.csv"`);
    res.send([headers.join(','), ...rows].join('\n'));
  } catch (e) { console.error(e); res.status(500).json({ error: 'Export failed' }); }
});

// GET /api/assets/export/csv-template
router.get('/export/csv-template', auth, (req, res) => {
  const h = ['vm_name','os_hostname','ip_address','asset_type','os_type','os_version','assigned_user',
    'department','business_purpose','server_status','me_installed_status','tenable_installed_status',
    'patching_schedule','patching_type','server_patch_type','location','additional_remarks',
    'serial_number','idrac_enabled','idrac_ip','eol_status','asset_username','asset_password',
    'hosted_ip','asset_tag'];
  const ex = ['SERVER-01','server-01.local','192.168.1.10','VM','Linux','Ubuntu 22.04 LTS','john.doe',
    'IT','Web server','Alive','true','false','Monthly','Auto','Critical','DC1','Notes',
    'SN123','false','','InSupport','admin','password123','10.0.0.1','0001'];
  res.setHeader('Content-Type','text/csv');
  res.setHeader('Content-Disposition','attachment; filename="asset_import_template.csv"');
  res.send(h.join(',') + '\n' + ex.join(','));
});

// POST /api/assets/import/csv
router.post('/import/csv', auth, requireWrite, upload.single('file'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
    const records = parse(req.file.buffer.toString(), { columns: true, skip_empty_lines: true, trim: true });
    const results = { success: 0, failed: 0, skipped: 0, errors: [] };
    for (let i = 0; i < records.length; i++) {
      const r = records[i];
      try {
        const ipErr = await checkIPDuplicate(r.ip_address);
        if (ipErr) { results.skipped++; results.errors.push(`Row ${i+2} skipped (IP dup): ${ipErr}`); continue; }
        const fk = async (t, v) => v ? (await pool.query(`SELECT id FROM ${t} WHERE name ILIKE $1`, [v])).rows[0]?.id || null : null;
        const ot = await fk('os_types', r.os_type);
        const ov = ot && r.os_version ? (await pool.query('SELECT id FROM os_versions WHERE name ILIKE $1 AND os_type_id=$2', [r.os_version, ot])).rows[0]?.id || null : null;
        await pool.query(`
          INSERT INTO assets (vm_name,os_hostname,ip_address,asset_type_id,os_type_id,os_version_id,
            assigned_user,department_id,business_purpose,server_status_id,me_installed_status,
            tenable_installed_status,patching_schedule_id,patching_type_id,server_patch_type_id,
            location_id,additional_remarks,serial_number,idrac_enabled,idrac_ip,eol_status,
            asset_username,asset_password,submitted_by,hosted_ip,asset_tag)
          VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26)`,
          [r.vm_name,r.os_hostname,r.ip_address,
           await fk('asset_types',r.asset_type), ot, ov,
           r.assigned_user, await fk('departments',r.department), r.business_purpose,
           await fk('server_status',r.server_status),
           r.me_installed_status==='true', r.tenable_installed_status==='true',
           await fk('patching_schedules',r.patching_schedule),
           await fk('patching_types',r.patching_type),
           await fk('server_patch_types',r.server_patch_type),
           await fk('locations',r.location),
           r.additional_remarks,r.serial_number,r.idrac_enabled==='true',r.idrac_ip||null,
           r.eol_status||'InSupport',r.asset_username,r.asset_password,
           req.user.username, r.hosted_ip||'', r.asset_tag||'']
        );
        results.success++;
      } catch (err) { results.failed++; results.errors.push(`Row ${i+2}: ${err.message}`); }
    }
    res.json(results);
  } catch (e) { res.status(500).json({ error: 'Import failed: ' + e.message }); }
});

// ── GET /api/assets/report — fetch all assets (no pagination) for reporting ──
router.get('/report', auth, async (req, res) => {
  try {
    const r = await pool.query(`${ASSET_SELECT} ORDER BY a.created_at DESC`);
    res.json(r.rows);
  } catch (e) { console.error(e); res.status(500).json({ error: 'Server error' }); }
});

module.exports = router;
