# Infrastructure Inventory Management System - Ubuntu 24.04 Native Setup

## Complete Installation Guide for Ubuntu 24.04 LTS

This guide will set up the application natively on Ubuntu 24.04 without Docker.

---

## PART 1: SYSTEM PREREQUISITES

### Step 1: Update System
```bash
sudo apt update
sudo apt upgrade -y
sudo apt install -y curl wget git build-essential
```

### Step 2: Install Node.js 18+ LTS
```bash
# Install Node.js 20 LTS (recommended)
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Verify installation
node --version    # Should be v20.x.x
npm --version     # Should be 10.x.x
```

### Step 3: Install PostgreSQL 15
```bash
# Add PostgreSQL repository
sudo sh -c 'echo "deb http://apt.postgresql.org/pub/repos/apt $(lsb_release -cs)-pgdg main" > /etc/apt/sources.list.d/pgdg.list'
wget --quiet -O - https://www.postgresql.org/media/keys/ACCC4CF8.asc | sudo apt-key add -

# Install PostgreSQL
sudo apt update
sudo apt install -y postgresql-15 postgresql-contrib-15

# Start and enable PostgreSQL
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Verify installation
psql --version    # Should show PostgreSQL 15.x
```

### Step 4: Install Nginx (Web Server & Reverse Proxy)
```bash
sudo apt install -y nginx

# Start and enable Nginx
sudo systemctl start nginx
sudo systemctl enable nginx

# Verify Nginx is running
sudo systemctl status nginx
```

### Step 5: Install Certbot for SSL (Optional but Recommended)
```bash
sudo apt install -y certbot python3-certbot-nginx
```

---

## PART 2: CREATE APPLICATION USER & DIRECTORIES

### Create Application User
```bash
# Create user 'infra' for application
sudo useradd -m -s /bin/bash infra
sudo usermod -aG sudo infra

# Create application directory
sudo mkdir -p /opt/infrastructure-inventory
sudo chown -R infra:infra /opt/infrastructure-inventory

# Create log directory
sudo mkdir -p /var/log/infrastructure-inventory
sudo chown -R infra:infra /var/log/infrastructure-inventory

# Create data directory for uploads
sudo mkdir -p /opt/infrastructure-inventory/uploads
sudo chown -R infra:infra /opt/infrastructure-inventory/uploads
```

### Switch to Application User
```bash
sudo su - infra
cd /opt/infrastructure-inventory
```

---

## PART 3: SETUP DATABASE

### Create PostgreSQL User & Database
```bash
# Switch to postgres user
sudo su - postgres

# Connect to PostgreSQL
psql

# Run these commands in psql:
CREATE ROLE infra_user WITH PASSWORD 'secure_database_password' LOGIN CREATEDB;
CREATE DATABASE infrastructure_inventory OWNER infra_user;
GRANT ALL PRIVILEGES ON DATABASE infrastructure_inventory TO infra_user;

# Exit psql
\q

# Exit postgres user
exit
```

### Initialize Database Schema
```bash
# As infra user, from /opt/infrastructure-inventory

# Copy the database_init.sql file to this location
# Then run:

psql -U infra_user -h localhost -d infrastructure_inventory -f database_init.sql

# Verify connection
psql -U infra_user -h localhost -d infrastructure_inventory -c "SELECT COUNT(*) FROM users;"
# Should return: count = 1 (admin user)
```

---

## PART 4: SETUP BACKEND

### Clone/Copy Application Files
```bash
# As infra user, in /opt/infrastructure-inventory

# Create backend directory
mkdir -p backend
cd backend

# Copy all backend_*.js files to this directory
# Copy backend_package.json as package.json

# Your file structure should look like:
# /opt/infrastructure-inventory/backend/
#   ├── server.js
#   ├── package.json
#   ├── config/
#   │   └── database.js
#   ├── controllers/
#   ├── middleware/
#   ├── routes/
#   └── .env
```

### Install Node Dependencies
```bash
cd /opt/infrastructure-inventory/backend
npm install

# Verify installation
npm list | head -20
```

### Create Backend Environment File
```bash
# Create .env file
cat > .env << 'EOF'
# Database Configuration
DB_HOST=localhost
DB_PORT=5432
DB_USER=infra_user
DB_PASSWORD=secure_database_password
DB_NAME=infrastructure_inventory

# Server Configuration
PORT=5000
NODE_ENV=production
FRONTEND_URL=http://your-domain.com

# JWT Configuration
JWT_SECRET=your-super-secret-jwt-key-change-this-to-random-32-chars-minimum

# File Upload
MAX_FILE_SIZE=50000000
UPLOAD_DIR=./uploads

# CORS
CORS_ORIGIN=http://your-domain.com
EOF

# Edit the file with your actual values
nano .env
```

### Test Backend Startup
```bash
# Start backend (will run in foreground)
npm start

# You should see:
# ╔════════════════════════════════════════════════════╗
# ║   Infrastructure Inventory Management System       ║
# ║   Server running on: http://localhost:5000         ║
# ║   Environment: production                          ║
# ╚════════════════════════════════════════════════════╝

# Test in another terminal:
curl http://localhost:5000/api/dashboard/summary

# If you get a 401 error, that's expected (need auth token)
# If backend starts successfully, press Ctrl+C to stop
```

---

## PART 5: SETUP FRONTEND

### Copy Frontend Files
```bash
# As infra user, from /opt/infrastructure-inventory

mkdir -p frontend
cd frontend

# Copy all frontend_*.jsx files and configs
# Your structure should be:
# /opt/infrastructure-inventory/frontend/
#   ├── src/
#   │   ├── pages/
#   │   ├── components/
#   │   ├── context/
#   │   ├── services/
#   │   └── App.jsx
#   ├── index.html
#   ├── package.json
#   ├── vite.config.js
#   ├── tailwind.config.js
#   └── .env
```

### Install Frontend Dependencies
```bash
cd /opt/infrastructure-inventory/frontend
npm install

# This will take a few minutes
```

### Create Frontend Environment File
```bash
cat > .env << 'EOF'
VITE_API_URL=http://your-domain.com/api
EOF

# Edit with your domain
nano .env
```

### Build Frontend
```bash
cd /opt/infrastructure-inventory/frontend

# Build for production
npm run build

# This creates a 'dist' folder with optimized files
# Verify build succeeded
ls -la dist/

# Should see: index.html and other files
```

---

## PART 6: SETUP SYSTEMD SERVICES

### Create Backend Service File
```bash
# As root user (use sudo)
sudo tee /etc/systemd/system/infra-inventory-backend.service > /dev/null << 'EOF'
[Unit]
Description=Infrastructure Inventory Backend API
After=network.target postgresql.service

[Service]
Type=simple
User=infra
WorkingDirectory=/opt/infrastructure-inventory/backend
ExecStart=/usr/bin/npm start
Restart=always
RestartSec=10
StandardOutput=append:/var/log/infrastructure-inventory/backend.log
StandardError=append:/var/log/infrastructure-inventory/backend-error.log
Environment="NODE_ENV=production"

[Install]
WantedBy=multi-user.target
EOF

# Enable and start the service
sudo systemctl daemon-reload
sudo systemctl enable infra-inventory-backend
sudo systemctl start infra-inventory-backend

# Check status
sudo systemctl status infra-inventory-backend

# View logs
sudo tail -f /var/log/infrastructure-inventory/backend.log
```

---

## PART 7: SETUP NGINX REVERSE PROXY

### Create Nginx Configuration
```bash
# Create Nginx configuration
sudo tee /etc/nginx/sites-available/infrastructure-inventory > /dev/null << 'EOF'
upstream backend {
    server localhost:5000;
}

server {
    listen 80;
    server_name your-domain.com www.your-domain.com;

    # Redirect to HTTPS (optional, set up HTTPS first)
    # return 301 https://$server_name$request_uri;

    # Gzip compression
    gzip on;
    gzip_types text/plain text/css text/xml text/javascript application/x-javascript application/xml+rss application/json;
    gzip_vary on;
    gzip_comp_level 6;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    # Increase body size limit for file uploads
    client_max_body_size 50M;

    # Frontend static files
    location / {
        root /opt/infrastructure-inventory/frontend/dist;
        try_files $uri $uri/ /index.html;
        expires 1d;
        add_header Cache-Control "public, immutable";
    }

    # Cache busting for JS/CSS
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        root /opt/infrastructure-inventory/frontend/dist;
        expires 30d;
        add_header Cache-Control "public, immutable";
    }

    # API proxy to backend
    location /api/ {
        proxy_pass http://backend;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 60s;
        proxy_connect_timeout 60s;
    }

    # Deny access to sensitive files
    location ~ /\. {
        deny all;
    }

    location ~ /\#\# {
        deny all;
    }
}
EOF

# Create symlink to enable the site
sudo ln -s /etc/nginx/sites-available/infrastructure-inventory /etc/nginx/sites-enabled/

# Remove default site if needed
sudo rm -f /etc/nginx/sites-enabled/default

# Test Nginx configuration
sudo nginx -t

# Restart Nginx
sudo systemctl restart nginx

# Check status
sudo systemctl status nginx
```

### Replace your-domain.com
```bash
# Edit the Nginx config and replace your-domain.com with your actual domain
sudo nano /etc/nginx/sites-available/infrastructure-inventory

# Then restart Nginx
sudo systemctl restart nginx
```

---

## PART 8: SETUP SSL/HTTPS WITH CERTBOT (Optional but Recommended)

```bash
# Stop Nginx temporarily (if using HTTP auth)
# sudo systemctl stop nginx

# Get SSL certificate from Let's Encrypt
sudo certbot certonly --standalone -d your-domain.com -d www.your-domain.com

# Update Nginx configuration for HTTPS
sudo nano /etc/nginx/sites-available/infrastructure-inventory

# Change the Nginx config to listen on 443:

# Replace:
# listen 80;
# With:
# listen 443 ssl http2;
# ssl_certificate /etc/letsencrypt/live/your-domain.com/fullchain.pem;
# ssl_certificate_key /etc/letsencrypt/live/your-domain.com/privkey.pem;

# Add HTTP to HTTPS redirect:
# Add a new server block before the main server block:
# server {
#     listen 80;
#     server_name your-domain.com www.your-domain.com;
#     return 301 https://$server_name$request_uri;
# }

# Test configuration
sudo nginx -t

# Restart Nginx
sudo systemctl restart nginx
```

---

## PART 9: SETUP FIREWALL

```bash
# If using UFW (Ubuntu Firewall)
sudo ufw enable

# Allow SSH (important! don't lock yourself out)
sudo ufw allow 22/tcp

# Allow HTTP
sudo ufw allow 80/tcp

# Allow HTTPS
sudo ufw allow 443/tcp

# Check status
sudo ufw status

# Output should show:
# Status: active
# 22/tcp  ALLOW
# 80/tcp  ALLOW
# 443/tcp ALLOW
```

---

## PART 10: SETUP AUTOMATIC DATABASE BACKUPS

### Create Backup Script
```bash
# Create backup directory
sudo mkdir -p /opt/infrastructure-inventory/backups
sudo chown infra:infra /opt/infrastructure-inventory/backups

# Create backup script
cat > /opt/infrastructure-inventory/backups/backup.sh << 'EOF'
#!/bin/bash

BACKUP_DIR="/opt/infrastructure-inventory/backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="$BACKUP_DIR/infrastructure_inventory_$TIMESTAMP.sql"

# Backup database
pg_dump -U infra_user -h localhost infrastructure_inventory > "$BACKUP_FILE"

# Compress backup
gzip "$BACKUP_FILE"

# Keep only last 30 days of backups
find "$BACKUP_DIR" -name "*.sql.gz" -mtime +30 -delete

# Log the backup
echo "$(date): Backup created: $BACKUP_FILE.gz" >> "$BACKUP_DIR/backup.log"
EOF

chmod +x /opt/infrastructure-inventory/backups/backup.sh
```

### Setup Automated Backups with Cron
```bash
# Edit crontab
crontab -e

# Add this line to run backup daily at 2:00 AM:
0 2 * * * /opt/infrastructure-inventory/backups/backup.sh

# Add this line to run backup weekly at Sunday 3:00 AM:
0 3 * * 0 /opt/infrastructure-inventory/backups/backup.sh
```

---

## PART 11: MONITORING & LOGGING

### View Backend Logs
```bash
# Real-time log view
sudo tail -f /var/log/infrastructure-inventory/backend.log

# View errors
sudo tail -f /var/log/infrastructure-inventory/backend-error.log

# Check service status
sudo systemctl status infra-inventory-backend

# Restart service if needed
sudo systemctl restart infra-inventory-backend
```

### View Nginx Logs
```bash
# Access logs
sudo tail -f /var/log/nginx/access.log

# Error logs
sudo tail -f /var/log/nginx/error.log
```

### Monitor System Resources
```bash
# Install monitoring tools
sudo apt install -y htop iotop

# View system stats
htop

# View disk usage
df -h

# View database connections
sudo su - postgres
psql -c "SELECT datname, count(*) FROM pg_stat_activity GROUP BY datname;"
```

---

## PART 12: POST-INSTALLATION VERIFICATION

### Verify All Services Running
```bash
# Check Node.js backend
sudo systemctl status infra-inventory-backend

# Check Nginx
sudo systemctl status nginx

# Check PostgreSQL
sudo systemctl status postgresql

# Check ports are listening
sudo netstat -tlnp | grep -E ':(5000|80|443|5432)'
```

### Test Application
```bash
# Test backend API
curl http://localhost:5000/api/dashboard/summary

# Test frontend (if on same machine)
curl http://localhost

# Or access via browser:
http://your-domain.com

# Login with:
# Username: admin@infra.local
# Password: admin123
```

### Create New Admin User (Optional)
```bash
# Connect to database
psql -U infra_user -h localhost -d infrastructure_inventory

# Insert new admin
INSERT INTO users (username, email, password_hash, full_name, is_admin, can_write, is_active)
VALUES ('your_admin', 'admin@yourcompany.com', '$2b$10$YIjqVhKW9VUrWWf7xZZMz.l68MXMp2K0cUn7EqWVnz2yJmHIL7K9K', 'Your Name', TRUE, TRUE, TRUE);

# Exit
\q
```

---

## PART 13: PRODUCTION CONFIGURATION CHECKLIST

Before going live, complete these:

### Security
- [ ] Changed admin password
- [ ] Generated new strong JWT_SECRET
- [ ] Enabled HTTPS/SSL
- [ ] Configured firewall rules
- [ ] Set strong database password
- [ ] Enabled automated backups
- [ ] Reviewed CORS settings
- [ ] Disabled debug logging in production

### Performance
- [ ] Enabled Gzip compression in Nginx
- [ ] Configured caching headers
- [ ] Optimized database indexes
- [ ] Set appropriate log rotation
- [ ] Configured connection pooling
- [ ] Optimized Node.js max connections

### Monitoring
- [ ] Setup log monitoring
- [ ] Configure email alerts
- [ ] Setup uptime monitoring
- [ ] Monitor disk space
- [ ] Monitor database size
- [ ] Track performance metrics

### Maintenance
- [ ] Schedule regular backups (daily)
- [ ] Schedule database maintenance (weekly)
- [ ] Update system packages regularly
- [ ] Review and rotate logs
- [ ] Test backup recovery process
- [ ] Document procedures

---

## QUICK REFERENCE COMMANDS

### Service Management
```bash
# Start/Stop/Restart Backend
sudo systemctl start infra-inventory-backend
sudo systemctl stop infra-inventory-backend
sudo systemctl restart infra-inventory-backend

# Start/Stop/Restart Nginx
sudo systemctl start nginx
sudo systemctl stop nginx
sudo systemctl restart nginx

# Check logs
sudo journalctl -u infra-inventory-backend -f
sudo tail -f /var/log/nginx/access.log
```

### Database
```bash
# Connect to database
psql -U infra_user -h localhost -d infrastructure_inventory

# Backup database
pg_dump -U infra_user -h localhost infrastructure_inventory > backup.sql

# Restore database
psql -U infra_user -h localhost -d infrastructure_inventory < backup.sql

# Check database size
psql -U infra_user -c "SELECT pg_size_pretty(pg_database_size('infrastructure_inventory'));"
```

### Application
```bash
# Update backend
cd /opt/infrastructure-inventory/backend
npm update
sudo systemctl restart infra-inventory-backend

# Update frontend
cd /opt/infrastructure-inventory/frontend
npm update
npm run build
sudo systemctl restart nginx
```

---

## TROUBLESHOOTING

### Backend Won't Start
```bash
# Check logs
sudo journalctl -u infra-inventory-backend -n 50 --no-pager

# Check if port 5000 is already in use
sudo lsof -i :5000

# Test database connection
psql -U infra_user -h localhost -d infrastructure_inventory
```

### Frontend Not Loading
```bash
# Check Nginx configuration
sudo nginx -t

# Check Nginx logs
sudo tail -f /var/log/nginx/error.log

# Verify frontend files exist
ls -la /opt/infrastructure-inventory/frontend/dist/
```

### Database Connection Issues
```bash
# Check PostgreSQL is running
sudo systemctl status postgresql

# Check PostgreSQL is listening
sudo netstat -tlnp | grep postgres

# Try connecting directly
psql -U infra_user -h localhost -c "SELECT 1;"
```

### Performance Issues
```bash
# Check system resources
htop

# Check disk space
df -h

# Check database connections
psql -c "SELECT count(*) FROM pg_stat_activity;"

# Check slow queries
psql -c "SELECT query, calls, total_time FROM pg_stat_statements ORDER BY total_time DESC LIMIT 10;"
```

---

## NEXT STEPS

1. **Access the application:** http://your-domain.com
2. **Change admin password:** Login and change immediately
3. **Create team users:** Add users with appropriate permissions
4. **Configure dropdowns:** Set up your asset types, locations, etc.
5. **Add your assets:** Start populating your infrastructure inventory
6. **Monitor:** Watch logs and system resources
7. **Backup:** Ensure daily backups are running

---

## SUCCESS INDICATORS

Your setup is complete and working when:
```
✅ Backend service is running (sudo systemctl status infra-inventory-backend)
✅ Nginx is serving the application (sudo systemctl status nginx)
✅ Database is connected (psql -U infra_user -c "SELECT 1;")
✅ Application loads in browser (http://your-domain.com)
✅ Login works with admin@infra.local
✅ Dashboard displays data
✅ You can add/edit/delete assets
✅ Logs show no errors
✅ HTTPS is enabled (if configured)
✅ Backups are running automatically
```

---

**Congratulations! Your Infrastructure Inventory Management System is now running on Ubuntu 24.04!**

For support, refer to the documentation files or check the logs.
