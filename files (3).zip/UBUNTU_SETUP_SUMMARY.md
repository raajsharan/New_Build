# 🚀 Ubuntu 24.04 Native Setup - Complete Package

## What You're Getting

A **complete, production-ready application deployment package for Ubuntu 24.04 LTS** without Docker.

### Key Documents for Ubuntu Setup

| Document | Purpose | Start Here |
|----------|---------|-----------|
| **UBUNTU_DEPLOYMENT_GUIDE.md** | Step-by-step deployment (12 steps) | 👈 **START HERE** |
| **ubuntu-setup.sh** | Automated system setup script | Run: `sudo bash ubuntu-setup.sh` |
| **UBUNTU_24_04_SETUP.md** | Detailed manual setup instructions | Reference guide |
| **UBUNTU_CONFIG_FILES.md** | Nginx, systemd, scripts, monitoring | Configuration templates |

---

## Quick Start (Ubuntu 24.04)

### Option 1: Fully Automated (Recommended - 15 minutes)

```bash
# 1. SSH into your Ubuntu 24.04 server
ssh your-username@your-server-ip

# 2. Download the automation script
wget https://your-location/ubuntu-setup.sh
# Or copy it to the server via SCP

# 3. Run the automated setup (as root)
sudo bash ubuntu-setup.sh your-domain.com

# The script will:
# ✓ Update system
# ✓ Install Node.js 20 LTS
# ✓ Install PostgreSQL 15
# ✓ Install Nginx
# ✓ Create app user and directories
# ✓ Setup database
# ✓ Create systemd services
# ✓ Configure firewall
# ✓ Setup backups

# 4. Follow remaining setup instructions (see step 2)
```

### Option 2: Step-by-Step Manual (Detailed - 30 minutes)

Follow **UBUNTU_DEPLOYMENT_GUIDE.md** which provides:
1. Automated prerequisites (5 min)
2. Copy application files (5 min)
3. Setup backend (10 min)
4. Setup database (5 min)
5. Setup frontend (10 min)
6. Start services (2 min)
7. Access application (2 min)
8. Security & SSL (5 min)
9. Verification (2 min)

---

## Complete File Structure After Setup

```
/opt/infrastructure-inventory/
├── backend/
│   ├── server.js
│   ├── package.json
│   ├── config/database.js
│   ├── controllers/ (all controller files)
│   ├── middleware/auth.js
│   ├── routes/ (all route files)
│   ├── .env (configured)
│   └── uploads/
│
├── frontend/
│   ├── src/ (all source files)
│   ├── dist/ (production build)
│   ├── package.json
│   ├── vite.config.js
│   ├── tailwind.config.js
│   ├── .env (configured)
│   └── index.html
│
├── scripts/
│   ├── health-check.sh
│   ├── monitor.sh
│   └── backup.sh
│
├── backups/
│   └── (automated daily backups here)
│
└── uploads/
    └── (user uploads here)

/etc/nginx/sites-available/
├── infrastructure-inventory (configured)

/etc/systemd/system/
├── infra-inventory-backend.service (configured)

/var/log/infrastructure-inventory/
├── backend.log
└── backend-error.log
```

---

## System Services After Setup

### Backend API Service
```bash
# Runs as: systemd service
# Port: 5000 (internal, proxied through Nginx)
# Status: sudo systemctl status infra-inventory-backend
# Logs: sudo tail -f /var/log/infrastructure-inventory/backend.log
# Auto-restart: Enabled
```

### Nginx Web Server
```bash
# Serves: Frontend static files + API proxy
# Ports: 80 (HTTP), 443 (HTTPS optional)
# Status: sudo systemctl status nginx
# Logs: sudo tail -f /var/log/nginx/error.log
# Features: Gzip compression, security headers, caching
```

### PostgreSQL Database
```bash
# Stores: All application data
# Port: 5432 (local only)
# Database: infrastructure_inventory
# User: infra_user
# Backups: Daily at 2:00 AM (automated)
```

---

## What's Configured Automatically

### ✅ System Components
- Node.js 20 LTS for backend
- PostgreSQL 15 for database
- Nginx as reverse proxy & web server
- Systemd for service management
- UFW firewall with proper ports open
- Log rotation for all services

### ✅ Application Setup
- Complete backend API (40+ endpoints)
- Full React frontend (10 pages)
- PostgreSQL database with schema
- 4 sample assets for testing
- Admin user: admin@infra.local / admin123

### ✅ Production Features
- Auto-restart on failure
- Daily automated backups
- Health checks available
- Monitoring scripts included
- SSL/HTTPS ready
- Performance optimized
- Security hardened

### ✅ User Management
- Application user 'infra' created
- Proper permissions configured
- Sudo access for management
- Home directory setup

---

## Key Configuration Files

### Backend (.env)
```
DB_HOST=localhost
DB_PORT=5432
DB_USER=infra_user
DB_PASSWORD=secure_database_password_change_me
DB_NAME=infrastructure_inventory
PORT=5000
NODE_ENV=production
JWT_SECRET=(auto-generated)
FRONTEND_URL=http://your-domain.com
```

### Frontend (.env)
```
VITE_API_URL=http://your-domain.com/api
```

### Nginx
- Listens on ports 80 (HTTP) and 443 (HTTPS when configured)
- Proxies /api/* to backend on localhost:5000
- Serves frontend static files with caching
- Includes security headers
- Gzip compression enabled
- Supports 50MB file uploads

### Systemd Service
- Automatically restarts on failure
- Runs as 'infra' user
- Logs to /var/log/infrastructure-inventory/
- Starts after PostgreSQL
- Enabled for auto-start on boot

---

## Access After Setup

### Application URL
```
http://your-server-ip
# or
http://your-domain.com (if domain configured)
```

### Default Login
```
Username: admin@infra.local
Password: admin123

⚠️ CHANGE THIS PASSWORD IMMEDIATELY!
```

### SSH Access
```bash
# As regular user
ssh your-username@your-server-ip

# Switch to app user
sudo su - infra

# Backend directory
cd /opt/infrastructure-inventory/backend

# Frontend directory
cd /opt/infrastructure-inventory/frontend

# View logs
sudo tail -f /var/log/infrastructure-inventory/backend.log
```

---

## Post-Deployment Tasks

### Immediately After Deployment
1. ✅ Change admin password (in Settings page)
2. ✅ Update Nginx config with your domain name
3. ✅ Create new admin users for your team
4. ✅ Configure dropdowns (Asset Types, Departments, Locations)
5. ✅ Verify daily backups are running

### Within 24 Hours
1. ✅ Enable SSL/HTTPS with Certbot
2. ✅ Update DNS to point to your server
3. ✅ Add your team members with appropriate permissions
4. ✅ Configure custom fields for your assets
5. ✅ Start adding your infrastructure

### Weekly
1. ✅ Monitor logs for errors
2. ✅ Check backup completion
3. ✅ Verify system resources
4. ✅ Update npm packages

### Monthly
1. ✅ Update system packages
2. ✅ Review user access
3. ✅ Check database size
4. ✅ Test backup recovery

---

## Useful Commands

### Service Management
```bash
# Start service
sudo systemctl start infra-inventory-backend

# Stop service
sudo systemctl stop infra-inventory-backend

# Restart service
sudo systemctl restart infra-inventory-backend

# View status
sudo systemctl status infra-inventory-backend

# View logs
sudo journalctl -u infra-inventory-backend -f
```

### Application Management
```bash
# Switch to app user
sudo su - infra

# Navigate to backend
cd /opt/infrastructure-inventory/backend

# Update packages
npm update

# Rebuild frontend
cd /opt/infrastructure-inventory/frontend && npm run build
```

### Database Management
```bash
# Connect to database
psql -U infra_user -h localhost -d infrastructure_inventory

# Backup database
pg_dump -U infra_user -h localhost infrastructure_inventory > backup.sql

# Manual backup via script
/opt/infrastructure-inventory/backups/backup.sh
```

### Monitoring & Health
```bash
# Health check
/opt/infrastructure-inventory/scripts/health-check.sh

# Real-time monitoring
/opt/infrastructure-inventory/scripts/monitor.sh

# View recent errors
sudo tail -f /var/log/infrastructure-inventory/backend-error.log
```

---

## Troubleshooting Quick Links

| Issue | Solution |
|-------|----------|
| Backend won't start | Check: `sudo journalctl -u infra-inventory-backend -n 50` |
| Frontend not loading | Verify: `sudo nginx -t` then `sudo systemctl restart nginx` |
| Database connection error | Test: `psql -U infra_user -c "SELECT 1;"` |
| Port already in use | Find: `sudo lsof -i :5000` and kill process |
| Permission denied | Check ownership: `ls -la /opt/infrastructure-inventory/` |
| High memory usage | Restart: `sudo systemctl restart infra-inventory-backend` |

---

## Performance Specifications

| Metric | Target |
|--------|--------|
| API Response Time | < 500ms |
| Frontend Load Time | < 2 seconds |
| Database Connections | Pool max 20 |
| Memory Usage | ~100-200MB |
| Disk Space | ~2GB minimum |
| Backup Time | < 5 minutes |
| Backup Frequency | Daily at 2:00 AM |

---

## Security Checklist

Before going to production, verify:

- ✅ Default admin password changed
- ✅ JWT_SECRET is strong (32+ characters)
- ✅ Database password is strong
- ✅ HTTPS/SSL configured (if public)
- ✅ Firewall properly configured
- ✅ Backups running daily
- ✅ Regular security updates installed
- ✅ User permissions reviewed
- ✅ Log monitoring enabled
- ✅ Backup recovery tested

---

## File Descriptions

### UBUNTU_DEPLOYMENT_GUIDE.md
Complete 12-step deployment guide with:
- Prerequisites verification
- Automated setup option
- Manual step-by-step instructions
- File copying procedures
- Service configuration
- Verification checklist
- Troubleshooting guide

**Time to complete:** 30-45 minutes

### ubuntu-setup.sh
Automated bash script that:
- Updates system packages
- Installs all dependencies
- Creates application user and directories
- Initializes PostgreSQL
- Generates configuration files
- Creates systemd services
- Configures firewall
- Sets up backups

**Time to run:** 15-20 minutes

### UBUNTU_24_04_SETUP.md
Detailed manual setup guide with:
- System prerequisites
- Node.js installation
- PostgreSQL installation
- Nginx installation
- Database configuration
- Complete step-by-step instructions
- Backup setup
- Monitoring setup

**Time to complete:** 45-60 minutes (manual)

### UBUNTU_CONFIG_FILES.md
Configuration templates including:
- Nginx configuration
- Systemd service file
- Health check script
- Monitoring script
- Deployment checklist
- Copy/paste ready configurations

**Reference:** Use as templates for configuration

---

## Getting Started NOW

### 1. Quick Start (Fastest - 15 minutes)
```bash
sudo bash ubuntu-setup.sh localhost
# Then follow remaining steps in UBUNTU_DEPLOYMENT_GUIDE.md (steps 2-12)
```

### 2. Step-by-Step (Recommended - 30 minutes)
```bash
# Follow UBUNTU_DEPLOYMENT_GUIDE.md completely
# All steps clearly numbered and explained
```

### 3. Detailed Manual (Learning - 60 minutes)
```bash
# Follow UBUNTU_24_04_SETUP.md
# Understand each component
# More control over configuration
```

---

## Support Resources

### Documentation
- `UBUNTU_DEPLOYMENT_GUIDE.md` - Your main deployment guide
- `UBUNTU_24_04_SETUP.md` - Detailed reference
- `UBUNTU_CONFIG_FILES.md` - Configuration templates
- `API_DOCUMENTATION.md` - API reference
- `README.md` - Project overview

### Scripts Included
- `ubuntu-setup.sh` - Automated setup
- `health-check.sh` - Health monitoring
- `monitor.sh` - Real-time monitoring
- `backup.sh` - Database backup

### Logs
- `/var/log/infrastructure-inventory/backend.log` - Backend logs
- `/var/log/nginx/error.log` - Nginx errors
- `/var/log/infrastructure-inventory/backup.log` - Backup logs

---

## Success Indicators

Your setup is complete and working when:

✅ You can SSH into the server  
✅ Application accessible at http://your-domain.com  
✅ Login works with admin@infra.local  
✅ Dashboard displays sample data  
✅ You can create/edit/delete assets  
✅ Backend service is running  
✅ Nginx serving frontend  
✅ Database connected  
✅ Daily backups scheduled  
✅ Logs show no errors  

---

## Next Steps

1. **Immediate:** Follow UBUNTU_DEPLOYMENT_GUIDE.md steps 1-7
2. **Short term:** Complete steps 8-12 (Security & verification)
3. **First day:** Change passwords, add users, configure system
4. **First week:** Add your real infrastructure assets

---

## You're Ready!

You have everything needed to deploy the Infrastructure Inventory Management System on Ubuntu 24.04 natively (without Docker).

**Start with:** `UBUNTU_DEPLOYMENT_GUIDE.md`

**Quick automated setup:** `sudo bash ubuntu-setup.sh localhost`

---

**Installation Type:** Ubuntu 24.04 Native (No Docker)  
**Estimated Setup Time:** 15-45 minutes  
**System Requirements:** Ubuntu 24.04 LTS, 2+ CPU, 4GB+ RAM, 20GB+ disk  
**Status:** ✅ Production Ready

---

**Happy Deployment! 🚀**
