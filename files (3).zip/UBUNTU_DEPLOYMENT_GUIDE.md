# Ubuntu 24.04 Complete Deployment - Step-by-Step Guide

## Overview

This guide provides step-by-step instructions to deploy the Infrastructure Inventory Management System on a fresh Ubuntu 24.04 server.

**Estimated Setup Time:** 30-45 minutes

---

## Prerequisites

### Minimum Server Requirements
- OS: Ubuntu 24.04 LTS
- CPU: 2 cores
- RAM: 4GB minimum (8GB recommended)
- Disk: 20GB available space
- Internet: Required for package downloads
- SSH: Access via terminal/putty

### What You'll Have at the End
- Running Node.js backend API
- Served React frontend via Nginx
- PostgreSQL database with sample data
- Automatic daily backups
- SSL-ready (optional HTTPS)
- Production-ready monitoring

---

## STEP 1: Automated System Setup (5 minutes)

### Option A: Use Automated Setup Script (Recommended)

```bash
# Download and run the setup script as root
sudo bash ubuntu-setup.sh localhost

# Wait for completion - the script will:
# ✓ Update system packages
# ✓ Install Node.js 20 LTS
# ✓ Install PostgreSQL 15
# ✓ Install Nginx
# ✓ Create application user 'infra'
# ✓ Create directories and databases
# ✓ Setup systemd services
# ✓ Configure firewall
# ✓ Create backup scripts
```

**After script completes, move to STEP 2.**

---

### Option B: Manual Setup

If you prefer manual setup, follow the detailed instructions in `UBUNTU_24_04_SETUP.md`, Part 1-7.

---

## STEP 2: Copy Application Files (5 minutes)

### Connect to Server
```bash
ssh your-username@your-server-ip
# Or use Putty/Terminal
```

### Copy Files to Server

**From your local machine:**

```bash
# SCP - Copy backend files
scp -r backend_*.js your-username@your-server:/tmp/
scp backend_package.json your-username@your-server:/tmp/backend-package.json
scp backend_env.txt your-username@your-server:/tmp/

# SCP - Copy frontend files
scp -r frontend_*.jsx your-username@your-server:/tmp/
scp frontend_package.json your-username@your-server:/tmp/frontend-package.json
scp frontend_config_files.txt your-username@your-server:/tmp/

# SCP - Copy database schema
scp database_init.sql your-username@your-server:/tmp/
```

**Or copy files manually:**

```bash
# On your server, create the structure
mkdir -p /opt/infrastructure-inventory/backend/config
mkdir -p /opt/infrastructure-inventory/backend/controllers
mkdir -p /opt/infrastructure-inventory/backend/middleware
mkdir -p /opt/infrastructure-inventory/backend/routes

mkdir -p /opt/infrastructure-inventory/frontend/src/pages
mkdir -p /opt/infrastructure-inventory/frontend/src/components
mkdir -p /opt/infrastructure-inventory/frontend/src/context
mkdir -p /opt/infrastructure-inventory/frontend/src/services

# Copy files to appropriate locations
# (Use your preferred method: SCP, Git, SFTP, or manual upload)
```

---

## STEP 3: Setup Backend (10 minutes)

### Install Dependencies
```bash
# Switch to infra user
sudo su - infra

# Navigate to backend
cd /opt/infrastructure-inventory/backend

# Install npm packages
npm install

# This will take 2-3 minutes
# You should see: added XX packages
```

### Verify Installation
```bash
# Check package.json exists
ls -la package.json

# Check node_modules installed
ls -la node_modules | head -20

# Check main files
ls -la *.js
```

### Test Backend
```bash
# Start backend (will run in foreground)
npm start

# Should see:
# ╔════════════════════════════════════════════════════╗
# ║   Infrastructure Inventory Management System       ║
# ║   Server running on: http://localhost:5000         ║
# ║   Environment: production                          ║
# ╚════════════════════════════════════════════════════╝

# In another terminal, test API:
curl http://localhost:5000/api/dashboard/summary

# Should return JSON (might have 401 error, that's ok)

# Stop backend: Press Ctrl+C in the original terminal
```

---

## STEP 4: Initialize Database (5 minutes)

### Copy Database Schema
```bash
# Copy database_init.sql to application directory
cp /tmp/database_init.sql /opt/infrastructure-inventory/

# Change to infra user if not already
sudo su - infra
cd /opt/infrastructure-inventory
```

### Initialize Database
```bash
# Run the initialization script
psql -U infra_user -h localhost -d infrastructure_inventory -f database_init.sql

# Should see no errors
# Tables created successfully
```

### Verify Database
```bash
# Connect to database
psql -U infra_user -h localhost -d infrastructure_inventory

# Run verification queries:
SELECT COUNT(*) FROM users;        -- Should return: 1 (admin user)
SELECT COUNT(*) FROM assets;       -- Should return: 4 (sample assets)
SELECT COUNT(*) FROM asset_types;  -- Should return: 2

# Exit database
\q
```

---

## STEP 5: Setup Frontend (10 minutes)

### Install Dependencies
```bash
# Still as infra user
cd /opt/infrastructure-inventory/frontend

# Install npm packages
npm install

# Takes 2-3 minutes
```

### Build for Production
```bash
# Build the React application
npm run build

# Takes 1-2 minutes
# Creates optimized production build in 'dist/' folder

# Verify build succeeded
ls -la dist/
# Should show: index.html and other files
```

### Verify Frontend Build
```bash
# Check distribution files
ls -la dist/ | head -10

# Should see: index.html, bundle files, etc.
```

---

## STEP 6: Start Services (2 minutes)

### Start Backend Service
```bash
# Exit infra user if in it
exit

# Start backend service
sudo systemctl start infra-inventory-backend

# Enable auto-start
sudo systemctl enable infra-inventory-backend

# Check status
sudo systemctl status infra-inventory-backend

# Should show: active (running)
```

### Verify Backend is Running
```bash
# Check process
ps aux | grep "npm start" | grep -v grep

# Check listening port
sudo netstat -tlnp | grep 5000

# Check logs
sudo tail -f /var/log/infrastructure-inventory/backend.log

# Should show no errors
```

### Verify Nginx is Running
```bash
# Check Nginx status
sudo systemctl status nginx

# Should show: active (running)

# Check Nginx configuration
sudo nginx -t

# Should show: successful
```

---

## STEP 7: Access the Application (2 minutes)

### Get Your Server IP
```bash
# Find your server's IP address
hostname -I
# Or
ip addr show | grep "inet " | grep -v 127.0.0.1
```

### Access in Browser

**Open your browser and go to:**
```
http://your-server-ip
```

**If using domain name:**
```
http://your-domain.com
```

### Login with Default Credentials
```
Username: admin@infra.local
Password: admin123
```

**You should see:**
- ✓ Login page loads
- ✓ Dashboard with sample data
- ✓ 4 sample assets in inventory
- ✓ Charts displaying data

---

## STEP 8: Security & Configuration (5 minutes)

### Change Admin Password (CRITICAL!)
```
1. Login to application
2. Click user menu (top right)
3. Go to Settings
4. Change password immediately
5. Save changes
```

### Update Nginx Configuration
```bash
# Edit Nginx config with your domain
sudo nano /etc/nginx/sites-available/infrastructure-inventory

# Find and replace:
# server_name localhost;
# With:
# server_name your-domain.com www.your-domain.com;

# Save: Ctrl+O, Enter, Ctrl+X

# Test configuration
sudo nginx -t

# Restart Nginx
sudo systemctl restart nginx
```

### Update Frontend .env (Optional)
```bash
# Edit frontend environment
nano /opt/infrastructure-inventory/frontend/.env

# Change:
# VITE_API_URL=http://localhost/api
# To:
# VITE_API_URL=http://your-domain.com/api

# Rebuild if changed:
cd /opt/infrastructure-inventory/frontend
npm run build
```

---

## STEP 9: Setup HTTPS with SSL (Optional but Recommended)

### Install SSL Certificate
```bash
# Stop Nginx temporarily
sudo systemctl stop nginx

# Get certificate from Let's Encrypt
sudo certbot certonly --standalone \
  -d your-domain.com \
  -d www.your-domain.com \
  -n --agree-tos -m your-email@example.com

# Follow prompts if needed
```

### Update Nginx for HTTPS
```bash
# Backup original config
sudo cp /etc/nginx/sites-available/infrastructure-inventory \
        /etc/nginx/sites-available/infrastructure-inventory.backup

# Edit configuration
sudo nano /etc/nginx/sites-available/infrastructure-inventory

# Replace entire file with HTTPS version:
# See UBUNTU_CONFIG_FILES.md for HTTPS Nginx config

# Test configuration
sudo nginx -t

# Start Nginx
sudo systemctl start nginx
```

### Verify HTTPS
```bash
# Access application
https://your-domain.com

# Should show secure connection (green lock)
```

---

## STEP 10: Verification Checklist

### Basic Functionality ✓
```
[ ] Application loads in browser
[ ] Login page displays
[ ] Can login with admin@infra.local
[ ] Dashboard displays statistics
[ ] Asset inventory shows 4 sample assets
[ ] Can view asset details
[ ] Can search assets
[ ] Can filter assets
```

### Backend & Services ✓
```
[ ] Backend service running: sudo systemctl status infra-inventory-backend
[ ] Nginx running: sudo systemctl status nginx
[ ] PostgreSQL running: sudo systemctl status postgresql
[ ] Backend responding: curl http://localhost:5000/api/dashboard/summary
[ ] No errors in backend log: sudo tail /var/log/infrastructure-inventory/backend.log
```

### Database ✓
```
[ ] Database contains sample data
[ ] Users table has admin user
[ ] Assets table has 4 records
[ ] Lookup tables populated
```

### Security ✓
```
[ ] Admin password changed
[ ] HTTPS enabled (if configured)
[ ] Firewall active and ports open
[ ] Database password is strong
[ ] .env files are not world-readable
```

---

## STEP 11: Daily Operations

### Monitoring the System
```bash
# Health check (run anytime)
/opt/infrastructure-inventory/scripts/health-check.sh

# Real-time monitoring
/opt/infrastructure-inventory/scripts/monitor.sh

# View backend logs
sudo journalctl -u infra-inventory-backend -f

# View Nginx logs
sudo tail -f /var/log/nginx/error.log
```

### Restarting Services
```bash
# Restart backend
sudo systemctl restart infra-inventory-backend

# Restart Nginx
sudo systemctl restart nginx

# Restart PostgreSQL
sudo systemctl restart postgresql
```

### Backups
```bash
# Manual backup
/opt/infrastructure-inventory/backups/backup.sh

# Check backup
ls -lah /opt/infrastructure-inventory/backups/

# Automatic backups run daily at 2:00 AM
# Verify in crontab: crontab -l
```

---

## STEP 12: Common Tasks

### Add New User
```bash
# Login to application
# Go to User Management
# Create new user with permissions
```

### Configure Dropdowns
```bash
# Login as admin
# Go to Inventory Configuration
# Add/Edit/Delete dropdown values
```

### Add Assets
```bash
# Go to Asset Inventory
# Click "Add Asset"
# Fill in details
# Click "Add Asset"
```

### Bulk Import Assets
```bash
# Go to Asset Inventory
# Use CSV import template
# Upload file
# Verify import results
```

---

## Troubleshooting

### Backend Won't Start
```bash
# Check logs
sudo journalctl -u infra-inventory-backend -n 50 --no-pager

# Check if port 5000 is in use
sudo lsof -i :5000

# Check database connection
psql -U infra_user -h localhost -d infrastructure_inventory -c "SELECT 1;"

# Restart service
sudo systemctl restart infra-inventory-backend
```

### Frontend Not Loading
```bash
# Check Nginx errors
sudo tail -f /var/log/nginx/error.log

# Check Nginx config
sudo nginx -t

# Verify dist folder exists
ls -la /opt/infrastructure-inventory/frontend/dist/

# Rebuild if needed
cd /opt/infrastructure-inventory/frontend && npm run build
```

### Database Connection Issues
```bash
# Check PostgreSQL running
sudo systemctl status postgresql

# Check database exists
psql -U infra_user -h localhost -c "SELECT datname FROM pg_database;"

# Check credentials in .env
cat /opt/infrastructure-inventory/backend/.env | grep DB_
```

### High Memory Usage
```bash
# Check Node.js process
ps aux | grep node

# Restart service to free memory
sudo systemctl restart infra-inventory-backend

# Check available memory
free -h
```

---

## Performance Optimization

### Monitor Performance
```bash
# Check response times
curl -w "@format.txt" -o /dev/null -s http://localhost/api/dashboard/summary

# Monitor system resources
top

# Check database queries
sudo -u postgres psql -d infrastructure_inventory -c "SELECT query, calls, total_time FROM pg_stat_statements ORDER BY total_time DESC LIMIT 10;"
```

### Optimization Tips
1. Ensure backups don't run during peak hours
2. Monitor disk space regularly
3. Archive old logs monthly
4. Update Node.js packages quarterly
5. Review and optimize slow database queries

---

## Maintenance Schedule

### Daily
- Check service status
- Verify backups completed
- Monitor error logs

### Weekly
- Review system resources
- Check disk usage
- Update npm packages: `npm update`

### Monthly
- Update system packages: `sudo apt update && sudo apt upgrade`
- Test backup recovery
- Review database size
- Audit user accounts

### Quarterly
- Major version updates
- Security audit
- Performance review
- Capacity planning

---

## Important Files & Paths

```
Application: /opt/infrastructure-inventory/
  ├── backend/               - Node.js API
  ├── frontend/dist/         - React build
  ├── uploads/               - File uploads
  ├── backups/               - Database backups
  └── scripts/               - Utility scripts

Configuration:
  ├── /etc/nginx/sites-available/infrastructure-inventory
  ├── /etc/systemd/system/infra-inventory-backend.service
  ├── /opt/infrastructure-inventory/backend/.env
  └── /opt/infrastructure-inventory/frontend/.env

Logs:
  ├── /var/log/infrastructure-inventory/backend.log
  ├── /var/log/infrastructure-inventory/backend-error.log
  ├── /var/log/nginx/access.log
  └── /var/log/nginx/error.log

Database:
  └── infrastructure_inventory (PostgreSQL)
```

---

## Support & Resources

- **Setup Guide:** UBUNTU_24_04_SETUP.md
- **Configuration Files:** UBUNTU_CONFIG_FILES.md
- **API Reference:** API_DOCUMENTATION.md
- **Project Overview:** README.md

---

## Success! 🎉

Your Infrastructure Inventory Management System is now:
- ✅ Running on Ubuntu 24.04
- ✅ Served via Nginx
- ✅ Backed by PostgreSQL
- ✅ Auto-starting on reboot
- ✅ Backing up daily
- ✅ Production-ready
- ✅ Ready for your infrastructure!

**Next:** Start adding your actual infrastructure assets and team members!

---

**Installation Completed Successfully!**

Date: [Your Date]
Domain: [Your Domain]
Admin User: admin@infra.local

Remember: **Change the admin password immediately!**
