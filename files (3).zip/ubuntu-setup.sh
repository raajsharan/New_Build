#!/bin/bash

# Infrastructure Inventory Management System - Ubuntu 24.04 Automated Setup Script
# Run this script as root or with sudo to automatically setup the entire application

set -e  # Exit on any error

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
APP_USER="infra"
APP_DIR="/opt/infrastructure-inventory"
DB_USER="infra_user"
DB_NAME="infrastructure_inventory"
DB_PASSWORD="secure_database_password_change_me"
NODE_VERSION="20"
DOMAIN_NAME="${1:-localhost}"

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}Infrastructure Inventory Setup Script${NC}"
echo -e "${BLUE}Ubuntu 24.04 LTS${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Function to print section headers
print_section() {
    echo ""
    echo -e "${BLUE}>>> $1${NC}"
    echo ""
}

# Function to print success
print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

# Function to print error
print_error() {
    echo -e "${RED}✗ $1${NC}"
}

# Function to print warning
print_warning() {
    echo -e "${YELLOW}! $1${NC}"
}

# Check if running as root
if [[ $EUID -ne 0 ]]; then
    print_error "This script must be run as root (use sudo)"
    exit 1
fi

# Step 1: Update System
print_section "Step 1: Updating System Packages"
apt update
apt upgrade -y
apt install -y curl wget git build-essential ufw
print_success "System updated"

# Step 2: Install Node.js
print_section "Step 2: Installing Node.js $NODE_VERSION LTS"
if command -v node &> /dev/null; then
    print_warning "Node.js already installed: $(node --version)"
else
    curl -fsSL https://deb.nodesource.com/setup_${NODE_VERSION}.x | bash -
    apt install -y nodejs
    print_success "Node.js installed: $(node --version)"
fi

# Step 3: Install PostgreSQL
print_section "Step 3: Installing PostgreSQL 15"
if command -v psql &> /dev/null; then
    print_warning "PostgreSQL already installed: $(psql --version)"
else
    sh -c 'echo "deb http://apt.postgresql.org/pub/repos/apt $(lsb_release -cs)-pgdg main" > /etc/apt/sources.list.d/pgdg.list'
    wget --quiet -O - https://www.postgresql.org/media/keys/ACCC4CF8.asc | apt-key add -
    apt update
    apt install -y postgresql-15 postgresql-contrib-15
    systemctl start postgresql
    systemctl enable postgresql
    print_success "PostgreSQL installed and started"
fi

# Step 4: Install Nginx
print_section "Step 4: Installing Nginx"
if command -v nginx &> /dev/null; then
    print_warning "Nginx already installed"
else
    apt install -y nginx
    systemctl start nginx
    systemctl enable nginx
    print_success "Nginx installed and started"
fi

# Step 5: Install Certbot (Optional SSL)
print_section "Step 5: Installing Certbot for SSL"
apt install -y certbot python3-certbot-nginx
print_success "Certbot installed"

# Step 6: Create Application User
print_section "Step 6: Creating Application User"
if id "$APP_USER" &>/dev/null; then
    print_warning "User $APP_USER already exists"
else
    useradd -m -s /bin/bash $APP_USER
    usermod -aG sudo $APP_USER
    print_success "User $APP_USER created"
fi

# Step 7: Create Application Directories
print_section "Step 7: Creating Application Directories"
mkdir -p $APP_DIR/backend
mkdir -p $APP_DIR/frontend
mkdir -p $APP_DIR/uploads
mkdir -p $APP_DIR/backups
mkdir -p /var/log/infrastructure-inventory

chown -R $APP_USER:$APP_USER $APP_DIR
chown -R $APP_USER:$APP_USER /var/log/infrastructure-inventory
chmod 755 $APP_DIR

print_success "Directories created at $APP_DIR"

# Step 8: Create PostgreSQL User and Database
print_section "Step 8: Setting up PostgreSQL Database"
sudo -u postgres psql << PSQL_COMMANDS
CREATE ROLE $DB_USER WITH PASSWORD '$DB_PASSWORD' LOGIN CREATEDB;
CREATE DATABASE $DB_NAME OWNER $DB_USER;
GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;
PSQL_COMMANDS
print_success "Database $DB_NAME created"

# Step 9: Create Environment Files
print_section "Step 9: Creating Environment Files"

# Backend .env
cat > $APP_DIR/backend/.env << EOF
DB_HOST=localhost
DB_PORT=5432
DB_USER=$DB_USER
DB_PASSWORD=$DB_PASSWORD
DB_NAME=$DB_NAME

PORT=5000
NODE_ENV=production
FRONTEND_URL=http://$DOMAIN_NAME

JWT_SECRET=$(openssl rand -base64 32)

MAX_FILE_SIZE=50000000
UPLOAD_DIR=./uploads

CORS_ORIGIN=http://$DOMAIN_NAME
EOF

# Frontend .env
cat > $APP_DIR/frontend/.env << EOF
VITE_API_URL=http://$DOMAIN_NAME/api
EOF

chown $APP_USER:$APP_USER $APP_DIR/backend/.env
chown $APP_USER:$APP_USER $APP_DIR/frontend/.env
chmod 600 $APP_DIR/backend/.env

print_success "Environment files created"

# Step 10: Setup Systemd Service for Backend
print_section "Step 10: Creating Systemd Service"

cat > /etc/systemd/system/infra-inventory-backend.service << 'EOF'
[Unit]
Description=Infrastructure Inventory Backend API
After=network.target postgresql.service

[Service]
Type=simple
User=infra
WorkingDirectory=/opt/infrastructure-inventory/backend
ExecStart=/usr/bin/npm start
Restart=always
RestartSec=10
StandardOutput=append:/var/log/infrastructure-inventory/backend.log
StandardError=append:/var/log/infrastructure-inventory/backend-error.log
Environment="NODE_ENV=production"

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
print_success "Systemd service created"

# Step 11: Setup Nginx Configuration
print_section "Step 11: Configuring Nginx"

cat > /etc/nginx/sites-available/infrastructure-inventory << EOF
upstream backend {
    server localhost:5000;
}

server {
    listen 80;
    server_name $DOMAIN_NAME www.$DOMAIN_NAME;

    gzip on;
    gzip_types text/plain text/css text/xml text/javascript application/x-javascript application/json;
    gzip_vary on;
    gzip_comp_level 6;

    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;

    client_max_body_size 50M;

    location / {
        root /opt/infrastructure-inventory/frontend/dist;
        try_files \$uri \$uri/ /index.html;
        expires 1d;
        add_header Cache-Control "public, immutable";
    }

    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)\$ {
        root /opt/infrastructure-inventory/frontend/dist;
        expires 30d;
        add_header Cache-Control "public, immutable";
    }

    location /api/ {
        proxy_pass http://backend;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_read_timeout 60s;
    }

    location ~ /\. {
        deny all;
    }
}
EOF

ln -sf /etc/nginx/sites-available/infrastructure-inventory /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

nginx -t
systemctl restart nginx
print_success "Nginx configured"

# Step 12: Setup Firewall
print_section "Step 12: Configuring Firewall"
ufw enable -y
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
print_success "Firewall configured"

# Step 13: Create Backup Script
print_section "Step 13: Creating Backup Script"

cat > $APP_DIR/backups/backup.sh << 'EOF'
#!/bin/bash

BACKUP_DIR="/opt/infrastructure-inventory/backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="$BACKUP_DIR/infrastructure_inventory_$TIMESTAMP.sql"

pg_dump -U infra_user -h localhost infrastructure_inventory > "$BACKUP_FILE"
gzip "$BACKUP_FILE"

find "$BACKUP_DIR" -name "*.sql.gz" -mtime +30 -delete

echo "$(date): Backup created: $BACKUP_FILE.gz" >> "$BACKUP_DIR/backup.log"
EOF

chmod +x $APP_DIR/backups/backup.sh
chown $APP_USER:$APP_USER $APP_DIR/backups/backup.sh

# Add to crontab for daily backups at 2:00 AM
(crontab -l 2>/dev/null | grep -v "infrastructure"; echo "0 2 * * * $APP_DIR/backups/backup.sh") | crontab -
print_success "Backup script created and scheduled"

# Step 14: Setup Log Rotation
print_section "Step 14: Setting up Log Rotation"

cat > /etc/logrotate.d/infrastructure-inventory << EOF
/var/log/infrastructure-inventory/*.log {
    daily
    rotate 14
    compress
    delaycompress
    missingok
    notifempty
    create 0640 infra infra
    sharedscripts
    postrotate
        systemctl reload infra-inventory-backend > /dev/null 2>&1 || true
    endscript
}
EOF

print_success "Log rotation configured"

# Step 15: Create Installation Instructions
print_section "Step 15: Creating Setup Instructions"

cat > $APP_DIR/SETUP_INSTRUCTIONS.txt << 'SETUP_EOF'
=================================================================
Infrastructure Inventory Management System - Setup Instructions
=================================================================

Automated Setup Complete!

Next Steps:

1. COPY APPLICATION FILES
   - Copy all backend files to: /opt/infrastructure-inventory/backend/
   - Copy all frontend files to: /opt/infrastructure-inventory/frontend/
   
   Files needed:
   Backend:
     - server.js
     - package.json (rename from backend_package.json)
     - config/database.js
     - controllers/* (all controller files)
     - middleware/auth.js
     - routes/* (all route files)
     
   Frontend:
     - src/* (all source files)
     - package.json (rename from frontend_package.json)
     - vite.config.js
     - tailwind.config.js
     - postcss.config.js
     - index.html

2. INITIALIZE DATABASE
   - Copy database_init.sql to: /opt/infrastructure-inventory/
   - Run: psql -U infra_user -h localhost -d infrastructure_inventory -f database_init.sql

3. INSTALL DEPENDENCIES
   cd /opt/infrastructure-inventory/backend
   npm install
   
   cd /opt/infrastructure-inventory/frontend
   npm install

4. BUILD FRONTEND
   cd /opt/infrastructure-inventory/frontend
   npm run build

5. START BACKEND SERVICE
   sudo systemctl start infra-inventory-backend
   sudo systemctl status infra-inventory-backend

6. VERIFY SETUP
   curl http://localhost/api/dashboard/summary
   curl http://localhost/
   
   Open browser: http://your-domain.com
   Login: admin@infra.local / admin123

7. IMPORTANT: CHANGE DEFAULT PASSWORD
   Login and immediately change the admin password!

8. ENABLE HTTPS (Optional but Recommended)
   sudo certbot --nginx -d your-domain.com

Useful Commands:
- View backend logs: sudo journalctl -u infra-inventory-backend -f
- Restart backend: sudo systemctl restart infra-inventory-backend
- View Nginx logs: sudo tail -f /var/log/nginx/error.log
- Backup database: /opt/infrastructure-inventory/backups/backup.sh
- Connect to database: psql -U infra_user -h localhost -d infrastructure_inventory

Configuration Files:
- Backend .env: /opt/infrastructure-inventory/backend/.env
- Frontend .env: /opt/infrastructure-inventory/frontend/.env
- Nginx config: /etc/nginx/sites-available/infrastructure-inventory
- Database password: Check /opt/infrastructure-inventory/backend/.env
SETUP_EOF

cat > $APP_DIR/SETUP_INSTRUCTIONS.txt

print_success "Setup instructions created"

# Print Summary
print_section "INSTALLATION COMPLETE!"

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}Installation Summary${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo -e "Application User: ${YELLOW}$APP_USER${NC}"
echo -e "Application Directory: ${YELLOW}$APP_DIR${NC}"
echo -e "Database Name: ${YELLOW}$DB_NAME${NC}"
echo -e "Database User: ${YELLOW}$DB_USER${NC}"
echo -e "Backend Port: ${YELLOW}5000${NC}"
echo -e "Web Server: ${YELLOW}Nginx (Port 80/443)${NC}"
echo -e "Domain: ${YELLOW}$DOMAIN_NAME${NC}"
echo ""
echo -e "${BLUE}Next Steps:${NC}"
echo ""
echo "1. Copy application files to $APP_DIR"
echo "   - Backend files to: $APP_DIR/backend/"
echo "   - Frontend files to: $APP_DIR/frontend/"
echo ""
echo "2. Initialize database:"
echo "   psql -U infra_user -h localhost -d infrastructure_inventory -f database_init.sql"
echo ""
echo "3. Install dependencies:"
echo "   cd $APP_DIR/backend && npm install"
echo "   cd $APP_DIR/frontend && npm install"
echo ""
echo "4. Build frontend:"
echo "   cd $APP_DIR/frontend && npm run build"
echo ""
echo "5. Start backend service:"
echo "   sudo systemctl start infra-inventory-backend"
echo ""
echo "6. Access application:"
echo "   http://$DOMAIN_NAME"
echo ""
echo "   Default Login:"
echo "   Username: admin@infra.local"
echo "   Password: admin123"
echo ""
echo -e "${RED}IMPORTANT: Change the admin password immediately after first login!${NC}"
echo ""
echo "For detailed instructions, see: $APP_DIR/SETUP_INSTRUCTIONS.txt"
echo ""

print_success "Setup script completed successfully!"
