# Standalone Configuration Files for Ubuntu 24.04

## File 1: /etc/nginx/sites-available/infrastructure-inventory

upstream backend {
    server localhost:5000;
    keepalive 32;
}

server {
    listen 80;
    listen [::]:80;
    server_name your-domain.com www.your-domain.com;

    # Redirect to HTTPS if you have SSL
    # return 301 https://$server_name$request_uri;

    # Gzip compression
    gzip on;
    gzip_types text/plain text/css text/xml text/javascript 
               application/x-javascript application/xml+rss application/json;
    gzip_vary on;
    gzip_comp_level 6;
    gzip_min_length 1000;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    add_header Permissions-Policy "geolocation=(), microphone=(), camera=()" always;

    # Increase body size for file uploads
    client_max_body_size 50M;
    client_body_buffer_size 10M;

    # Timeouts
    keepalive_timeout 65;
    proxy_connect_timeout 60s;
    proxy_send_timeout 60s;
    proxy_read_timeout 60s;

    # Frontend static files
    location / {
        root /opt/infrastructure-inventory/frontend/dist;
        try_files $uri $uri/ /index.html;
        expires 1d;
        add_header Cache-Control "public, immutable";
        add_header ETag "$file_mtime";
    }

    # Cache busting for versioned assets
    location ~* \.(js|css)$ {
        root /opt/infrastructure-inventory/frontend/dist;
        expires 30d;
        add_header Cache-Control "public, immutable";
    }

    # Images and fonts
    location ~* \.(png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        root /opt/infrastructure-inventory/frontend/dist;
        expires 30d;
        add_header Cache-Control "public, immutable";
        access_log off;
    }

    # API proxy to backend
    location /api/ {
        proxy_pass http://backend;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-Host $server_name;
        proxy_cache_bypass $http_upgrade;
        
        # Disable buffering for streaming responses
        proxy_buffering off;
        proxy_request_buffering off;
    }

    # Health check endpoint
    location /health {
        access_log off;
        proxy_pass http://backend;
        proxy_http_version 1.1;
    }

    # Deny access to hidden files
    location ~ /\. {
        deny all;
        access_log off;
        log_not_found off;
    }

    # Deny access to specific files
    location ~ /\.env {
        deny all;
    }

    location ~ /\.git {
        deny all;
    }

    # Custom error pages
    error_page 502 503 504 /50x.html;
    location = /50x.html {
        root /usr/share/nginx/html;
    }
}

---

## File 2: /etc/systemd/system/infra-inventory-backend.service

[Unit]
Description=Infrastructure Inventory Backend API
After=network.target postgresql.service
Wants=postgresql.service

[Service]
Type=simple
User=infra
Group=infra
WorkingDirectory=/opt/infrastructure-inventory/backend

# Restart policy
Restart=always
RestartSec=10
StartLimitInterval=60s
StartLimitBurst=3

# Process management
StandardOutput=append:/var/log/infrastructure-inventory/backend.log
StandardError=append:/var/log/infrastructure-inventory/backend-error.log
SyslogIdentifier=infra-backend

# Environment
Environment="NODE_ENV=production"
Environment="NODE_OPTIONS=--max_old_space_size=512"

# Execution
ExecStart=/usr/bin/npm start

# Security
NoNewPrivileges=true
ProtectSystem=full
ProtectHome=yes
ReadWritePaths=/opt/infrastructure-inventory/backend/uploads

# Resource limits
LimitNOFILE=65535
LimitNPROC=2048

[Install]
WantedBy=multi-user.target

---

## File 3: Health Check Script (/opt/infrastructure-inventory/scripts/health-check.sh)

#!/bin/bash

# Health Check Script for Infrastructure Inventory System
# Run: /opt/infrastructure-inventory/scripts/health-check.sh

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo "Infrastructure Inventory - Health Check"
echo "========================================"
echo ""

# Check Backend Service
echo -n "Backend Service: "
if sudo systemctl is-active --quiet infra-inventory-backend; then
    echo -e "${GREEN}✓ Running${NC}"
else
    echo -e "${RED}✗ Not Running${NC}"
fi

# Check Nginx
echo -n "Nginx Service: "
if sudo systemctl is-active --quiet nginx; then
    echo -e "${GREEN}✓ Running${NC}"
else
    echo -e "${RED}✗ Not Running${NC}"
fi

# Check PostgreSQL
echo -n "PostgreSQL Service: "
if sudo systemctl is-active --quiet postgresql; then
    echo -e "${GREEN}✓ Running${NC}"
else
    echo -e "${RED}✗ Not Running${NC}"
fi

# Check Backend API
echo -n "Backend API: "
if curl -s http://localhost:5000/api/dashboard/summary > /dev/null 2>&1; then
    echo -e "${GREEN}✓ Responding${NC}"
else
    echo -e "${RED}✗ Not Responding${NC}"
fi

# Check Frontend
echo -n "Frontend: "
if curl -s http://localhost/ > /dev/null 2>&1; then
    echo -e "${GREEN}✓ Accessible${NC}"
else
    echo -e "${RED}✗ Not Accessible${NC}"
fi

# Check Database Connection
echo -n "Database Connection: "
if sudo -u postgres psql -c "SELECT 1" > /dev/null 2>&1; then
    echo -e "${GREEN}✓ Connected${NC}"
else
    echo -e "${RED}✗ Not Connected${NC}"
fi

# Check Disk Space
echo ""
echo "Disk Usage:"
df -h /opt/infrastructure-inventory | tail -1

# Check Memory Usage
echo ""
echo "Memory Usage:"
free -h | grep Mem

# Check Running Processes
echo ""
echo "Node.js Processes:"
ps aux | grep "node" | grep -v grep | wc -l

# Recent Errors
echo ""
echo "Recent Errors (Last 10):"
sudo tail -n 10 /var/log/infrastructure-inventory/backend-error.log 2>/dev/null || echo "No errors found"

---

## File 4: Monitoring Script (/opt/infrastructure-inventory/scripts/monitor.sh)

#!/bin/bash

# Real-time Monitoring Script
# Run: /opt/infrastructure-inventory/scripts/monitor.sh

while true; do
    clear
    
    echo "Infrastructure Inventory - Real-time Monitor"
    echo "=============================================="
    echo ""
    
    # System Stats
    echo "System Stats:"
    echo "  Uptime: $(uptime | awk -F'up' '{print $2}' | awk -F',' '{print $1}')"
    echo "  Load Average: $(cat /proc/loadavg | awk '{print $1, $2, $3}')"
    echo ""
    
    # Memory
    echo "Memory:"
    free -h | grep Mem | awk '{print "  Total: " $2 ", Used: " $3 ", Free: " $4}'
    echo ""
    
    # Disk
    echo "Disk:"
    df -h /opt/infrastructure-inventory | tail -1 | awk '{print "  Used: " $3 ", Available: " $4 ", Usage: " $5}'
    echo ""
    
    # Services
    echo "Services:"
    echo -n "  Backend: "
    if sudo systemctl is-active --quiet infra-inventory-backend; then
        echo "✓ Running"
    else
        echo "✗ Stopped"
    fi
    
    echo -n "  Nginx: "
    if sudo systemctl is-active --quiet nginx; then
        echo "✓ Running"
    else
        echo "✗ Stopped"
    fi
    
    echo -n "  PostgreSQL: "
    if sudo systemctl is-active --quiet postgresql; then
        echo "✓ Running"
    else
        echo "✗ Stopped"
    fi
    echo ""
    
    # Node.js Memory Usage
    echo "Backend Process:"
    ps aux | grep "node" | grep -v grep | awk '{print "  PID: " $2 ", Memory: " $6 "K, CPU: " $3 "%"}'
    echo ""
    
    # Recent Logs
    echo "Recent Backend Logs:"
    sudo tail -n 5 /var/log/infrastructure-inventory/backend.log | sed 's/^/  /'
    echo ""
    
    echo "Press Ctrl+C to exit, refreshing every 5 seconds..."
    sleep 5
done

---

## File 5: Deployment Checklist (/opt/infrastructure-inventory/DEPLOYMENT_CHECKLIST.txt)

Infrastructure Inventory - Ubuntu 24.04 Deployment Checklist

PRE-DEPLOYMENT:
[ ] System Requirements Met
    [ ] Ubuntu 24.04 LTS
    [ ] 4GB+ RAM available
    [ ] 20GB+ disk space
    [ ] Internet connectivity

[ ] Prerequisites Installed
    [ ] Node.js 20+ LTS
    [ ] PostgreSQL 15
    [ ] Nginx
    [ ] Certbot (for SSL)

[ ] Application User Created
    [ ] User: infra
    [ ] Home directory: /home/infra
    [ ] Application directory: /opt/infrastructure-inventory

[ ] Database Configured
    [ ] PostgreSQL running
    [ ] Database: infrastructure_inventory
    [ ] User: infra_user
    [ ] Privileges granted
    [ ] Schema initialized

DEPLOYMENT:
[ ] Backend Setup
    [ ] Files copied to /opt/infrastructure-inventory/backend/
    [ ] package.json in place
    [ ] npm install completed
    [ ] .env file configured
    [ ] Database connection verified

[ ] Frontend Setup
    [ ] Files copied to /opt/infrastructure-inventory/frontend/
    [ ] package.json in place
    [ ] npm install completed
    [ ] .env file configured
    [ ] npm run build completed
    [ ] dist/ folder generated

[ ] Services Configured
    [ ] Systemd service created
    [ ] Nginx configuration in place
    [ ] Symlink created in sites-enabled/
    [ ] Nginx configuration tested
    [ ] Services enabled

[ ] Services Started
    [ ] Backend service started
    [ ] Nginx service started
    [ ] PostgreSQL running
    [ ] Services set to auto-start

[ ] Security Configured
    [ ] Firewall enabled
    [ ] Ports 22, 80, 443 allowed
    [ ] HTTPS/SSL configured (optional)
    [ ] .env files permissions set (600)
    [ ] Database password changed

POST-DEPLOYMENT:
[ ] Functionality Testing
    [ ] Backend API responding
    [ ] Frontend loading
    [ ] Login page accessible
    [ ] Default credentials work
    [ ] Can create asset
    [ ] Can edit asset
    [ ] Can delete asset
    [ ] Dashboard displaying data

[ ] Security Verification
    [ ] HTTPS working (if configured)
    [ ] Security headers present
    [ ] Gzip compression enabled
    [ ] Cache headers correct
    [ ] No debug info in responses

[ ] Performance Verification
    [ ] API response time < 500ms
    [ ] Frontend loading < 2 seconds
    [ ] No errors in logs
    [ ] Memory usage acceptable
    [ ] Disk space adequate

[ ] Monitoring & Backups
    [ ] Log rotation configured
    [ ] Backup script created
    [ ] Backup scheduled (daily)
    [ ] Backup tested
    [ ] Monitoring setup
    [ ] Health checks configured

[ ] Documentation & Handover
    [ ] Setup instructions documented
    [ ] Admin credentials secured
    [ ] Backup procedures documented
    [ ] Support contacts listed
    [ ] Runbooks created
    [ ] Training completed

ONGOING MAINTENANCE:
[ ] Daily
    [ ] Check backend service running
    [ ] Monitor logs for errors
    [ ] Verify backups completed

[ ] Weekly
    [ ] Review system resources
    [ ] Check disk usage
    [ ] Update Node.js packages
    [ ] Review security logs

[ ] Monthly
    [ ] Update system packages
    [ ] Audit user accounts
    [ ] Review database size
    [ ] Test backup recovery

[ ] Quarterly
    [ ] Major version updates
    [ ] Security audit
    [ ] Performance review
    [ ] Capacity planning

---

## Installation Instructions for These Files

1. Copy Nginx configuration:
   sudo cp infrastructure-inventory /etc/nginx/sites-available/
   sudo ln -s /etc/nginx/sites-available/infrastructure-inventory /etc/nginx/sites-enabled/
   sudo nginx -t
   sudo systemctl restart nginx

2. Copy Systemd service:
   sudo cp infra-inventory-backend.service /etc/systemd/system/
   sudo systemctl daemon-reload
   sudo systemctl enable infra-inventory-backend

3. Copy scripts:
   mkdir -p /opt/infrastructure-inventory/scripts
   cp health-check.sh /opt/infrastructure-inventory/scripts/
   cp monitor.sh /opt/infrastructure-inventory/scripts/
   chmod +x /opt/infrastructure-inventory/scripts/*.sh

4. Edit and verify:
   - Replace your-domain.com with your actual domain in Nginx config
   - Verify paths match your installation
   - Test all configurations before deployment
