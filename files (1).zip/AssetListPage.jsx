import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../context/AuthContext';
import { useAuth } from '../context/AuthContext';
import { useSettings } from '../context/SettingsContext';
import { useDropdowns } from '../utils/useDropdowns';
import { Search, Edit2, Trash2, Upload, Download, Eye, EyeOff, ChevronLeft, ChevronRight, Filter, X } from 'lucide-react';
import toast from 'react-hot-toast';

function StatusBadge({ name }) {
  if (!name) return <span className="badge-default">—</span>;
  if (name === 'Alive') return <span className="badge-alive"><span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block" />{name}</span>;
  if (name === 'Powered Off') return <span className="badge-off"><span className="w-1.5 h-1.5 rounded-full bg-amber-400 inline-block" />{name}</span>;
  if (name.includes('Not') || name === 'Decommissioned') return <span className="badge-dead"><span className="w-1.5 h-1.5 rounded-full bg-red-400 inline-block" />{name}</span>;
  return <span className="badge-default">{name}</span>;
}

function BoolBadge({ value }) {
  return value
    ? <span className="badge-alive">Yes</span>
    : <span className="text-xs text-slate-600">No</span>;
}

export default function AssetListPage() {
  const { canWrite, isAdmin } = useAuth();
  const { settings } = useSettings();
  const navigate = useNavigate();
  const { dropdowns } = useDropdowns();
  const fileRef = useRef();

  const [assets, setAssets] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [showPasswords, setShowPasswords] = useState(false);
  const [revealedPasswords, setRevealedPasswords] = useState({});
  const pwVisible = settings.password_visibility_enabled === 'true';

  const [filters, setFilters] = useState({
    search: '', location_id: '', department_id: '', server_status_id: '', asset_type_id: ''
  });
  const [showFilters, setShowFilters] = useState(false);
  const LIMIT = 20;

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page, limit: LIMIT });
      Object.entries(filters).forEach(([k, v]) => { if (v) params.append(k, v); });
      const res = await api.get(`/assets?${params}`);
      setAssets(res.data.assets);
      setTotal(res.data.total);
    } catch { toast.error('Failed to load assets'); }
    finally { setLoading(false); }
  }, [page, filters]);

  useEffect(() => { load(); }, [load]);

  const handleDelete = async (id, name) => {
    if (!window.confirm(`Delete "${name}"?`)) return;
    try {
      await api.delete(`/assets/${id}`);
      toast.success('Asset deleted');
      load();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Delete failed');
    }
  };

  const handleCsvImport = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const formData = new FormData();
    formData.append('file', file);
    try {
      const res = await api.post('/assets/import/csv', formData, { headers: { 'Content-Type': 'multipart/form-data' } });
      toast.success(`Imported ${res.data.inserted} of ${res.data.total} assets`);
      if (res.data.errors?.length) toast.error(`${res.data.errors.length} rows failed`);
      load();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Import failed');
    }
    e.target.value = '';
  };

  const handleDownloadTemplate = () => {
    window.location.href = '/api/assets/template/csv';
  };

  const togglePasswordReveal = (id) => {
    setRevealedPasswords(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const totalPages = Math.ceil(total / LIMIT);

  const setFilter = (k, v) => { setFilters(f => ({ ...f, [k]: v })); setPage(1); };
  const clearFilters = () => { setFilters({ search: '', location_id: '', department_id: '', server_status_id: '', asset_type_id: '' }); setPage(1); };
  const hasFilters = Object.values(filters).some(Boolean);

  return (
    <div className="space-y-4 fade-in">
      <div className="page-header">
        <div>
          <h1 className="page-title">Asset Inventory</h1>
          <p className="text-sm text-slate-500 mt-0.5">{total} total assets</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {canWrite && (
            <>
              <button onClick={handleDownloadTemplate} className="btn-secondary text-xs">
                <Download className="w-3.5 h-3.5" /> CSV Template
              </button>
              <button onClick={() => fileRef.current?.click()} className="btn-secondary text-xs">
                <Upload className="w-3.5 h-3.5" /> Import CSV
              </button>
              <input ref={fileRef} type="file" accept=".csv" className="hidden" onChange={handleCsvImport} />
            </>
          )}
          {canWrite && (
            <button onClick={() => navigate('/add-asset')} className="btn-primary text-xs">
              + Add Asset
            </button>
          )}
        </div>
      </div>

      {/* Search & Filters */}
      <div className="card space-y-3">
        <div className="flex items-center gap-2">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input
              className="form-input pl-9"
              placeholder="Search hostname, IP, VM name, user..."
              value={filters.search}
              onChange={e => setFilter('search', e.target.value)}
            />
          </div>
          <button onClick={() => setShowFilters(s => !s)} className={`btn-secondary text-xs ${showFilters ? 'bg-blue-600/20 text-blue-400 border-blue-500/30' : ''}`}>
            <Filter className="w-3.5 h-3.5" /> Filters {hasFilters && '•'}
          </button>
          {hasFilters && (
            <button onClick={clearFilters} className="text-xs text-slate-400 hover:text-white flex items-center gap-1">
              <X className="w-3.5 h-3.5" /> Clear
            </button>
          )}
          {pwVisible && (
            <button onClick={() => setShowPasswords(s => !s)} className="btn-secondary text-xs ml-auto">
              {showPasswords ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              {showPasswords ? 'Hide' : 'Show'} Passwords
            </button>
          )}
        </div>

        {showFilters && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 border-t border-slate-800">
            <div>
              <label className="form-label">Location</label>
              <select className="form-select text-xs" value={filters.location_id} onChange={e => setFilter('location_id', e.target.value)}>
                <option value="">All Locations</option>
                {dropdowns.locations?.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}
              </select>
            </div>
            <div>
              <label className="form-label">Department</label>
              <select className="form-select text-xs" value={filters.department_id} onChange={e => setFilter('department_id', e.target.value)}>
                <option value="">All Departments</option>
                {dropdowns.departments?.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}
              </select>
            </div>
            <div>
              <label className="form-label">Status</label>
              <select className="form-select text-xs" value={filters.server_status_id} onChange={e => setFilter('server_status_id', e.target.value)}>
                <option value="">All Statuses</option>
                {dropdowns.server_status?.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}
              </select>
            </div>
            <div>
              <label className="form-label">Asset Type</label>
              <select className="form-select text-xs" value={filters.asset_type_id} onChange={e => setFilter('asset_type_id', e.target.value)}>
                <option value="">All Types</option>
                {dropdowns.asset_types?.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}
              </select>
            </div>
          </div>
        )}
      </div>

      {/* Table */}
      <div className="card p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-800/50 border-b border-slate-800">
              <tr>
                {['VM Name','Hostname','IP Address','Type','OS','Version','User','Dept','Status','ME','Tenable','Patching','Location','EOL','Username','Password','Actions']
                  .map(h => <th key={h} className="table-th">{h}</th>)}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {loading ? (
                <tr><td colSpan={17} className="text-center py-12 text-slate-500">Loading...</td></tr>
              ) : assets.length === 0 ? (
                <tr><td colSpan={17} className="text-center py-12 text-slate-500">No assets found</td></tr>
              ) : assets.map(a => (
                <tr key={a.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="table-td font-mono text-xs text-blue-400">{a.vm_name || '—'}</td>
                  <td className="table-td font-mono text-xs">{a.os_hostname || '—'}</td>
                  <td className="table-td font-mono text-xs text-slate-400">{a.ip_address || '—'}</td>
                  <td className="table-td"><span className="badge-default text-xs">{a.asset_type_name || '—'}</span></td>
                  <td className="table-td text-xs">{a.os_type_name || '—'}</td>
                  <td className="table-td text-xs text-slate-400 max-w-[120px] truncate">{a.os_version_name || '—'}</td>
                  <td className="table-td text-xs">{a.assigned_user || '—'}</td>
                  <td className="table-td text-xs">{a.department_name || '—'}</td>
                  <td className="table-td"><StatusBadge name={a.server_status_name} /></td>
                  <td className="table-td"><BoolBadge value={a.me_installed_status} /></td>
                  <td className="table-td"><BoolBadge value={a.tenable_installed_status} /></td>
                  <td className="table-td text-xs">{a.patching_type_name || '—'}</td>
                  <td className="table-td text-xs">{a.location_name || '—'}</td>
                  <td className="table-td">
                    {a.eol_status_name ? (
                      <span className={`text-xs px-1.5 py-0.5 rounded ${a.eol_status_name === 'InSupport' ? 'text-emerald-400' : a.eol_status_name === 'EOL' ? 'text-amber-400' : 'text-red-400'}`}>
                        {a.eol_status_name}
                      </span>
                    ) : '—'}
                  </td>
                  <td className="table-td text-xs font-mono">{a.asset_username || '—'}</td>
                  <td className="table-td">
                    {pwVisible && a.asset_password ? (
                      <div className="flex items-center gap-1">
                        <span className="font-mono text-xs">
                          {(showPasswords || revealedPasswords[a.id]) ? a.asset_password : '••••••••'}
                        </span>
                        <button onClick={() => togglePasswordReveal(a.id)} className="text-slate-500 hover:text-slate-300">
                          {revealedPasswords[a.id] ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                        </button>
                      </div>
                    ) : <span className="text-slate-600 text-xs">hidden</span>}
                  </td>
                  <td className="table-td">
                    <div className="flex items-center gap-1.5">
                      {canWrite && (
                        <>
                          <button onClick={() => navigate(`/add-asset?edit=${a.id}`)} className="btn-edit">
                            <Edit2 className="w-3 h-3" />
                          </button>
                          <button onClick={() => handleDelete(a.id, a.vm_name || a.os_hostname)} className="btn-danger">
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-slate-800">
            <p className="text-xs text-slate-500">
              Showing {((page - 1) * LIMIT) + 1}–{Math.min(page * LIMIT, total)} of {total}
            </p>
            <div className="flex items-center gap-1">
              <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
                className="p-1.5 rounded text-slate-400 hover:text-white hover:bg-slate-700 disabled:opacity-30 transition-colors">
                <ChevronLeft className="w-4 h-4" />
              </button>
              {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                const p = Math.max(1, Math.min(totalPages - 4, page - 2)) + i;
                return (
                  <button key={p} onClick={() => setPage(p)}
                    className={`w-7 h-7 text-xs rounded ${p === page ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-700 hover:text-white'}`}>
                    {p}
                  </button>
                );
              })}
              <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages}
                className="p-1.5 rounded text-slate-400 hover:text-white hover:bg-slate-700 disabled:opacity-30 transition-colors">
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
