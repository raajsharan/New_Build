const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();

app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/assets', require('./routes/assets'));
app.use('/api/config', require('./routes/config'));
app.use('/api/dashboard', require('./routes/dashboard'));
app.use('/api/users', require('./routes/users'));
app.use('/api/settings', require('./routes/settings'));

// CSV Template download
app.get('/api/assets/template/csv', (req, res) => {
  const headers = [
    'vm_name', 'os_hostname', 'ip_address', 'asset_type', 'os_type', 'os_version',
    'assigned_user', 'department', 'business_purpose', 'server_status',
    'me_installed', 'tenable_installed', 'patching_schedule', 'patching_type',
    'location', 'additional_remarks', 'host_details', 'serial_number',
    'idrac_enabled', 'idrac_ip', 'eol_status', 'server_patch_type',
    'asset_username', 'asset_password'
  ];
  const example = [
    'PROD-WEB-02', 'webserver02.local', '192.168.1.50', 'VM', 'Linux', 'Ubuntu 22.04 LTS',
    'John Doe', 'IT', 'Web Server', 'Alive',
    'true', 'true', 'Monthly', 'Auto',
    'DC1', 'Sample server', 'Dell PowerEdge R740', 'SN-XXXX',
    'false', '', 'InSupport', 'Critical',
    'admin', 'password123'
  ];
  const csv = headers.join(',') + '\n' + example.join(',') + '\n';
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename=asset_import_template.csv');
  res.send(csv);
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`InfraVault API running on port ${PORT}`);
});

module.exports = app;
