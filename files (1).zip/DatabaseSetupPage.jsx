import React, { useState } from 'react';
import { Database, Copy, Check, Download } from 'lucide-react';
import toast from 'react-hot-toast';

const SQL_CONTENT = `-- ============================================================
-- Infrastructure Inventory - PostgreSQL Database Setup
-- Run these commands as a PostgreSQL superuser
-- ============================================================

-- Step 1: Create the database
CREATE DATABASE infrastructure_inventory;

-- Step 2: Connect to the database
\\c infrastructure_inventory;

-- Step 3: Create lookup tables
CREATE TABLE asset_types (id SERIAL PRIMARY KEY, name VARCHAR(100) NOT NULL UNIQUE, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE os_types (id SERIAL PRIMARY KEY, name VARCHAR(100) NOT NULL UNIQUE, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE os_versions (id SERIAL PRIMARY KEY, name VARCHAR(150) NOT NULL, os_type_id INTEGER REFERENCES os_types(id) ON DELETE CASCADE, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE departments (id SERIAL PRIMARY KEY, name VARCHAR(100) NOT NULL UNIQUE, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE server_status (id SERIAL PRIMARY KEY, name VARCHAR(100) NOT NULL UNIQUE, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE patching_schedule (id SERIAL PRIMARY KEY, name VARCHAR(100) NOT NULL UNIQUE, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE patching_type (id SERIAL PRIMARY KEY, name VARCHAR(100) NOT NULL UNIQUE, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE locations (id SERIAL PRIMARY KEY, name VARCHAR(100) NOT NULL UNIQUE, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE server_patch_type (id SERIAL PRIMARY KEY, name VARCHAR(100) NOT NULL UNIQUE, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE eol_status (id SERIAL PRIMARY KEY, name VARCHAR(100) NOT NULL UNIQUE, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);

-- Step 4: Create users table
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  username VARCHAR(100) NOT NULL UNIQUE,
  email VARCHAR(200) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(20) NOT NULL DEFAULT 'read_only' CHECK (role IN ('admin', 'read_write', 'read_only')),
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Step 5: Create main assets table
CREATE TABLE assets (
  id SERIAL PRIMARY KEY,
  vm_name VARCHAR(200), os_hostname VARCHAR(200), ip_address VARCHAR(50),
  asset_type_id INTEGER REFERENCES asset_types(id),
  os_type_id INTEGER REFERENCES os_types(id),
  os_version_id INTEGER REFERENCES os_versions(id),
  assigned_user VARCHAR(200), department_id INTEGER REFERENCES departments(id),
  business_purpose TEXT, server_status_id INTEGER REFERENCES server_status(id),
  me_installed_status BOOLEAN DEFAULT FALSE, tenable_installed_status BOOLEAN DEFAULT FALSE,
  patching_schedule_id INTEGER REFERENCES patching_schedule(id),
  patching_type_id INTEGER REFERENCES patching_type(id),
  location_id INTEGER REFERENCES locations(id), additional_remarks TEXT,
  host_details TEXT, serial_number VARCHAR(200),
  idrac_enabled BOOLEAN DEFAULT FALSE, idrac_ip VARCHAR(50),
  eol_status_id INTEGER REFERENCES eol_status(id),
  server_patch_type_id INTEGER REFERENCES server_patch_type(id),
  asset_username VARCHAR(200), asset_password TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Step 6: Support tables
CREATE TABLE custom_fields (id SERIAL PRIMARY KEY, field_name VARCHAR(100) NOT NULL UNIQUE, field_label VARCHAR(200) NOT NULL, field_type VARCHAR(20) NOT NULL CHECK (field_type IN ('textbox','dropdown','toggle')), dropdown_options TEXT, is_active BOOLEAN DEFAULT TRUE, display_order INTEGER DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE app_settings (id SERIAL PRIMARY KEY, setting_key VARCHAR(100) NOT NULL UNIQUE, setting_value TEXT, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE user_page_permissions (id SERIAL PRIMARY KEY, user_id INTEGER REFERENCES users(id) ON DELETE CASCADE, page_key VARCHAR(100) NOT NULL, is_visible BOOLEAN DEFAULT TRUE, UNIQUE(user_id, page_key));

-- Step 7: Create indexes
CREATE INDEX idx_assets_hostname ON assets(os_hostname);
CREATE INDEX idx_assets_ip ON assets(ip_address);
CREATE INDEX idx_os_versions_os_type ON os_versions(os_type_id);

-- Step 8: Seed dropdown data
INSERT INTO asset_types (name) VALUES ('VM'),('Physical Server'),('Hypervisor'),('Container');
INSERT INTO os_types (name) VALUES ('Linux'),('Windows'),('ESXi'),('Other');
INSERT INTO os_versions (name, os_type_id) VALUES ('Ubuntu 20.04 LTS',1),('Ubuntu 22.04 LTS',1),('Ubuntu 24.04 LTS',1),('RHEL 7',1),('RHEL 8',1),('RHEL 9',1),('CentOS 7',1),('Debian 11',1),('Debian 12',1),('Amazon Linux 2023',1),('Windows Server 2016',2),('Windows Server 2019',2),('Windows Server 2022',2),('Windows 10 Enterprise',2),('Windows 11 Enterprise',2),('ESXi 7.0',3),('ESXi 8.0',3),('Other',4);
INSERT INTO departments (name) VALUES ('IT'),('DevOps'),('Security'),('Application Team'),('Finance'),('Operations'),('Network');
INSERT INTO server_status (name) VALUES ('Alive'),('Powered Off'),('Not Alive'),('Decommissioned'),('Under Maintenance');
INSERT INTO patching_schedule (name) VALUES ('Weekly'),('Monthly'),('Quarterly'),('On-Demand');
INSERT INTO patching_type (name) VALUES ('Auto'),('Manual');
INSERT INTO locations (name) VALUES ('DC1'),('DC2'),('Azure'),('AWS'),('GCP'),('Branch Office'),('HQ');
INSERT INTO server_patch_type (name) VALUES ('Critical'),('Non-Critical'),('Test');
INSERT INTO eol_status (name) VALUES ('InSupport'),('EOL'),('Decom');

-- Step 9: Admin user (password: admin123)
INSERT INTO users (username, email, password_hash, role) VALUES ('admin','admin@infra.local','$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','admin');

-- Step 10: App settings
INSERT INTO app_settings (setting_key, setting_value) VALUES ('app_name','InfraVault'),('company_name','Your Company'),('logo_url',''),('password_visibility_enabled','false');

-- Done! Verify:
SELECT 'Setup complete' as status;`;

function CodeBlock({ code }) {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast.success('Copied to clipboard');
  };
  return (
    <div className="relative">
      <button onClick={copy} className="absolute top-3 right-3 text-slate-400 hover:text-white p-1.5 bg-slate-800 rounded-lg border border-slate-700 transition-colors">
        {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
      </button>
      <pre className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-xs text-slate-300 font-mono overflow-x-auto max-h-96 overflow-y-auto whitespace-pre-wrap leading-relaxed">
        {code}
      </pre>
    </div>
  );
}

const steps = [
  { step: 1, title: 'Install PostgreSQL', desc: 'Install PostgreSQL 13+ on your server', code: `# Ubuntu/Debian
sudo apt update && sudo apt install postgresql postgresql-contrib

# RHEL/CentOS
sudo dnf install postgresql-server postgresql-contrib
sudo postgresql-setup --initdb
sudo systemctl enable --now postgresql

# Verify
psql --version` },
  { step: 2, title: 'Access PostgreSQL', desc: 'Connect to PostgreSQL as superuser', code: `sudo -u postgres psql` },
  { step: 3, title: 'Run Database Setup', desc: 'Execute the full setup script', code: SQL_CONTENT },
  { step: 4, title: 'Configure Backend .env', desc: 'Create backend/.env with your database credentials', code: `PORT=5000
DB_HOST=localhost
DB_PORT=5432
DB_NAME=infrastructure_inventory
DB_USER=postgres
DB_PASSWORD=your_password_here
JWT_SECRET=change_this_to_a_long_random_string_in_production
JWT_EXPIRES_IN=24h
NODE_ENV=production` },
  { step: 5, title: 'Install & Start Backend', desc: 'Install dependencies and start the API server', code: `cd backend
npm install
npm start` },
  { step: 6, title: 'Install & Start Frontend', desc: 'Build and serve the React frontend', code: `cd frontend
npm install
npm run build
# For development:
npm run dev
# For production, serve the dist/ folder with nginx or similar` },
];

export default function DatabaseSetupPage() {
  const [activeStep, setActiveStep] = useState(null);

  const downloadSql = () => {
    const blob = new Blob([SQL_CONTENT], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'database_setup.sql'; a.click();
    URL.revokeObjectURL(url);
    toast.success('SQL file downloaded');
  };

  return (
    <div className="space-y-6 fade-in max-w-4xl">
      <div className="page-header">
        <div>
          <h1 className="page-title">Database Setup</h1>
          <p className="text-sm text-slate-500 mt-0.5">PostgreSQL setup commands and instructions</p>
        </div>
        <button onClick={downloadSql} className="btn-secondary">
          <Download className="w-4 h-4" /> Download SQL
        </button>
      </div>

      <div className="card bg-blue-500/5 border-blue-500/20">
        <div className="flex items-start gap-3">
          <Database className="w-5 h-5 text-blue-400 mt-0.5 flex-shrink-0" />
          <div>
            <p className="text-sm font-medium text-blue-300">Database: <span className="font-mono">infrastructure_inventory</span></p>
            <p className="text-xs text-slate-400 mt-1">
              PostgreSQL 13 or higher required. Run the setup script once to create all tables, indexes, and seed data.
              Default admin: <span className="font-mono text-slate-300">admin@infra.local</span> / <span className="font-mono text-slate-300">admin123</span>
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-3">
        {steps.map(s => (
          <div key={s.step} className="card">
            <button onClick={() => setActiveStep(activeStep === s.step ? null : s.step)}
              className="w-full flex items-center gap-3 text-left">
              <div className="w-7 h-7 rounded-lg bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-xs font-bold text-blue-400 flex-shrink-0">
                {s.step}
              </div>
              <div className="flex-1">
                <p className="text-sm font-semibold text-white">{s.title}</p>
                <p className="text-xs text-slate-500">{s.desc}</p>
              </div>
              <span className="text-xs text-slate-500">{activeStep === s.step ? '▲ Hide' : '▼ Show'}</span>
            </button>
            {activeStep === s.step && (
              <div className="mt-4">
                <CodeBlock code={s.code} />
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
