const express = require('express');
const router = express.Router();
const multer = require('multer');
const { parse } = require('csv-parse/sync');
const pool = require('../db/pool');
const { authenticate, requireWriteAccess } = require('../middleware/auth');

const upload = multer({ storage: multer.memoryStorage() });

const ASSET_SELECT = `
  SELECT a.*,
    at2.name as asset_type_name,
    ot.name as os_type_name,
    ov.name as os_version_name,
    d.name as department_name,
    ss.name as server_status_name,
    ps.name as patching_schedule_name,
    pt.name as patching_type_name,
    l.name as location_name,
    es.name as eol_status_name,
    spt.name as server_patch_type_name
  FROM assets a
  LEFT JOIN asset_types at2 ON a.asset_type_id = at2.id
  LEFT JOIN os_types ot ON a.os_type_id = ot.id
  LEFT JOIN os_versions ov ON a.os_version_id = ov.id
  LEFT JOIN departments d ON a.department_id = d.id
  LEFT JOIN server_status ss ON a.server_status_id = ss.id
  LEFT JOIN patching_schedule ps ON a.patching_schedule_id = ps.id
  LEFT JOIN patching_type pt ON a.patching_type_id = pt.id
  LEFT JOIN locations l ON a.location_id = l.id
  LEFT JOIN eol_status es ON a.eol_status_id = es.id
  LEFT JOIN server_patch_type spt ON a.server_patch_type_id = spt.id
`;

// GET /api/assets
router.get('/', authenticate, async (req, res) => {
  try {
    const { search, location_id, department_id, server_status_id, asset_type_id, page = 1, limit = 50 } = req.query;
    let where = [];
    let params = [];
    let i = 1;
    if (search) {
      where.push(`(a.os_hostname ILIKE $${i} OR a.ip_address ILIKE $${i} OR a.assigned_user ILIKE $${i} OR a.vm_name ILIKE $${i})`);
      params.push(`%${search}%`); i++;
    }
    if (location_id) { where.push(`a.location_id = $${i}`); params.push(location_id); i++; }
    if (department_id) { where.push(`a.department_id = $${i}`); params.push(department_id); i++; }
    if (server_status_id) { where.push(`a.server_status_id = $${i}`); params.push(server_status_id); i++; }
    if (asset_type_id) { where.push(`a.asset_type_id = $${i}`); params.push(asset_type_id); i++; }
    const whereStr = where.length > 0 ? 'WHERE ' + where.join(' AND ') : '';
    const offset = (parseInt(page) - 1) * parseInt(limit);
    const countResult = await pool.query(`SELECT COUNT(*) FROM assets a ${whereStr}`, params);
    const total = parseInt(countResult.rows[0].count);
    const result = await pool.query(
      `${ASSET_SELECT} ${whereStr} ORDER BY a.created_at DESC LIMIT $${i} OFFSET $${i+1}`,
      [...params, parseInt(limit), offset]
    );
    res.json({ assets: result.rows, total, page: parseInt(page), limit: parseInt(limit) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/assets/:id
router.get('/:id', authenticate, async (req, res) => {
  try {
    const result = await pool.query(`${ASSET_SELECT} WHERE a.id = $1`, [req.params.id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Asset not found' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /api/assets
router.post('/', authenticate, requireWriteAccess, async (req, res) => {
  try {
    const f = req.body;
    const result = await pool.query(`
      INSERT INTO assets (vm_name, os_hostname, ip_address, asset_type_id, os_type_id, os_version_id,
        assigned_user, department_id, business_purpose, server_status_id, me_installed_status,
        tenable_installed_status, patching_schedule_id, patching_type_id, location_id, additional_remarks,
        host_details, serial_number, idrac_enabled, idrac_ip, eol_status_id, server_patch_type_id,
        asset_username, asset_password)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24)
      RETURNING id`,
      [f.vm_name, f.os_hostname, f.ip_address, f.asset_type_id||null, f.os_type_id||null, f.os_version_id||null,
       f.assigned_user, f.department_id||null, f.business_purpose, f.server_status_id||null,
       f.me_installed_status||false, f.tenable_installed_status||false,
       f.patching_schedule_id||null, f.patching_type_id||null, f.location_id||null,
       f.additional_remarks, f.host_details, f.serial_number, f.idrac_enabled||false,
       f.idrac_ip||null, f.eol_status_id||null, f.server_patch_type_id||null,
       f.asset_username, f.asset_password]
    );
    const newAsset = await pool.query(`${ASSET_SELECT} WHERE a.id = $1`, [result.rows[0].id]);
    res.status(201).json(newAsset.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// PUT /api/assets/:id
router.put('/:id', authenticate, requireWriteAccess, async (req, res) => {
  try {
    const f = req.body;
    await pool.query(`
      UPDATE assets SET vm_name=$1, os_hostname=$2, ip_address=$3, asset_type_id=$4, os_type_id=$5,
        os_version_id=$6, assigned_user=$7, department_id=$8, business_purpose=$9, server_status_id=$10,
        me_installed_status=$11, tenable_installed_status=$12, patching_schedule_id=$13, patching_type_id=$14,
        location_id=$15, additional_remarks=$16, host_details=$17, serial_number=$18, idrac_enabled=$19,
        idrac_ip=$20, eol_status_id=$21, server_patch_type_id=$22, asset_username=$23, asset_password=$24
      WHERE id=$25`,
      [f.vm_name, f.os_hostname, f.ip_address, f.asset_type_id||null, f.os_type_id||null, f.os_version_id||null,
       f.assigned_user, f.department_id||null, f.business_purpose, f.server_status_id||null,
       f.me_installed_status||false, f.tenable_installed_status||false,
       f.patching_schedule_id||null, f.patching_type_id||null, f.location_id||null,
       f.additional_remarks, f.host_details, f.serial_number, f.idrac_enabled||false,
       f.idrac_ip||null, f.eol_status_id||null, f.server_patch_type_id||null,
       f.asset_username, f.asset_password, req.params.id]
    );
    const updated = await pool.query(`${ASSET_SELECT} WHERE a.id = $1`, [req.params.id]);
    res.json(updated.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// DELETE /api/assets/:id
router.delete('/:id', authenticate, requireWriteAccess, async (req, res) => {
  try {
    const result = await pool.query('DELETE FROM assets WHERE id = $1 RETURNING id', [req.params.id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Asset not found' });
    res.json({ message: 'Asset deleted', id: req.params.id });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /api/assets/import/csv
router.post('/import/csv', authenticate, requireWriteAccess, upload.single('file'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
    const content = req.file.buffer.toString('utf8');
    const records = parse(content, { columns: true, skip_empty_lines: true, trim: true });
    let inserted = 0, errors = [];

    // Get all lookup tables for name->id mapping
    const [at, ot, ov, dep, ss, ps, pt, loc, es, spt] = await Promise.all([
      pool.query('SELECT id, LOWER(name) as name FROM asset_types'),
      pool.query('SELECT id, LOWER(name) as name FROM os_types'),
      pool.query('SELECT id, LOWER(name) as name FROM os_versions'),
      pool.query('SELECT id, LOWER(name) as name FROM departments'),
      pool.query('SELECT id, LOWER(name) as name FROM server_status'),
      pool.query('SELECT id, LOWER(name) as name FROM patching_schedule'),
      pool.query('SELECT id, LOWER(name) as name FROM patching_type'),
      pool.query('SELECT id, LOWER(name) as name FROM locations'),
      pool.query('SELECT id, LOWER(name) as name FROM eol_status'),
      pool.query('SELECT id, LOWER(name) as name FROM server_patch_type'),
    ]);
    const lookup = (rows, val) => {
      if (!val) return null;
      const found = rows.find(r => r.name === val.toLowerCase().trim());
      return found ? found.id : null;
    };

    for (let i = 0; i < records.length; i++) {
      const r = records[i];
      try {
        await pool.query(`
          INSERT INTO assets (vm_name, os_hostname, ip_address, asset_type_id, os_type_id, os_version_id,
            assigned_user, department_id, business_purpose, server_status_id, me_installed_status,
            tenable_installed_status, patching_schedule_id, patching_type_id, location_id, additional_remarks,
            host_details, serial_number, idrac_enabled, idrac_ip, eol_status_id, server_patch_type_id,
            asset_username, asset_password)
          VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24)`,
          [r.vm_name, r.os_hostname, r.ip_address,
           lookup(at.rows, r.asset_type), lookup(ot.rows, r.os_type), lookup(ov.rows, r.os_version),
           r.assigned_user, lookup(dep.rows, r.department), r.business_purpose,
           lookup(ss.rows, r.server_status),
           r.me_installed === 'true' || r.me_installed === '1',
           r.tenable_installed === 'true' || r.tenable_installed === '1',
           lookup(ps.rows, r.patching_schedule), lookup(pt.rows, r.patching_type),
           lookup(loc.rows, r.location), r.additional_remarks, r.host_details, r.serial_number,
           r.idrac_enabled === 'true' || r.idrac_enabled === '1',
           r.idrac_ip || null, lookup(es.rows, r.eol_status), lookup(spt.rows, r.server_patch_type),
           r.asset_username, r.asset_password]
        );
        inserted++;
      } catch (rowErr) {
        errors.push({ row: i + 2, error: rowErr.message });
      }
    }
    res.json({ inserted, errors, total: records.length });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'CSV import failed: ' + err.message });
  }
});

module.exports = router;
