import React, { useState, useEffect } from 'react';
import { api } from '../context/AuthContext';
import { useAuth } from '../context/AuthContext';
import { Plus, Edit2, Trash2, Save, X, ChevronDown } from 'lucide-react';
import toast from 'react-hot-toast';

const CONFIG_TABLES = [
  { key: 'asset_types', label: 'Asset Types', example: 'VM, Physical Server' },
  { key: 'os_types', label: 'OS Types', example: 'Linux, Windows, ESXi' },
  { key: 'os_versions', label: 'OS Versions', example: 'Ubuntu 22.04, RHEL 9', hasOsType: true },
  { key: 'departments', label: 'Departments', example: 'IT, DevOps, Security' },
  { key: 'server_status', label: 'Server Status', example: 'Alive, Powered Off, Not Alive' },
  { key: 'patching_schedule', label: 'Patching Schedule', example: 'Weekly, Monthly' },
  { key: 'patching_type', label: 'Patching Type', example: 'Auto, Manual' },
  { key: 'locations', label: 'Locations', example: 'DC1, DC2, Azure' },
  { key: 'server_patch_type', label: 'Server Patch Type', example: 'Critical, Non-Critical, Test' },
  { key: 'eol_status', label: 'EOL Status', example: 'InSupport, EOL, Decom' },
];

function ConfigSection({ table, label, example, hasOsType, canWrite }) {
  const [items, setItems] = useState([]);
  const [osTypes, setOsTypes] = useState([]);
  const [editId, setEditId] = useState(null);
  const [editName, setEditName] = useState('');
  const [editOsTypeId, setEditOsTypeId] = useState('');
  const [newName, setNewName] = useState('');
  const [newOsTypeId, setNewOsTypeId] = useState('');
  const [open, setOpen] = useState(false);

  const load = async () => {
    const res = await api.get(`/config/${table}`);
    setItems(res.data);
  };

  useEffect(() => {
    if (open) {
      load();
      if (hasOsType) api.get('/config/os_types').then(r => setOsTypes(r.data));
    }
  }, [open]);

  const handleAdd = async (e) => {
    e.preventDefault();
    if (!newName.trim()) return;
    try {
      await api.post(`/config/${table}`, { name: newName.trim(), os_type_id: newOsTypeId || undefined });
      toast.success('Added');
      setNewName(''); setNewOsTypeId('');
      load();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to add');
    }
  };

  const handleUpdate = async (id) => {
    try {
      await api.put(`/config/${table}/${id}`, { name: editName, os_type_id: editOsTypeId || undefined });
      toast.success('Updated');
      setEditId(null);
      load();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to update');
    }
  };

  const handleDelete = async (id, name) => {
    if (!window.confirm(`Delete "${name}"?`)) return;
    try {
      await api.delete(`/config/${table}/${id}`);
      toast.success('Deleted');
      load();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Cannot delete - value is in use');
    }
  };

  const osTypeMap = {};
  osTypes.forEach(o => { osTypeMap[o.id] = o.name; });

  return (
    <div className="card">
      <button onClick={() => setOpen(s => !s)} className="w-full flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold text-white">{label}</h3>
          <p className="text-xs text-slate-500 mt-0.5">e.g. {example}</p>
        </div>
        <div className="flex items-center gap-2">
          {open && <span className="text-xs text-slate-500">{items.length} values</span>}
          <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${open ? 'rotate-180' : ''}`} />
        </div>
      </button>

      {open && (
        <div className="mt-4 space-y-3 border-t border-slate-800 pt-4">
          {/* Add form */}
          {canWrite && (
            <form onSubmit={handleAdd} className="flex items-center gap-2">
              {hasOsType && (
                <select className="form-select text-xs w-36" value={newOsTypeId} onChange={e => setNewOsTypeId(e.target.value)}>
                  <option value="">OS Type...</option>
                  {osTypes.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}
                </select>
              )}
              <input className="form-input text-xs flex-1" value={newName} onChange={e => setNewName(e.target.value)}
                placeholder={`Add ${label.slice(0, -1)}...`} />
              <button type="submit" className="btn-primary text-xs px-3 py-1.5">
                <Plus className="w-3.5 h-3.5" /> Add
              </button>
            </form>
          )}

          {/* Items list */}
          <div className="space-y-1 max-h-64 overflow-y-auto">
            {items.length === 0 ? (
              <p className="text-xs text-slate-600 text-center py-4">No values yet</p>
            ) : items.map(item => (
              <div key={item.id} className="flex items-center gap-2 px-3 py-2 rounded-lg bg-slate-800/50 hover:bg-slate-800 group">
                {editId === item.id ? (
                  <>
                    {hasOsType && (
                      <select className="form-select text-xs w-32" value={editOsTypeId} onChange={e => setEditOsTypeId(e.target.value)}>
                        <option value="">OS Type...</option>
                        {osTypes.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}
                      </select>
                    )}
                    <input className="form-input text-xs flex-1 h-7" value={editName} onChange={e => setEditName(e.target.value)}
                      autoFocus onKeyDown={e => { if (e.key === 'Enter') handleUpdate(item.id); if (e.key === 'Escape') setEditId(null); }} />
                    <button onClick={() => handleUpdate(item.id)} className="text-emerald-400 hover:text-emerald-300 p-1"><Save className="w-3.5 h-3.5" /></button>
                    <button onClick={() => setEditId(null)} className="text-slate-400 hover:text-white p-1"><X className="w-3.5 h-3.5" /></button>
                  </>
                ) : (
                  <>
                    <span className="text-xs text-slate-300 flex-1">
                      {hasOsType && item.os_type_id && (
                        <span className="text-slate-500 mr-1.5">[{osTypeMap[item.os_type_id] || '?'}]</span>
                      )}
                      {item.name}
                    </span>
                    {canWrite && (
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => { setEditId(item.id); setEditName(item.name); setEditOsTypeId(item.os_type_id || ''); }}
                          className="text-blue-400 hover:text-blue-300 p-1"><Edit2 className="w-3 h-3" /></button>
                        <button onClick={() => handleDelete(item.id, item.name)}
                          className="text-red-400 hover:text-red-300 p-1"><Trash2 className="w-3 h-3" /></button>
                      </div>
                    )}
                  </>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default function ConfigPage() {
  const { canWrite } = useAuth();

  return (
    <div className="space-y-4 fade-in max-w-3xl">
      <div className="page-header">
        <div>
          <h1 className="page-title">Inventory Configuration</h1>
          <p className="text-sm text-slate-500 mt-0.5">Manage dropdown values used in the asset form</p>
        </div>
        {!canWrite && (
          <span className="text-xs bg-amber-500/10 text-amber-400 border border-amber-500/30 px-3 py-1.5 rounded-lg">Read-only</span>
        )}
      </div>

      <div className="space-y-3">
        {CONFIG_TABLES.map(t => (
          <ConfigSection key={t.key} table={t.key} label={t.label} example={t.example} hasOsType={t.hasOsType} canWrite={canWrite} />
        ))}
      </div>
    </div>
  );
}
