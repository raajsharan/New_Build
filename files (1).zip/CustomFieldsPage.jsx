import React, { useState, useEffect } from 'react';
import { api } from '../context/AuthContext';
import { Plus, Trash2, Edit2, Save, X, Wrench } from 'lucide-react';
import Toggle from '../components/Toggle';
import toast from 'react-hot-toast';

const FIELD_TYPES = [
  { value: 'textbox', label: 'Text Box' },
  { value: 'dropdown', label: 'Dropdown' },
  { value: 'toggle', label: 'Toggle (Yes/No)' },
];

export default function CustomFieldsPage() {
  const [fields, setFields] = useState([]);
  const [form, setForm] = useState({ field_name: '', field_label: '', field_type: 'textbox', dropdown_options: '', display_order: 0 });
  const [editId, setEditId] = useState(null);
  const [saving, setSaving] = useState(false);

  const load = async () => {
    try {
      const res = await api.get('/settings/custom-fields');
      setFields(res.data);
    } catch {}
  };

  useEffect(() => { load(); }, []);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.field_name || !form.field_label) return toast.error('Name and label required');
    setSaving(true);
    try {
      if (editId) {
        await api.put(`/settings/custom-fields/${editId}`, form);
        toast.success('Field updated');
        setEditId(null);
      } else {
        await api.post('/settings/custom-fields', form);
        toast.success('Custom field added');
      }
      setForm({ field_name: '', field_label: '', field_type: 'textbox', dropdown_options: '', display_order: 0 });
      load();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to save');
    } finally { setSaving(false); }
  };

  const handleDelete = async (id, label) => {
    if (!window.confirm(`Delete field "${label}"?`)) return;
    try {
      await api.delete(`/settings/custom-fields/${id}`);
      toast.success('Field deleted');
      load();
    } catch { toast.error('Delete failed'); }
  };

  const startEdit = (f) => {
    setEditId(f.id);
    setForm({ field_name: f.field_name, field_label: f.field_label, field_type: f.field_type, dropdown_options: f.dropdown_options || '', display_order: f.display_order || 0 });
  };

  return (
    <div className="space-y-6 fade-in max-w-3xl">
      <div className="page-header">
        <div>
          <h1 className="page-title">Custom Fields</h1>
          <p className="text-sm text-slate-500 mt-0.5">Add custom fields to the asset form (admin only)</p>
        </div>
      </div>

      {/* Add/Edit form */}
      <div className="card">
        <h3 className="text-sm font-semibold text-slate-300 border-b border-slate-800 pb-2 mb-4">
          {editId ? 'Edit Custom Field' : 'Add New Custom Field'}
        </h3>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="form-label">Field Key (no spaces)</label>
              <input className="form-input font-mono text-xs" value={form.field_name} onChange={e => set('field_name', e.target.value.replace(/\s/g, '_').toLowerCase())}
                placeholder="custom_field_name" disabled={!!editId} />
            </div>
            <div>
              <label className="form-label">Display Label</label>
              <input className="form-input" value={form.field_label} onChange={e => set('field_label', e.target.value)} placeholder="Custom Field Label" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="form-label">Field Type</label>
              <select className="form-select" value={form.field_type} onChange={e => set('field_type', e.target.value)}>
                {FIELD_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
              </select>
            </div>
            <div>
              <label className="form-label">Display Order</label>
              <input type="number" className="form-input" value={form.display_order} onChange={e => set('display_order', parseInt(e.target.value) || 0)} />
            </div>
          </div>
          {form.field_type === 'dropdown' && (
            <div>
              <label className="form-label">Dropdown Options (comma-separated)</label>
              <input className="form-input" value={form.dropdown_options} onChange={e => set('dropdown_options', e.target.value)} placeholder="Option 1, Option 2, Option 3" />
            </div>
          )}
          <div className="flex items-center gap-2">
            <button type="submit" className="btn-primary" disabled={saving}>
              <Save className="w-4 h-4" /> {saving ? 'Saving...' : editId ? 'Update' : 'Add Field'}
            </button>
            {editId && (
              <button type="button" className="btn-secondary" onClick={() => { setEditId(null); setForm({ field_name: '', field_label: '', field_type: 'textbox', dropdown_options: '', display_order: 0 }); }}>
                <X className="w-4 h-4" /> Cancel
              </button>
            )}
          </div>
        </form>
      </div>

      {/* Fields list */}
      <div className="card p-0 overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-800 flex items-center gap-2">
          <Wrench className="w-4 h-4 text-slate-400" />
          <span className="text-sm font-medium text-slate-300">Custom Fields ({fields.length})</span>
        </div>
        {fields.length === 0 ? (
          <p className="text-sm text-slate-500 text-center py-8">No custom fields yet. Add one above.</p>
        ) : (
          <table className="w-full">
            <thead className="bg-slate-800/40">
              <tr>
                {['Key','Label','Type','Options','Order','Actions'].map(h => (
                  <th key={h} className="table-th">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {fields.map(f => (
                <tr key={f.id} className="hover:bg-slate-800/20">
                  <td className="table-td font-mono text-xs text-blue-400">{f.field_name}</td>
                  <td className="table-td text-sm">{f.field_label}</td>
                  <td className="table-td">
                    <span className="badge-default">{FIELD_TYPES.find(t => t.value === f.field_type)?.label}</span>
                  </td>
                  <td className="table-td text-xs text-slate-400 max-w-xs truncate">{f.dropdown_options || '—'}</td>
                  <td className="table-td text-xs">{f.display_order}</td>
                  <td className="table-td">
                    <div className="flex gap-1">
                      <button onClick={() => startEdit(f)} className="btn-edit"><Edit2 className="w-3 h-3" /></button>
                      <button onClick={() => handleDelete(f.id, f.field_label)} className="btn-danger"><Trash2 className="w-3 h-3" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="card text-xs text-slate-500 space-y-1">
        <p className="text-slate-400 font-medium">ℹ️ Note:</p>
        <p>Custom fields are defined here for future integration. Once added, they can be programmatically included in the asset form by a developer. Field keys are used as database column identifiers.</p>
      </div>
    </div>
  );
}
