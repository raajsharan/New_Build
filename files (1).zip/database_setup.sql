-- ============================================================
-- Infrastructure Inventory Management System - Database Setup
-- PostgreSQL Database: infrastructure_inventory
-- ============================================================

-- Create database (run as superuser)
CREATE DATABASE infrastructure_inventory;

-- Connect to the database
\c infrastructure_inventory;

-- ============================================================
-- LOOKUP / DROPDOWN TABLES
-- ============================================================

CREATE TABLE asset_types (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE os_types (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE os_versions (
    id SERIAL PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    os_type_id INTEGER REFERENCES os_types(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE departments (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE server_status (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE patching_schedule (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE patching_type (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE locations (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE server_patch_type (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE eol_status (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- USERS TABLE
-- ============================================================

CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(200) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'read_only' CHECK (role IN ('admin', 'read_write', 'read_only')),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- MAIN ASSETS TABLE
-- ============================================================

CREATE TABLE assets (
    id SERIAL PRIMARY KEY,
    vm_name VARCHAR(200),
    os_hostname VARCHAR(200),
    ip_address VARCHAR(50),
    asset_type_id INTEGER REFERENCES asset_types(id),
    os_type_id INTEGER REFERENCES os_types(id),
    os_version_id INTEGER REFERENCES os_versions(id),
    assigned_user VARCHAR(200),
    department_id INTEGER REFERENCES departments(id),
    business_purpose TEXT,
    server_status_id INTEGER REFERENCES server_status(id),
    me_installed_status BOOLEAN DEFAULT FALSE,
    tenable_installed_status BOOLEAN DEFAULT FALSE,
    patching_schedule_id INTEGER REFERENCES patching_schedule(id),
    patching_type_id INTEGER REFERENCES patching_type(id),
    location_id INTEGER REFERENCES locations(id),
    additional_remarks TEXT,
    -- Extended fields
    host_details TEXT,
    serial_number VARCHAR(200),
    idrac_enabled BOOLEAN DEFAULT FALSE,
    idrac_ip VARCHAR(50),
    eol_status_id INTEGER REFERENCES eol_status(id),
    server_patch_type_id INTEGER REFERENCES server_patch_type(id),
    asset_username VARCHAR(200),
    asset_password TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- CUSTOM FIELDS TABLE
-- ============================================================

CREATE TABLE custom_fields (
    id SERIAL PRIMARY KEY,
    field_name VARCHAR(100) NOT NULL UNIQUE,
    field_label VARCHAR(200) NOT NULL,
    field_type VARCHAR(20) NOT NULL CHECK (field_type IN ('textbox', 'dropdown', 'toggle')),
    dropdown_options TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    display_order INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- APP SETTINGS TABLE
-- ============================================================

CREATE TABLE app_settings (
    id SERIAL PRIMARY KEY,
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- USER PERMISSIONS TABLE (page visibility)
-- ============================================================

CREATE TABLE user_page_permissions (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    page_key VARCHAR(100) NOT NULL,
    is_visible BOOLEAN DEFAULT TRUE,
    UNIQUE(user_id, page_key)
);

-- ============================================================
-- INDEXES
-- ============================================================

CREATE INDEX idx_assets_hostname ON assets(os_hostname);
CREATE INDEX idx_assets_ip ON assets(ip_address);
CREATE INDEX idx_assets_location ON assets(location_id);
CREATE INDEX idx_assets_department ON assets(department_id);
CREATE INDEX idx_assets_status ON assets(server_status_id);
CREATE INDEX idx_assets_asset_type ON assets(asset_type_id);
CREATE INDEX idx_os_versions_os_type ON os_versions(os_type_id);

-- ============================================================
-- SEED DATA - DROPDOWN VALUES
-- ============================================================

INSERT INTO asset_types (name) VALUES ('VM'), ('Physical Server'), ('Hypervisor'), ('Container');

INSERT INTO os_types (name) VALUES ('Linux'), ('Windows'), ('ESXi'), ('Other');

INSERT INTO os_versions (name, os_type_id) VALUES
  ('Ubuntu 20.04 LTS', 1), ('Ubuntu 22.04 LTS', 1), ('Ubuntu 24.04 LTS', 1),
  ('RHEL 7', 1), ('RHEL 8', 1), ('RHEL 9', 1),
  ('CentOS 7', 1), ('CentOS Stream 8', 1), ('CentOS Stream 9', 1),
  ('Debian 10', 1), ('Debian 11', 1), ('Debian 12', 1),
  ('Amazon Linux 2', 1), ('Amazon Linux 2023', 1),
  ('SUSE Linux Enterprise 15', 1),
  ('Windows Server 2016', 2), ('Windows Server 2019', 2), ('Windows Server 2022', 2),
  ('Windows 10 Enterprise', 2), ('Windows 11 Enterprise', 2), ('Windows 10 Pro', 2),
  ('Windows 11 Pro', 2),
  ('ESXi 7.0', 3), ('ESXi 8.0', 3),
  ('Other', 4);

INSERT INTO departments (name) VALUES ('IT'), ('DevOps'), ('Security'), ('Application Team'), ('Finance'), ('HR'), ('Operations'), ('Network');

INSERT INTO server_status (name) VALUES ('Alive'), ('Powered Off'), ('Not Alive'), ('Decommissioned'), ('Under Maintenance');

INSERT INTO patching_schedule (name) VALUES ('Weekly'), ('Monthly'), ('Quarterly'), ('On-Demand');

INSERT INTO patching_type (name) VALUES ('Auto'), ('Manual');

INSERT INTO locations (name) VALUES ('DC1'), ('DC2'), ('Azure'), ('AWS'), ('GCP'), ('Branch Office'), ('HQ');

INSERT INTO server_patch_type (name) VALUES ('Critical'), ('Non-Critical'), ('Test');

INSERT INTO eol_status (name) VALUES ('InSupport'), ('EOL'), ('Decom');

-- ============================================================
-- SEED DATA - ADMIN USER
-- Password: admin123 (bcrypt hash)
-- ============================================================

INSERT INTO users (username, email, password_hash, role) VALUES
  ('admin', 'admin@infra.local', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- ============================================================
-- SEED DATA - APP SETTINGS
-- ============================================================

INSERT INTO app_settings (setting_key, setting_value) VALUES
  ('app_name', 'InfraVault'),
  ('company_name', 'Your Company'),
  ('logo_url', ''),
  ('password_visibility_enabled', 'false');

-- ============================================================
-- SEED DATA - 4 SAMPLE ASSETS
-- ============================================================

INSERT INTO assets (
  vm_name, os_hostname, ip_address, asset_type_id, os_type_id, os_version_id,
  assigned_user, department_id, business_purpose, server_status_id,
  me_installed_status, tenable_installed_status, patching_schedule_id, patching_type_id,
  location_id, additional_remarks, serial_number, idrac_enabled, idrac_ip,
  eol_status_id, server_patch_type_id, asset_username, asset_password
) VALUES
(
  'PROD-WEB-01', 'webserver01.infra.local', '192.168.1.10',
  1, 1, 2, 'John Smith', 1, 'Production Web Server for main application',
  1, TRUE, TRUE, 2, 1, 1,
  'Primary production web server', 'SN-WEB-001', TRUE, '192.168.1.110',
  1, 1, 'sysadmin', 'P@ssw0rd123'
),
(
  'PROD-DB-01', 'dbserver01.infra.local', '192.168.1.20',
  2, 1, 4, 'Jane Doe', 2, 'Production PostgreSQL Database Server',
  1, TRUE, TRUE, 2, 2, 1,
  'Main production database', 'SN-DB-001', TRUE, '192.168.1.120',
  1, 1, 'dbadmin', 'DB$ecure2024'
),
(
  'DEV-APP-01', 'devapp01.infra.local', '192.168.2.10',
  1, 2, 16, 'Bob Wilson', 3, 'Development Application Server',
  1, FALSE, TRUE, 1, 1, 2,
  'Dev environment server', 'SN-DEV-001', FALSE, NULL,
  1, 3, 'devadmin', 'Dev@dmin123'
),
(
  'BACKUP-01', 'backup01.infra.local', '192.168.1.30',
  2, 2, 17, 'Alice Brown', 1, 'Backup and Disaster Recovery Server',
  2, TRUE, FALSE, 2, 2, 1,
  'Nightly backup server - scheduled maintenance window', 'SN-BCK-001', TRUE, '192.168.1.130',
  1, 2, 'backupadmin', 'Backup@2024'
);

-- ============================================================
-- UPDATE TRIGGER for updated_at
-- ============================================================

CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER assets_updated_at BEFORE UPDATE ON assets
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER users_updated_at BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Done!
SELECT 'Database setup complete!' as status;
SELECT 'Tables created: ' || count(*) as info FROM information_schema.tables WHERE table_schema = 'public';
