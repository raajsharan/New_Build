import React, { useState, useEffect } from 'react';
import { api } from '../context/AuthContext';
import { useSettings } from '../context/SettingsContext';
import { Save, Server } from 'lucide-react';
import toast from 'react-hot-toast';

export default function SettingsPage() {
  const { settings, refresh } = useSettings();
  const [form, setForm] = useState({ app_name: '', company_name: '', logo_url: '' });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setForm({
      app_name: settings.app_name || '',
      company_name: settings.company_name || '',
      logo_url: settings.logo_url || '',
    });
  }, [settings]);

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await api.put('/settings', form);
      await refresh();
      toast.success('Settings saved');
    } catch { toast.error('Failed to save'); }
    finally { setSaving(false); }
  };

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  return (
    <div className="space-y-6 fade-in max-w-2xl">
      <div className="page-header">
        <div>
          <h1 className="page-title">App Settings</h1>
          <p className="text-sm text-slate-500 mt-0.5">Customize branding and application name</p>
        </div>
      </div>

      <form onSubmit={handleSave} className="space-y-4">
        <div className="card space-y-4">
          <h3 className="text-sm font-semibold text-slate-300 border-b border-slate-800 pb-2">Branding</h3>
          
          <div>
            <label className="form-label">Application Name</label>
            <input className="form-input" value={form.app_name} onChange={e => set('app_name', e.target.value)} placeholder="InfraVault" />
            <p className="text-xs text-slate-500 mt-1">Displayed in the sidebar and browser tab</p>
          </div>

          <div>
            <label className="form-label">Company Name</label>
            <input className="form-input" value={form.company_name} onChange={e => set('company_name', e.target.value)} placeholder="Your Company" />
            <p className="text-xs text-slate-500 mt-1">Shown below the app name in the sidebar</p>
          </div>

          <div>
            <label className="form-label">Logo URL</label>
            <input className="form-input" value={form.logo_url} onChange={e => set('logo_url', e.target.value)} placeholder="https://yourcompany.com/logo.png" />
            <p className="text-xs text-slate-500 mt-1">Direct URL to company logo image (PNG, SVG). Leave blank to use default icon.</p>
          </div>

          {/* Preview */}
          <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700">
            <p className="text-xs text-slate-500 mb-3">Sidebar Preview:</p>
            <div className="flex items-center gap-3">
              {form.logo_url ? (
                <img src={form.logo_url} alt="logo" className="w-8 h-8 rounded-lg object-contain bg-slate-700 p-1" onError={e => e.target.style.display='none'} />
              ) : (
                <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center">
                  <Server className="w-4 h-4 text-white" />
                </div>
              )}
              <div>
                <p className="text-sm font-bold text-white">{form.app_name || 'InfraVault'}</p>
                <p className="text-xs text-slate-500">{form.company_name || 'Your Company'}</p>
              </div>
            </div>
          </div>
        </div>

        <button type="submit" className="btn-primary" disabled={saving}>
          <Save className="w-4 h-4" />
          {saving ? 'Saving...' : 'Save Settings'}
        </button>
      </form>
    </div>
  );
}
