import React, { useState, useEffect, useCallback } from 'react';
import { api } from '../context/AuthContext';
import {
  PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend
} from 'recharts';
import { Server, Monitor, ShieldCheck, Activity, PowerOff, Wifi, WifiOff, RefreshCw } from 'lucide-react';
import toast from 'react-hot-toast';

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6'];

function StatCard({ icon: Icon, label, value, color = 'blue', sub }) {
  const colorMap = {
    blue: 'text-blue-400 bg-blue-500/10 border-blue-500/20',
    green: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
    amber: 'text-amber-400 bg-amber-500/10 border-amber-500/20',
    red: 'text-red-400 bg-red-500/10 border-red-500/20',
    purple: 'text-purple-400 bg-purple-500/10 border-purple-500/20',
    cyan: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20',
  };
  return (
    <div className="stat-card hover:border-slate-700 transition-colors">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs text-slate-500 font-medium">{label}</p>
          <p className="text-3xl font-bold text-white mt-1">{value ?? '—'}</p>
          {sub && <p className="text-xs text-slate-500 mt-0.5">{sub}</p>}
        </div>
        <div className={`w-9 h-9 rounded-lg flex items-center justify-center border ${colorMap[color] || colorMap.blue}`}>
          <Icon className="w-4.5 h-4.5" />
        </div>
      </div>
    </div>
  );
}

const CustomTooltip = ({ active, payload }) => {
  if (active && payload?.length) {
    return (
      <div className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm">
        <p className="text-white font-medium">{payload[0].name || payload[0].payload?.name}</p>
        <p className="text-slate-300">{payload[0].value} servers</p>
      </div>
    );
  }
  return null;
};

export default function DashboardPage() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      const res = await api.get('/dashboard/summary');
      setData(res.data);
    } catch { toast.error('Failed to load dashboard'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => {
    load();
    const interval = setInterval(load, 30000);
    return () => clearInterval(interval);
  }, [load]);

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="flex items-center gap-3 text-slate-400">
        <RefreshCw className="w-5 h-5 animate-spin" />
        <span>Loading dashboard...</span>
      </div>
    </div>
  );

  const vmVsPhysical = (data?.asset_type_distribution || [])
    .filter(d => d.name)
    .map(d => ({ name: d.name, value: parseInt(d.count) }));

  const patchData = (data?.patch_type_distribution || [])
    .filter(d => d.name)
    .map(d => ({ name: d.name, value: parseInt(d.count) }));

  const statusData = (data?.status_distribution || [])
    .filter(d => d.name)
    .map(d => ({ name: d.name, value: parseInt(d.count) }));

  const locationData = (data?.location_distribution || [])
    .filter(d => d.name)
    .map(d => ({ name: d.name, count: parseInt(d.count) }));

  return (
    <div className="space-y-6 fade-in">
      <div className="page-header">
        <div>
          <h1 className="page-title">Infrastructure Dashboard</h1>
          <p className="text-sm text-slate-500 mt-0.5">Real-time overview of your infrastructure assets</p>
        </div>
        <button onClick={load} className="btn-secondary">
          <RefreshCw className="w-4 h-4" /> Refresh
        </button>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
        <StatCard icon={Server} label="Total Assets" value={data?.total_assets} color="blue"
          sub={`${data?.vm_count || 0} VM · ${data?.physical_server_count || 0} Physical`} />
        <StatCard icon={ShieldCheck} label="ManageEngine" value={data?.me_installed_count} color="purple" sub="Installed" />
        <StatCard icon={Activity} label="Tenable" value={data?.tenable_installed_count} color="cyan" sub="Installed" />
        <StatCard icon={Wifi} label="Alive" value={data?.alive_servers} color="green" />
        <StatCard icon={PowerOff} label="Powered Off" value={data?.powered_off_servers} color="amber" />
        <StatCard icon={WifiOff} label="Not Alive" value={data?.not_alive_servers} color="red" />
        <StatCard icon={RefreshCw} label="Auto Patching" value={data?.auto_patch_count} color="blue" />
        <StatCard icon={Monitor} label="Manual Patching" value={data?.manual_patch_count} color="amber" />
      </div>

      {/* Charts row 1 */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {/* VM vs Physical */}
        <div className="card">
          <h3 className="text-sm font-semibold text-slate-300 mb-4">VM vs Physical</h3>
          {vmVsPhysical.length > 0 ? (
            <ResponsiveContainer width="100%" height={180}>
              <PieChart>
                <Pie data={vmVsPhysical} cx="50%" cy="50%" innerRadius={45} outerRadius={70}
                  dataKey="value" nameKey="name">
                  {vmVsPhysical.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
                <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: '11px' }} />
              </PieChart>
            </ResponsiveContainer>
          ) : <p className="text-slate-500 text-sm text-center py-8">No data</p>}
        </div>

        {/* Patching */}
        <div className="card">
          <h3 className="text-sm font-semibold text-slate-300 mb-4">Patching Type</h3>
          {patchData.length > 0 ? (
            <ResponsiveContainer width="100%" height={180}>
              <PieChart>
                <Pie data={patchData} cx="50%" cy="50%" innerRadius={45} outerRadius={70} dataKey="value" nameKey="name">
                  {patchData.map((_, i) => <Cell key={i} fill={COLORS[(i + 2) % COLORS.length]} />)}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
                <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: '11px' }} />
              </PieChart>
            </ResponsiveContainer>
          ) : <p className="text-slate-500 text-sm text-center py-8">No data</p>}
        </div>

        {/* Server Status */}
        <div className="card">
          <h3 className="text-sm font-semibold text-slate-300 mb-4">Server Status</h3>
          {statusData.length > 0 ? (
            <ResponsiveContainer width="100%" height={180}>
              <PieChart>
                <Pie data={statusData} cx="50%" cy="50%" innerRadius={45} outerRadius={70} dataKey="value" nameKey="name">
                  {statusData.map((entry) => {
                    const c = entry.name === 'Alive' ? '#10b981' : entry.name === 'Powered Off' ? '#f59e0b' : '#ef4444';
                    return <Cell key={entry.name} fill={c} />;
                  })}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
                <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: '11px' }} />
              </PieChart>
            </ResponsiveContainer>
          ) : <p className="text-slate-500 text-sm text-center py-8">No data</p>}
        </div>

        {/* Location summary */}
        <div className="card">
          <h3 className="text-sm font-semibold text-slate-300 mb-4">Top Locations</h3>
          <div className="space-y-2">
            {locationData.slice(0, 6).map((loc, i) => (
              <div key={i} className="flex items-center justify-between">
                <span className="text-xs text-slate-400 truncate max-w-[100px]">{loc.name || 'Unknown'}</span>
                <div className="flex items-center gap-2">
                  <div className="w-20 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-blue-500 rounded-full"
                      style={{ width: `${Math.min(100, (loc.count / (data?.total_assets || 1)) * 100)}%` }} />
                  </div>
                  <span className="text-xs font-mono text-slate-300 w-6 text-right">{loc.count}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Location bar chart */}
      {locationData.length > 0 && (
        <div className="card">
          <h3 className="text-sm font-semibold text-slate-300 mb-4">Location Distribution</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={locationData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#94a3b8' }} />
              <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} allowDecimals={false} />
              <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(255,255,255,0.04)' }} />
              <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                {locationData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
}
