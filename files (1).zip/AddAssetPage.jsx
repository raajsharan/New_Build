import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { api } from '../context/AuthContext';
import { useAuth } from '../context/AuthContext';
import { useDropdowns } from '../utils/useDropdowns';
import Toggle from '../components/Toggle';
import { PlusCircle, Save, X, Eye, EyeOff, ArrowLeft } from 'lucide-react';
import toast from 'react-hot-toast';

const EMPTY_FORM = {
  vm_name: '', os_hostname: '', ip_address: '', asset_type_id: '', os_type_id: '', os_version_id: '',
  assigned_user: '', department_id: '', business_purpose: '', server_status_id: '',
  me_installed_status: false, tenable_installed_status: false,
  patching_schedule_id: '', patching_type_id: '', location_id: '', additional_remarks: '',
  host_details: '', serial_number: '', idrac_enabled: false, idrac_ip: '',
  eol_status_id: '', server_patch_type_id: '',
  asset_username: '', asset_password: '',
};

function FormSection({ title, children }) {
  return (
    <div className="card space-y-4">
      <h3 className="text-sm font-semibold text-slate-300 border-b border-slate-800 pb-2">{title}</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {children}
      </div>
    </div>
  );
}

function Field({ label, children, full }) {
  return (
    <div className={full ? 'sm:col-span-2 lg:col-span-3' : ''}>
      <label className="form-label">{label}</label>
      {children}
    </div>
  );
}

export default function AddAssetPage() {
  const { canWrite } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const editId = searchParams.get('edit');

  const { dropdowns, loading: dropLoading, fetchOsVersions } = useDropdowns();
  const [form, setForm] = useState(EMPTY_FORM);
  const [osVersions, setOsVersions] = useState([]);
  const [showPw, setShowPw] = useState(false);
  const [saving, setSaving] = useState(false);

  // Load asset for edit
  useEffect(() => {
    if (editId) {
      api.get(`/assets/${editId}`).then(res => {
        const a = res.data;
        setForm({
          vm_name: a.vm_name || '', os_hostname: a.os_hostname || '', ip_address: a.ip_address || '',
          asset_type_id: a.asset_type_id || '', os_type_id: a.os_type_id || '', os_version_id: a.os_version_id || '',
          assigned_user: a.assigned_user || '', department_id: a.department_id || '',
          business_purpose: a.business_purpose || '', server_status_id: a.server_status_id || '',
          me_installed_status: !!a.me_installed_status, tenable_installed_status: !!a.tenable_installed_status,
          patching_schedule_id: a.patching_schedule_id || '', patching_type_id: a.patching_type_id || '',
          location_id: a.location_id || '', additional_remarks: a.additional_remarks || '',
          host_details: a.host_details || '', serial_number: a.serial_number || '',
          idrac_enabled: !!a.idrac_enabled, idrac_ip: a.idrac_ip || '',
          eol_status_id: a.eol_status_id || '', server_patch_type_id: a.server_patch_type_id || '',
          asset_username: a.asset_username || '', asset_password: a.asset_password || '',
        });
      }).catch(() => toast.error('Failed to load asset'));
    }
  }, [editId]);

  // Load OS versions when OS type changes
  useEffect(() => {
    if (form.os_type_id) {
      fetchOsVersions(form.os_type_id).then(setOsVersions);
    } else {
      setOsVersions([]);
    }
  }, [form.os_type_id]);

  const set = (key, val) => setForm(f => ({ ...f, [key]: val }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!canWrite) return toast.error('You do not have write access');
    setSaving(true);
    try {
      const payload = { ...form };
      // Convert empty strings to null for FK fields
      ['asset_type_id','os_type_id','os_version_id','department_id','server_status_id',
       'patching_schedule_id','patching_type_id','location_id','eol_status_id','server_patch_type_id'
      ].forEach(k => { if (payload[k] === '') payload[k] = null; });

      if (editId) {
        await api.put(`/assets/${editId}`, payload);
        toast.success('Asset updated successfully');
      } else {
        await api.post('/assets', payload);
        toast.success('Asset added successfully');
        setForm(EMPTY_FORM);
        setOsVersions([]);
      }
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to save asset');
    } finally {
      setSaving(false);
    }
  };

  if (dropLoading) return <div className="text-slate-400 text-sm p-4">Loading form...</div>;

  return (
    <div className="space-y-6 fade-in max-w-5xl">
      <div className="page-header">
        <div className="flex items-center gap-3">
          {editId && (
            <button onClick={() => navigate('/assets')} className="text-slate-400 hover:text-white">
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}
          <div>
            <h1 className="page-title">{editId ? 'Edit Asset' : 'Add New Asset'}</h1>
            <p className="text-sm text-slate-500 mt-0.5">{editId ? 'Update asset details' : 'Register a new infrastructure asset'}</p>
          </div>
        </div>
        {!canWrite && (
          <span className="text-xs bg-amber-500/10 text-amber-400 border border-amber-500/30 px-3 py-1.5 rounded-lg">
            Read-only mode
          </span>
        )}
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Basic Info */}
        <FormSection title="Asset Identification">
          <Field label="VM Name">
            <input className="form-input" value={form.vm_name} onChange={e => set('vm_name', e.target.value)} placeholder="PROD-WEB-01" disabled={!canWrite} />
          </Field>
          <Field label="OS Hostname">
            <input className="form-input" value={form.os_hostname} onChange={e => set('os_hostname', e.target.value)} placeholder="webserver01.domain.local" disabled={!canWrite} />
          </Field>
          <Field label="IP Address">
            <input className="form-input" value={form.ip_address} onChange={e => set('ip_address', e.target.value)} placeholder="192.168.1.10" disabled={!canWrite} />
          </Field>
          <Field label="Serial Number">
            <input className="form-input" value={form.serial_number} onChange={e => set('serial_number', e.target.value)} placeholder="SN-XXXX-XXXX" disabled={!canWrite} />
          </Field>
          <Field label="Host Details" full>
            <input className="form-input" value={form.host_details} onChange={e => set('host_details', e.target.value)} placeholder="Dell PowerEdge R740, 32GB RAM, 8-core" disabled={!canWrite} />
          </Field>
        </FormSection>

        {/* Classification */}
        <FormSection title="Asset Classification">
          <Field label="Asset Type">
            <select className="form-select" value={form.asset_type_id} onChange={e => set('asset_type_id', e.target.value)} disabled={!canWrite}>
              <option value="">Select...</option>
              {dropdowns.asset_types?.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}
            </select>
          </Field>
          <Field label="OS Type">
            <select className="form-select" value={form.os_type_id} onChange={e => { set('os_type_id', e.target.value); set('os_version_id', ''); }} disabled={!canWrite}>
              <option value="">Select...</option>
              {dropdowns.os_types?.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}
            </select>
          </Field>
          <Field label="OS Version">
            <select className="form-select" value={form.os_version_id} onChange={e => set('os_version_id', e.target.value)} disabled={!canWrite || !form.os_type_id}>
              <option value="">{form.os_type_id ? 'Select version...' : 'Select OS Type first'}</option>
              {osVersions.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}
            </select>
          </Field>
          <Field label="Location">
            <select className="form-select" value={form.location_id} onChange={e => set('location_id', e.target.value)} disabled={!canWrite}>
              <option value="">Select...</option>
              {dropdowns.locations?.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}
            </select>
          </Field>
          <Field label="EOL Status">
            <select className="form-select" value={form.eol_status_id} onChange={e => set('eol_status_id', e.target.value)} disabled={!canWrite}>
              <option value="">Select...</option>
              {dropdowns.eol_status?.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}
            </select>
          </Field>
        </FormSection>

        {/* Ownership */}
        <FormSection title="Ownership & Purpose">
          <Field label="Assigned User">
            <input className="form-input" value={form.assigned_user} onChange={e => set('assigned_user', e.target.value)} placeholder="John Smith" disabled={!canWrite} />
          </Field>
          <Field label="Department">
            <select className="form-select" value={form.department_id} onChange={e => set('department_id', e.target.value)} disabled={!canWrite}>
              <option value="">Select...</option>
              {dropdowns.departments?.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}
            </select>
          </Field>
          <Field label="Business Purpose" full>
            <input className="form-input" value={form.business_purpose} onChange={e => set('business_purpose', e.target.value)} placeholder="Production web server for main application" disabled={!canWrite} />
          </Field>
        </FormSection>

        {/* Status & Patching */}
        <FormSection title="Status & Patching">
          <Field label="Server Status">
            <select className="form-select" value={form.server_status_id} onChange={e => set('server_status_id', e.target.value)} disabled={!canWrite}>
              <option value="">Select...</option>
              {dropdowns.server_status?.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}
            </select>
          </Field>
          <Field label="Server Patch Type">
            <select className="form-select" value={form.server_patch_type_id} onChange={e => set('server_patch_type_id', e.target.value)} disabled={!canWrite}>
              <option value="">Select...</option>
              {dropdowns.server_patch_type?.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}
            </select>
          </Field>
          <Field label="Patching Schedule">
            <select className="form-select" value={form.patching_schedule_id} onChange={e => set('patching_schedule_id', e.target.value)} disabled={!canWrite}>
              <option value="">Select...</option>
              {dropdowns.patching_schedule?.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}
            </select>
          </Field>
          <Field label="Patching Type">
            <select className="form-select" value={form.patching_type_id} onChange={e => set('patching_type_id', e.target.value)} disabled={!canWrite}>
              <option value="">Select...</option>
              {dropdowns.patching_type?.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}
            </select>
          </Field>
        </FormSection>

        {/* Agent Status */}
        <div className="card">
          <h3 className="text-sm font-semibold text-slate-300 border-b border-slate-800 pb-2 mb-4">Agent Status</h3>
          <div className="grid grid-cols-2 gap-6">
            <div className="flex items-center justify-between p-3 bg-slate-800 rounded-lg">
              <div>
                <p className="text-sm font-medium text-white">ManageEngine</p>
                <p className="text-xs text-slate-500">Agent installed</p>
              </div>
              <Toggle checked={form.me_installed_status} onChange={v => set('me_installed_status', v)} disabled={!canWrite} />
            </div>
            <div className="flex items-center justify-between p-3 bg-slate-800 rounded-lg">
              <div>
                <p className="text-sm font-medium text-white">Tenable</p>
                <p className="text-xs text-slate-500">Agent installed</p>
              </div>
              <Toggle checked={form.tenable_installed_status} onChange={v => set('tenable_installed_status', v)} disabled={!canWrite} />
            </div>
          </div>
        </div>

        {/* iDRAC */}
        <div className="card">
          <h3 className="text-sm font-semibold text-slate-300 border-b border-slate-800 pb-2 mb-4">iDRAC / Remote Management</h3>
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3">
              <Toggle checked={form.idrac_enabled} onChange={v => { set('idrac_enabled', v); if (!v) set('idrac_ip', ''); }} disabled={!canWrite} />
              <span className="text-sm text-white">iDRAC Enabled</span>
            </div>
            {form.idrac_enabled && (
              <div className="flex-1 max-w-xs">
                <input className="form-input" value={form.idrac_ip} onChange={e => set('idrac_ip', e.target.value)}
                  placeholder="iDRAC IP Address" disabled={!canWrite} />
              </div>
            )}
          </div>
        </div>

        {/* Credentials */}
        <FormSection title="Asset Credentials">
          <Field label="Username">
            <input className="form-input" value={form.asset_username} onChange={e => set('asset_username', e.target.value)} placeholder="admin" disabled={!canWrite} />
          </Field>
          <Field label="Password">
            <div className="relative">
              <input type={showPw ? 'text' : 'password'} className="form-input pr-10"
                value={form.asset_password} onChange={e => set('asset_password', e.target.value)} disabled={!canWrite} />
              <button type="button" onClick={() => setShowPw(s => !s)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white">
                {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </Field>
        </FormSection>

        {/* Remarks */}
        <div className="card">
          <h3 className="text-sm font-semibold text-slate-300 border-b border-slate-800 pb-2 mb-4">Additional Information</h3>
          <label className="form-label">Remarks</label>
          <textarea className="form-input min-h-[80px] resize-none" value={form.additional_remarks}
            onChange={e => set('additional_remarks', e.target.value)} placeholder="Any additional notes..." disabled={!canWrite} />
        </div>

        {/* Actions */}
        {canWrite && (
          <div className="flex items-center gap-3">
            <button type="submit" className="btn-primary" disabled={saving}>
              <Save className="w-4 h-4" />
              {saving ? 'Saving...' : editId ? 'Update Asset' : 'Add Asset'}
            </button>
            <button type="button" className="btn-secondary" onClick={() => { setForm(EMPTY_FORM); setOsVersions([]); }}>
              <X className="w-4 h-4" /> Clear Form
            </button>
            {editId && (
              <button type="button" className="btn-secondary" onClick={() => navigate('/assets')}>
                Cancel
              </button>
            )}
          </div>
        )}
      </form>
    </div>
  );
}
