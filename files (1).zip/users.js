const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const pool = require('../db/pool');
const { authenticate, requireAdmin } = require('../middleware/auth');

// GET /api/users - admin only
router.get('/', authenticate, requireAdmin, async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT id, username, email, role, is_active, created_at FROM users ORDER BY created_at'
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// PUT /api/users/:id - admin update role/status
router.put('/:id', authenticate, requireAdmin, async (req, res) => {
  const { role, is_active, password } = req.body;
  try {
    if (password) {
      const hash = await bcrypt.hash(password, 10);
      await pool.query('UPDATE users SET role=$1, is_active=$2, password_hash=$3 WHERE id=$4', [role, is_active, hash, req.params.id]);
    } else {
      await pool.query('UPDATE users SET role=$1, is_active=$2 WHERE id=$3', [role, is_active, req.params.id]);
    }
    const result = await pool.query('SELECT id, username, email, role, is_active FROM users WHERE id=$1', [req.params.id]);
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// DELETE /api/users/:id
router.delete('/:id', authenticate, requireAdmin, async (req, res) => {
  try {
    if (req.user.id === parseInt(req.params.id)) return res.status(400).json({ error: 'Cannot delete yourself' });
    await pool.query('DELETE FROM users WHERE id=$1', [req.params.id]);
    res.json({ message: 'User deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/users/permissions/:userId
router.get('/permissions/:userId', authenticate, requireAdmin, async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM user_page_permissions WHERE user_id=$1', [req.params.userId]);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// PUT /api/users/permissions/:userId
router.put('/permissions/:userId', authenticate, requireAdmin, async (req, res) => {
  const { permissions } = req.body; // [{page_key, is_visible}]
  try {
    for (const p of permissions) {
      await pool.query(
        `INSERT INTO user_page_permissions (user_id, page_key, is_visible) VALUES ($1,$2,$3)
         ON CONFLICT (user_id, page_key) DO UPDATE SET is_visible=$3`,
        [req.params.userId, p.page_key, p.is_visible]
      );
    }
    res.json({ message: 'Permissions updated' });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
