const express = require('express');
const router = express.Router();
const pool = require('../db/pool');
const { authenticate } = require('../middleware/auth');

router.get('/summary', authenticate, async (req, res) => {
  try {
    const [total, types, me, tenable, patchType, status, locationDist] = await Promise.all([
      pool.query('SELECT COUNT(*) as count FROM assets'),
      pool.query(`SELECT at2.name, COUNT(*) as count FROM assets a LEFT JOIN asset_types at2 ON a.asset_type_id = at2.id GROUP BY at2.name`),
      pool.query(`SELECT COUNT(*) as count FROM assets WHERE me_installed_status = true`),
      pool.query(`SELECT COUNT(*) as count FROM assets WHERE tenable_installed_status = true`),
      pool.query(`SELECT pt.name, COUNT(*) as count FROM assets a LEFT JOIN patching_type pt ON a.patching_type_id = pt.id GROUP BY pt.name`),
      pool.query(`SELECT ss.name, COUNT(*) as count FROM assets a LEFT JOIN server_status ss ON a.server_status_id = ss.id GROUP BY ss.name`),
      pool.query(`SELECT l.name, COUNT(*) as count FROM assets a LEFT JOIN locations l ON a.location_id = l.id GROUP BY l.name ORDER BY count DESC`),
    ]);

    const typeMap = {};
    types.rows.forEach(r => { typeMap[r.name] = parseInt(r.count); });
    const patchMap = {};
    patchType.rows.forEach(r => { patchMap[r.name] = parseInt(r.count); });
    const statusMap = {};
    status.rows.forEach(r => { statusMap[r.name] = parseInt(r.count); });

    res.json({
      total_assets: parseInt(total.rows[0].count),
      vm_count: typeMap['VM'] || 0,
      physical_server_count: typeMap['Physical Server'] || 0,
      me_installed_count: parseInt(me.rows[0].count),
      tenable_installed_count: parseInt(tenable.rows[0].count),
      auto_patch_count: patchMap['Auto'] || 0,
      manual_patch_count: patchMap['Manual'] || 0,
      alive_servers: statusMap['Alive'] || 0,
      powered_off_servers: statusMap['Powered Off'] || 0,
      not_alive_servers: statusMap['Not Alive'] || 0,
      location_distribution: locationDist.rows,
      asset_type_distribution: types.rows,
      patch_type_distribution: patchType.rows,
      status_distribution: status.rows,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
