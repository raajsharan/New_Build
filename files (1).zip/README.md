# InfraVault — Infrastructure Inventory Management System

A professional full-stack web application for infrastructure teams to manually manage server and VM assets, track patching status, monitor agent installations, and control asset ownership.

---

## 🗂 Project Structure

```
infra-inventory/
├── backend/                  # Node.js + Express REST API
│   ├── db/pool.js            # PostgreSQL connection pool
│   ├── middleware/auth.js    # JWT authentication middleware
│   ├── routes/
│   │   ├── auth.js           # Login, register, /me
│   │   ├── assets.js         # Asset CRUD + CSV import
│   │   ├── config.js         # Dropdown management
│   │   ├── dashboard.js      # Dashboard stats
│   │   ├── users.js          # User & permissions management
│   │   └── settings.js       # App settings & custom fields
│   ├── server.js             # Express app entry point
│   └── .env.example          # Environment variable template
├── frontend/                 # React + TailwindCSS
│   └── src/
│       ├── pages/            # All page components
│       ├── components/       # Shared UI components
│       ├── context/          # Auth & Settings context
│       └── utils/            # Custom hooks
└── database_setup.sql        # Full PostgreSQL setup script
```

---

## 🚀 Quick Start

### 1. PostgreSQL Database Setup

```bash
# Access PostgreSQL
sudo -u postgres psql

# Run the setup script
\i /path/to/infra-inventory/database_setup.sql
```

Or copy-paste the contents of `database_setup.sql` into your PostgreSQL client.

### 2. Backend Setup

```bash
cd backend

# Install dependencies
npm install

# Create environment file
cp .env.example .env
# Edit .env with your PostgreSQL credentials and JWT secret

# Start server
npm start
# or for development:
npm run dev
```

Backend runs at: `http://localhost:5000`

### 3. Frontend Setup

```bash
cd frontend

# Install dependencies
npm install

# Start dev server
npm run dev

# Production build
npm run build
```

Frontend runs at: `http://localhost:3000`

---

## 🔐 Default Credentials

| Field | Value |
|-------|-------|
| Email | admin@infra.local |
| Password | admin123 |
| Role | Admin (full access) |

**Change the admin password immediately after first login.**

---

## 📖 Features

### Authentication
- JWT-based login with 24h token expiry
- Self-service user registration (read-only by default)
- Three roles: **Admin**, **Read/Write**, **Read Only**

### Dashboard
- Live stats: total assets, ME/Tenable installed counts, server status
- Pie charts: VM vs Physical, patching type, server status
- Bar chart: location distribution
- Auto-refreshes every 30 seconds

### Asset Inventory (Two Pages)
**Add Asset Page:**
- Full form with all fields
- iDRAC toggle (shows IP field when enabled)
- OS Version auto-filtered by OS Type
- ManageEngine & Tenable agent toggles
- Asset credentials (username/password with reveal)
- Edit mode via URL query param `?edit={id}`

**Asset List Page:**
- Searchable by hostname, IP, VM name, user
- Filterable by location, department, status, asset type
- Paginated (20 per page)
- Bulk CSV import with template download
- Password column visibility toggle (admin-controlled)
- Color-coded status badges

### Inventory Configuration
- Manage all dropdown values in one page
- Collapsible sections per dropdown type
- OS Versions linked to OS Types
- Add, edit, delete values

### Admin Pages
- **User Management**: change roles, enable/disable, reset passwords
- **Access Control**: per-user page visibility + global password visibility
- **Custom Fields**: define textbox/dropdown/toggle fields for future use
- **App Settings**: customize app name, company name, logo URL
- **Database Setup**: step-by-step SQL commands with copy buttons

### CSV Bulk Import
Download the template CSV, fill in asset data, upload to import multiple assets at once. Dropdown values are matched by name (case-insensitive).

CSV columns:
```
vm_name, os_hostname, ip_address, asset_type, os_type, os_version,
assigned_user, department, business_purpose, server_status,
me_installed, tenable_installed, patching_schedule, patching_type,
location, additional_remarks, host_details, serial_number,
idrac_enabled, idrac_ip, eol_status, server_patch_type,
asset_username, asset_password
```

---

## 🗄 Database Schema

### Main Tables
- `assets` — all infrastructure assets
- `users` — user accounts

### Lookup Tables (dropdowns)
- `asset_types`, `os_types`, `os_versions`, `departments`
- `server_status`, `patching_schedule`, `patching_type`
- `locations`, `server_patch_type`, `eol_status`

### Support Tables
- `custom_fields` — admin-defined custom form fields
- `app_settings` — branding/configuration key-value store
- `user_page_permissions` — per-user page access control

---

## 🔌 API Reference

### Auth
| Method | Path | Description |
|--------|------|-------------|
| POST | /api/auth/login | Login |
| POST | /api/auth/register | Register |
| GET | /api/auth/me | Current user |

### Assets
| Method | Path | Description |
|--------|------|-------------|
| GET | /api/assets | List assets (with search/filter/pagination) |
| GET | /api/assets/:id | Get single asset |
| POST | /api/assets | Create asset |
| PUT | /api/assets/:id | Update asset |
| DELETE | /api/assets/:id | Delete asset |
| POST | /api/assets/import/csv | Bulk import |
| GET | /api/assets/template/csv | Download CSV template |

### Config (Dropdowns)
| Method | Path | Description |
|--------|------|-------------|
| GET | /api/config/:table | List dropdown values |
| POST | /api/config/:table | Add value |
| PUT | /api/config/:table/:id | Update value |
| DELETE | /api/config/:table/:id | Delete value |

Valid tables: `asset_types`, `os_types`, `os_versions`, `departments`, `server_status`, `patching_schedule`, `patching_type`, `locations`, `server_patch_type`, `eol_status`

### Dashboard
| Method | Path | Description |
|--------|------|-------------|
| GET | /api/dashboard/summary | All stats & chart data |

### Users (Admin only)
| Method | Path | Description |
|--------|------|-------------|
| GET | /api/users | List all users |
| PUT | /api/users/:id | Update user role/status |
| DELETE | /api/users/:id | Delete user |
| GET | /api/users/permissions/:userId | Get user page permissions |
| PUT | /api/users/permissions/:userId | Update user page permissions |

### Settings (Admin only)
| Method | Path | Description |
|--------|------|-------------|
| GET | /api/settings | Get all settings |
| PUT | /api/settings | Update settings |
| GET | /api/settings/custom-fields | List custom fields |
| POST | /api/settings/custom-fields | Add custom field |
| PUT | /api/settings/custom-fields/:id | Update custom field |
| DELETE | /api/settings/custom-fields/:id | Delete custom field |

---

## 🛠 Tech Stack

| Layer | Technology |
|-------|------------|
| Frontend | React 18, React Router 6, TailwindCSS 3 |
| Charts | Recharts |
| Backend | Node.js, Express 4 |
| Database | PostgreSQL 13+ |
| Auth | JWT (jsonwebtoken), bcrypt |
| File Upload | Multer, csv-parse |

---

## 🔒 Security Notes

1. Change JWT_SECRET in production to a long random string
2. Change admin@infra.local password immediately
3. Use HTTPS in production
4. Restrict PostgreSQL access to localhost or trusted IPs
5. Consider encrypting stored passwords in the assets table for production

---

## 📝 Sample Assets (pre-loaded)

| VM Name | Hostname | IP | Type | Status |
|---------|----------|----|------|--------|
| PROD-WEB-01 | webserver01.infra.local | 192.168.1.10 | VM | Alive |
| PROD-DB-01 | dbserver01.infra.local | 192.168.1.20 | Physical | Alive |
| DEV-APP-01 | devapp01.infra.local | 192.168.2.10 | VM | Alive |
| BACKUP-01 | backup01.infra.local | 192.168.1.30 | Physical | Powered Off |
