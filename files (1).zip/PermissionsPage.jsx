import React, { useState, useEffect } from 'react';
import { api } from '../context/AuthContext';
import { useSettings } from '../context/SettingsContext';
import Toggle from '../components/Toggle';
import { Shield, Eye, Save } from 'lucide-react';
import toast from 'react-hot-toast';

const ALL_PAGES = [
  { key: 'dashboard', label: 'Dashboard' },
  { key: 'add_asset', label: 'Add Asset' },
  { key: 'asset_list', label: 'Asset Inventory' },
  { key: 'config', label: 'Inventory Config' },
];

export default function PermissionsPage() {
  const { settings, refresh: refreshSettings } = useSettings();
  const [users, setUsers] = useState([]);
  const [permissions, setPermissions] = useState({}); // {userId: {page_key: bool}}
  const [pwVisible, setPwVisible] = useState(settings.password_visibility_enabled === 'true');
  const [saving, setSaving] = useState(false);
  const [savingPerm, setSavingPerm] = useState(null);

  useEffect(() => {
    setPwVisible(settings.password_visibility_enabled === 'true');
  }, [settings]);

  useEffect(() => {
    api.get('/users').then(res => {
      const nonAdmins = res.data.filter(u => u.role !== 'admin');
      setUsers(nonAdmins);
      // Load permissions for each user
      Promise.all(nonAdmins.map(u => api.get(`/users/permissions/${u.id}`).then(r => ({ userId: u.id, perms: r.data })))).then(results => {
        const map = {};
        results.forEach(({ userId, perms }) => {
          map[userId] = {};
          ALL_PAGES.forEach(p => { map[userId][p.key] = true; }); // default: all visible
          perms.forEach(p => { map[userId][p.page_key] = p.is_visible; });
        });
        setPermissions(map);
      });
    });
  }, []);

  const handlePwVisibility = async (val) => {
    setPwVisible(val);
    try {
      await api.put('/settings', { password_visibility_enabled: String(val) });
      refreshSettings();
      toast.success(val ? 'Password column visible' : 'Password column hidden');
    } catch { toast.error('Failed to update'); }
  };

  const handlePermToggle = (userId, pageKey, val) => {
    setPermissions(prev => ({
      ...prev,
      [userId]: { ...prev[userId], [pageKey]: val }
    }));
  };

  const savePermissions = async (userId) => {
    setSavingPerm(userId);
    try {
      const perms = ALL_PAGES.map(p => ({ page_key: p.key, is_visible: permissions[userId]?.[p.key] ?? true }));
      await api.put(`/users/permissions/${userId}`, { permissions: perms });
      toast.success('Permissions saved');
    } catch { toast.error('Failed to save'); }
    finally { setSavingPerm(null); }
  };

  return (
    <div className="space-y-6 fade-in max-w-4xl">
      <div className="page-header">
        <div>
          <h1 className="page-title">Access Control</h1>
          <p className="text-sm text-slate-500 mt-0.5">Control password visibility and page access per user</p>
        </div>
      </div>

      {/* Password visibility */}
      <div className="card">
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center mt-0.5">
              <Eye className="w-4 h-4 text-blue-400" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-white">Asset Password Visibility</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                When enabled, the Password column appears in the Asset Inventory table.
                Individual users can further toggle visibility with the eye icon.
              </p>
            </div>
          </div>
          <Toggle checked={pwVisible} onChange={handlePwVisibility} />
        </div>
      </div>

      {/* Per-user page permissions */}
      <div className="card">
        <div className="flex items-center gap-2 mb-4 pb-3 border-b border-slate-800">
          <Shield className="w-4 h-4 text-purple-400" />
          <h3 className="text-sm font-semibold text-white">Page Visibility per User</h3>
        </div>

        {users.length === 0 ? (
          <p className="text-sm text-slate-500 py-4 text-center">No non-admin users registered yet</p>
        ) : (
          <div className="space-y-4">
            {users.map(user => (
              <div key={user.id} className="bg-slate-800/50 rounded-xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <p className="text-sm font-medium text-white">{user.username}</p>
                    <p className="text-xs text-slate-500">{user.email} · <span className={user.role === 'read_write' ? 'text-blue-400' : 'text-slate-400'}>{user.role}</span></p>
                  </div>
                  <button onClick={() => savePermissions(user.id)} className="btn-primary text-xs px-3 py-1.5" disabled={savingPerm === user.id}>
                    <Save className="w-3 h-3" />
                    {savingPerm === user.id ? 'Saving...' : 'Save'}
                  </button>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {ALL_PAGES.map(page => (
                    <div key={page.key} className="flex items-center justify-between p-2.5 bg-slate-800 rounded-lg">
                      <span className="text-xs text-slate-300">{page.label}</span>
                      <Toggle
                        checked={permissions[user.id]?.[page.key] ?? true}
                        onChange={val => handlePermToggle(user.id, page.key, val)}
                      />
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
