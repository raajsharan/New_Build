const express = require('express');
const router = express.Router();
const pool = require('../db/pool');
const { authenticate, requireAdmin, requireWriteAccess } = require('../middleware/auth');

const VALID_TABLES = ['asset_types', 'os_types', 'os_versions', 'departments', 'server_status',
  'patching_schedule', 'patching_type', 'locations', 'server_patch_type', 'eol_status'];

// GET /api/config/:table
router.get('/:table', authenticate, async (req, res) => {
  const { table } = req.params;
  if (!VALID_TABLES.includes(table)) return res.status(400).json({ error: 'Invalid table' });
  try {
    let query = `SELECT * FROM ${table}`;
    let params = [];
    if (table === 'os_versions' && req.query.os_type_id) {
      query += ' WHERE os_type_id = $1 ORDER BY name';
      params = [req.query.os_type_id];
    } else {
      query += ' ORDER BY name';
    }
    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /api/config/:table
router.post('/:table', authenticate, requireWriteAccess, async (req, res) => {
  const { table } = req.params;
  if (!VALID_TABLES.includes(table)) return res.status(400).json({ error: 'Invalid table' });
  try {
    const { name, os_type_id } = req.body;
    if (!name) return res.status(400).json({ error: 'Name is required' });
    let result;
    if (table === 'os_versions') {
      result = await pool.query(`INSERT INTO ${table} (name, os_type_id) VALUES ($1, $2) RETURNING *`, [name, os_type_id || null]);
    } else {
      result = await pool.query(`INSERT INTO ${table} (name) VALUES ($1) RETURNING *`, [name]);
    }
    res.status(201).json(result.rows[0]);
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: 'Value already exists' });
    res.status(500).json({ error: 'Server error' });
  }
});

// PUT /api/config/:table/:id
router.put('/:table/:id', authenticate, requireWriteAccess, async (req, res) => {
  const { table, id } = req.params;
  if (!VALID_TABLES.includes(table)) return res.status(400).json({ error: 'Invalid table' });
  try {
    const { name, os_type_id } = req.body;
    let result;
    if (table === 'os_versions') {
      result = await pool.query(`UPDATE ${table} SET name=$1, os_type_id=$2 WHERE id=$3 RETURNING *`, [name, os_type_id || null, id]);
    } else {
      result = await pool.query(`UPDATE ${table} SET name=$1 WHERE id=$2 RETURNING *`, [name, id]);
    }
    if (result.rows.length === 0) return res.status(404).json({ error: 'Not found' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// DELETE /api/config/:table/:id
router.delete('/:table/:id', authenticate, requireWriteAccess, async (req, res) => {
  const { table, id } = req.params;
  if (!VALID_TABLES.includes(table)) return res.status(400).json({ error: 'Invalid table' });
  try {
    const result = await pool.query(`DELETE FROM ${table} WHERE id = $1 RETURNING *`, [id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Not found' });
    res.json({ message: 'Deleted' });
  } catch (err) {
    if (err.code === '23503') return res.status(409).json({ error: 'Cannot delete - value is in use' });
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
