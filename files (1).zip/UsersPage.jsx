import React, { useState, useEffect } from 'react';
import { api } from '../context/AuthContext';
import { useAuth } from '../context/AuthContext';
import { Edit2, Trash2, Save, X, Users } from 'lucide-react';
import toast from 'react-hot-toast';

const ROLE_OPTIONS = [
  { value: 'admin', label: 'Admin', color: 'text-purple-400' },
  { value: 'read_write', label: 'Read/Write', color: 'text-blue-400' },
  { value: 'read_only', label: 'Read Only', color: 'text-slate-400' },
];

export default function UsersPage() {
  const { user: me } = useAuth();
  const [users, setUsers] = useState([]);
  const [editId, setEditId] = useState(null);
  const [editData, setEditData] = useState({});
  const [loading, setLoading] = useState(true);

  const load = async () => {
    try {
      const res = await api.get('/users');
      setUsers(res.data);
    } catch { toast.error('Failed to load users'); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const startEdit = (u) => {
    setEditId(u.id);
    setEditData({ role: u.role, is_active: u.is_active, password: '' });
  };

  const handleUpdate = async (id) => {
    try {
      const payload = { role: editData.role, is_active: editData.is_active };
      if (editData.password) payload.password = editData.password;
      await api.put(`/users/${id}`, payload);
      toast.success('User updated');
      setEditId(null);
      load();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Update failed');
    }
  };

  const handleDelete = async (id, username) => {
    if (id === me.id) return toast.error("Can't delete yourself");
    if (!window.confirm(`Delete user "${username}"?`)) return;
    try {
      await api.delete(`/users/${id}`);
      toast.success('User deleted');
      load();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Delete failed');
    }
  };

  const roleColor = (role) => ROLE_OPTIONS.find(r => r.value === role)?.color || 'text-slate-400';

  return (
    <div className="space-y-4 fade-in max-w-4xl">
      <div className="page-header">
        <div>
          <h1 className="page-title">User Management</h1>
          <p className="text-sm text-slate-500 mt-0.5">Manage user accounts and role assignments</p>
        </div>
        <div className="flex items-center gap-2 text-xs text-slate-500">
          <Users className="w-4 h-4" /> {users.length} users
        </div>
      </div>

      <div className="card p-0 overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-800/50 border-b border-slate-800">
            <tr>
              {['Username','Email','Role','Status','Password','Registered','Actions'].map(h => (
                <th key={h} className="table-th">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/50">
            {loading ? (
              <tr><td colSpan={7} className="text-center py-8 text-slate-500">Loading...</td></tr>
            ) : users.map(u => (
              <tr key={u.id} className="hover:bg-slate-800/20">
                <td className="table-td font-medium">
                  {u.username}
                  {u.id === me.id && <span className="ml-2 text-xs text-blue-400">(you)</span>}
                </td>
                <td className="table-td text-slate-400">{u.email}</td>
                <td className="table-td">
                  {editId === u.id ? (
                    <select className="form-select text-xs py-1" value={editData.role}
                      onChange={e => setEditData(d => ({ ...d, role: e.target.value }))}>
                      {ROLE_OPTIONS.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
                    </select>
                  ) : (
                    <span className={`text-sm font-medium ${roleColor(u.role)}`}>
                      {ROLE_OPTIONS.find(r => r.value === u.role)?.label}
                    </span>
                  )}
                </td>
                <td className="table-td">
                  {editId === u.id ? (
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="checkbox" checked={editData.is_active}
                        onChange={e => setEditData(d => ({ ...d, is_active: e.target.checked }))} />
                      <span className="text-xs">Active</span>
                    </label>
                  ) : (
                    <span className={`text-xs px-2 py-0.5 rounded-full border ${u.is_active ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30' : 'text-red-400 bg-red-500/10 border-red-500/30'}`}>
                      {u.is_active ? 'Active' : 'Disabled'}
                    </span>
                  )}
                </td>
                <td className="table-td">
                  {editId === u.id ? (
                    <input type="password" className="form-input text-xs py-1 w-32" placeholder="New password"
                      value={editData.password}
                      onChange={e => setEditData(d => ({ ...d, password: e.target.value }))} />
                  ) : <span className="text-slate-600 text-xs">••••••</span>}
                </td>
                <td className="table-td text-xs text-slate-500">
                  {new Date(u.created_at).toLocaleDateString()}
                </td>
                <td className="table-td">
                  <div className="flex items-center gap-1">
                    {editId === u.id ? (
                      <>
                        <button onClick={() => handleUpdate(u.id)} className="btn-edit">
                          <Save className="w-3 h-3" /> Save
                        </button>
                        <button onClick={() => setEditId(null)} className="btn-secondary text-xs px-2 py-1">
                          <X className="w-3 h-3" />
                        </button>
                      </>
                    ) : (
                      <>
                        <button onClick={() => startEdit(u)} className="btn-edit">
                          <Edit2 className="w-3 h-3" />
                        </button>
                        {u.id !== me.id && (
                          <button onClick={() => handleDelete(u.id, u.username)} className="btn-danger">
                            <Trash2 className="w-3 h-3" />
                          </button>
                        )}
                      </>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="card text-xs text-slate-500 space-y-1">
        <p className="font-medium text-slate-400">Role Permissions:</p>
        <p><span className="text-purple-400">Admin</span> — Full access: read, write, delete, manage users, configure settings</p>
        <p><span className="text-blue-400">Read/Write</span> — Can add, edit, and delete assets and dropdown values</p>
        <p><span className="text-slate-400">Read Only</span> — View-only access; no add/edit/delete operations</p>
      </div>
    </div>
  );
}
