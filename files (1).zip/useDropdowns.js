import { useState, useEffect } from 'react';
import { api } from '../context/AuthContext';

const cache = {};

export function useDropdowns() {
  const [dropdowns, setDropdowns] = useState({});
  const [loading, setLoading] = useState(true);

  const tables = [
    'asset_types', 'os_types', 'departments', 'server_status',
    'patching_schedule', 'patching_type', 'locations', 'server_patch_type', 'eol_status'
  ];

  useEffect(() => {
    const load = async () => {
      const results = await Promise.all(tables.map(t => api.get(`/config/${t}`)));
      const data = {};
      tables.forEach((t, i) => { data[t] = results[i].data; });
      setDropdowns(data);
      setLoading(false);
    };
    load();
  }, []);

  const fetchOsVersions = async (osTypeId) => {
    if (!osTypeId) return [];
    const res = await api.get(`/config/os_versions?os_type_id=${osTypeId}`);
    return res.data;
  };

  return { dropdowns, loading, fetchOsVersions };
}
