const express = require('express');
const router = express.Router();
const pool = require('../db/pool');
const { authenticate, requireAdmin } = require('../middleware/auth');

// GET /api/settings
router.get('/', authenticate, async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM app_settings');
    const settings = {};
    result.rows.forEach(r => { settings[r.setting_key] = r.setting_value; });
    res.json(settings);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// PUT /api/settings
router.put('/', authenticate, requireAdmin, async (req, res) => {
  try {
    const { app_name, company_name, logo_url, password_visibility_enabled } = req.body;
    const updates = { app_name, company_name, logo_url, password_visibility_enabled };
    for (const [key, value] of Object.entries(updates)) {
      if (value !== undefined) {
        await pool.query(
          `INSERT INTO app_settings (setting_key, setting_value) VALUES ($1,$2)
           ON CONFLICT (setting_key) DO UPDATE SET setting_value=$2, updated_at=CURRENT_TIMESTAMP`,
          [key, String(value)]
        );
      }
    }
    const result = await pool.query('SELECT * FROM app_settings');
    const settings = {};
    result.rows.forEach(r => { settings[r.setting_key] = r.setting_value; });
    res.json(settings);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Custom fields
router.get('/custom-fields', authenticate, async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM custom_fields WHERE is_active=true ORDER BY display_order, id');
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

router.post('/custom-fields', authenticate, requireAdmin, async (req, res) => {
  const { field_name, field_label, field_type, dropdown_options, display_order } = req.body;
  try {
    const result = await pool.query(
      'INSERT INTO custom_fields (field_name, field_label, field_type, dropdown_options, display_order) VALUES ($1,$2,$3,$4,$5) RETURNING *',
      [field_name, field_label, field_type, dropdown_options, display_order || 0]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: 'Field name already exists' });
    res.status(500).json({ error: 'Server error' });
  }
});

router.put('/custom-fields/:id', authenticate, requireAdmin, async (req, res) => {
  const { field_label, field_type, dropdown_options, is_active, display_order } = req.body;
  try {
    const result = await pool.query(
      'UPDATE custom_fields SET field_label=$1, field_type=$2, dropdown_options=$3, is_active=$4, display_order=$5 WHERE id=$6 RETURNING *',
      [field_label, field_type, dropdown_options, is_active, display_order, req.params.id]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

router.delete('/custom-fields/:id', authenticate, requireAdmin, async (req, res) => {
  try {
    await pool.query('DELETE FROM custom_fields WHERE id=$1', [req.params.id]);
    res.json({ message: 'Deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
