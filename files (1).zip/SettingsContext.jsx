import React, { createContext, useContext, useState, useEffect } from 'react';
import { api } from './AuthContext';

const SettingsContext = createContext({});

export function SettingsProvider({ children }) {
  const [settings, setSettings] = useState({
    app_name: 'InfraVault',
    company_name: 'Your Company',
    logo_url: '',
    password_visibility_enabled: 'false',
  });

  const loadSettings = async () => {
    try {
      const res = await api.get('/settings');
      setSettings(res.data);
    } catch {}
  };

  useEffect(() => { loadSettings(); }, []);

  const refresh = loadSettings;

  return (
    <SettingsContext.Provider value={{ settings, refresh }}>
      {children}
    </SettingsContext.Provider>
  );
}

export const useSettings = () => useContext(SettingsContext);
