-- Infrastructure Inventory Management System - PostgreSQL Database Schema
-- Database Name: infrastructure_inventory

-- Create Database
CREATE DATABASE infrastructure_inventory;

-- Connect to database
\c infrastructure_inventory;

-- =====================================================
-- LOOKUP TABLES (for dropdowns)
-- =====================================================

CREATE TABLE asset_types (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE os_types (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE os_versions (
    id SERIAL PRIMARY KEY,
    os_type_id INTEGER NOT NULL REFERENCES os_types(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(os_type_id, name)
);

CREATE TABLE departments (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE server_status (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE patching_schedule (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE patching_type (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE server_patch_type (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE locations (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================
-- USERS TABLE
-- =====================================================

CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100),
    is_admin BOOLEAN DEFAULT FALSE,
    can_write BOOLEAN DEFAULT TRUE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================
-- CUSTOM FIELDS TABLE (for dynamic asset fields)
-- =====================================================

CREATE TABLE custom_fields (
    id SERIAL PRIMARY KEY,
    field_name VARCHAR(100) NOT NULL UNIQUE,
    field_type VARCHAR(50) NOT NULL, -- textbox, dropdown, toggle
    field_label VARCHAR(100) NOT NULL,
    field_order INTEGER,
    is_active BOOLEAN DEFAULT TRUE,
    dropdown_options JSON, -- For storing dropdown options
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================
-- ASSETS TABLE (Main Table)
-- =====================================================

CREATE TABLE assets (
    id SERIAL PRIMARY KEY,
    vm_name VARCHAR(100) NOT NULL,
    os_hostname VARCHAR(100),
    ip_address VARCHAR(45),
    asset_type_id INTEGER REFERENCES asset_types(id),
    os_type_id INTEGER REFERENCES os_types(id),
    os_version_id INTEGER REFERENCES os_versions(id),
    assigned_user VARCHAR(100),
    department_id INTEGER REFERENCES departments(id),
    business_purpose TEXT,
    server_status_id INTEGER REFERENCES server_status(id),
    me_installed_status BOOLEAN DEFAULT FALSE,
    tenable_installed_status BOOLEAN DEFAULT FALSE,
    patching_schedule_id INTEGER REFERENCES patching_schedule(id),
    patching_type_id INTEGER REFERENCES patching_type(id),
    server_patch_type_id INTEGER REFERENCES server_patch_type(id),
    location_id INTEGER REFERENCES locations(id),
    additional_remarks TEXT,
    
    -- New fields for enhanced details
    host_details TEXT,
    serial_no VARCHAR(100),
    idrac_enabled BOOLEAN DEFAULT FALSE,
    idrac_ip VARCHAR(45),
    eol_status VARCHAR(50), -- InSupport, EOL, Decom
    asset_username VARCHAR(100),
    asset_password VARCHAR(255), -- Encrypted in production
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER REFERENCES users(id),
    updated_by INTEGER REFERENCES users(id)
);

-- =====================================================
-- ASSET CUSTOM FIELD VALUES TABLE
-- =====================================================

CREATE TABLE asset_custom_values (
    id SERIAL PRIMARY KEY,
    asset_id INTEGER NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
    custom_field_id INTEGER NOT NULL REFERENCES custom_fields(id) ON DELETE CASCADE,
    field_value TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(asset_id, custom_field_id)
);

-- =====================================================
-- PAGE VISIBILITY CONTROL TABLE
-- =====================================================

CREATE TABLE page_permissions (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    page_name VARCHAR(100) NOT NULL,
    is_visible BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, page_name)
);

-- =====================================================
-- PASSWORD VISIBILITY SETTINGS
-- =====================================================

CREATE TABLE password_visibility_settings (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    show_asset_passwords BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================
-- SETTINGS TABLE (Company branding, etc.)
-- =====================================================

CREATE TABLE settings (
    id SERIAL PRIMARY KEY,
    company_name VARCHAR(255) DEFAULT 'Infrastructure Management',
    logo_path VARCHAR(255),
    software_name VARCHAR(255) DEFAULT 'Asset Inventory System',
    primary_color VARCHAR(20) DEFAULT '#0066cc',
    secondary_color VARCHAR(20) DEFAULT '#333333',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================
-- AUDIT LOG TABLE
-- =====================================================

CREATE TABLE audit_logs (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    action VARCHAR(100),
    asset_id INTEGER REFERENCES assets(id),
    old_values JSON,
    new_values JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================
-- INDEXES (for performance)
-- =====================================================

CREATE INDEX idx_assets_vm_name ON assets(vm_name);
CREATE INDEX idx_assets_hostname ON assets(os_hostname);
CREATE INDEX idx_assets_ip_address ON assets(ip_address);
CREATE INDEX idx_assets_department ON assets(department_id);
CREATE INDEX idx_assets_location ON assets(location_id);
CREATE INDEX idx_assets_status ON assets(server_status_id);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_audit_logs_user ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_asset ON audit_logs(asset_id);

-- =====================================================
-- SEED DATA (Sample Data)
-- =====================================================

-- Asset Types
INSERT INTO asset_types (name) VALUES ('VM'), ('Physical Server');

-- OS Types
INSERT INTO os_types (name) VALUES ('Linux'), ('Windows'), ('ESXi');

-- OS Versions for Linux
INSERT INTO os_versions (os_type_id, name) 
SELECT id, 'Ubuntu 22.04 LTS' FROM os_types WHERE name = 'Linux'
UNION ALL
SELECT id, 'Ubuntu 20.04 LTS' FROM os_types WHERE name = 'Linux'
UNION ALL
SELECT id, 'CentOS 7' FROM os_types WHERE name = 'Linux'
UNION ALL
SELECT id, 'CentOS 8' FROM os_types WHERE name = 'Linux'
UNION ALL
SELECT id, 'RHEL 7' FROM os_types WHERE name = 'Linux'
UNION ALL
SELECT id, 'RHEL 8' FROM os_types WHERE name = 'Linux'
UNION ALL
SELECT id, 'Debian 11' FROM os_types WHERE name = 'Linux'
UNION ALL
SELECT id, 'Debian 12' FROM os_types WHERE name = 'Linux';

-- OS Versions for Windows
INSERT INTO os_versions (os_type_id, name) 
SELECT id, 'Windows Server 2019' FROM os_types WHERE name = 'Windows'
UNION ALL
SELECT id, 'Windows Server 2022' FROM os_types WHERE name = 'Windows'
UNION ALL
SELECT id, 'Windows Server 2016' FROM os_types WHERE name = 'Windows'
UNION ALL
SELECT id, 'Windows 10' FROM os_types WHERE name = 'Windows'
UNION ALL
SELECT id, 'Windows 11' FROM os_types WHERE name = 'Windows';

-- OS Versions for ESXi
INSERT INTO os_versions (os_type_id, name) 
SELECT id, 'ESXi 7.0' FROM os_types WHERE name = 'ESXi'
UNION ALL
SELECT id, 'ESXi 8.0' FROM os_types WHERE name = 'ESXi';

-- Departments
INSERT INTO departments (name) VALUES ('IT'), ('DevOps'), ('Security'), ('Application Team'), ('Infrastructure');

-- Server Status
INSERT INTO server_status (name) VALUES ('Alive'), ('Powered Off'), ('Not Alive');

-- Patching Schedule
INSERT INTO patching_schedule (name) VALUES ('Weekly'), ('Monthly'), ('Quarterly'), ('As Needed');

-- Patching Type
INSERT INTO patching_type (name) VALUES ('Auto'), ('Manual');

-- Server Patch Type
INSERT INTO server_patch_type (name) VALUES ('Critical'), ('Non-Critical'), ('Test');

-- Locations
INSERT INTO locations (name) VALUES ('DC1'), ('DC2'), ('Azure'), ('AWS'), ('Branch Office'), ('On-Premises');

-- Default Admin User (password: admin123, bcrypt hash)
INSERT INTO users (username, email, password_hash, full_name, is_admin, can_write, is_active) 
VALUES ('admin', 'admin@infra.local', '$2b$10$YIjqVhKW9VUrWWf7xZZMz.l68MXMp2K0cUn7EqWVnz2yJmHIL7K9K', 'System Administrator', TRUE, TRUE, TRUE);

-- Sample Assets (4 demo assets)
INSERT INTO assets (
    vm_name, os_hostname, ip_address, asset_type_id, os_type_id, os_version_id, 
    assigned_user, department_id, business_purpose, server_status_id, 
    me_installed_status, tenable_installed_status, patching_schedule_id, patching_type_id,
    server_patch_type_id, location_id, additional_remarks, host_details, serial_no, 
    idrac_enabled, idrac_ip, eol_status, asset_username, asset_password, created_by
)
VALUES (
    'WEB-SERVER-01', 'web-server-01.corp.local', '192.168.1.10', 
    (SELECT id FROM asset_types WHERE name = 'VM'), 
    (SELECT id FROM os_types WHERE name = 'Linux'),
    (SELECT id FROM os_versions WHERE name = 'Ubuntu 22.04 LTS'),
    'John Doe', (SELECT id FROM departments WHERE name = 'DevOps'), 
    'Production Web Server', (SELECT id FROM server_status WHERE name = 'Alive'),
    TRUE, TRUE, (SELECT id FROM patching_schedule WHERE name = 'Weekly'),
    (SELECT id FROM patching_type WHERE name = 'Auto'),
    (SELECT id FROM server_patch_type WHERE name = 'Critical'),
    (SELECT id FROM locations WHERE name = 'DC1'),
    'Primary production web server', '8vCPU, 16GB RAM', 'SN-001-WEB',
    TRUE, '192.168.1.100', 'InSupport', 'root', 'encrypted_password_1',
    (SELECT id FROM users WHERE username = 'admin')
),
(
    'DB-SERVER-01', 'db-server-01.corp.local', '192.168.1.20',
    (SELECT id FROM asset_types WHERE name = 'Physical Server'),
    (SELECT id FROM os_types WHERE name = 'Linux'),
    (SELECT id FROM os_versions WHERE name = 'RHEL 8'),
    'Jane Smith', (SELECT id FROM departments WHERE name = 'Infrastructure'),
    'Production Database Server', (SELECT id FROM server_status WHERE name = 'Alive'),
    TRUE, TRUE, (SELECT id FROM patching_schedule WHERE name = 'Monthly'),
    (SELECT id FROM patching_type WHERE name = 'Manual'),
    (SELECT id FROM server_patch_type WHERE name = 'Critical'),
    (SELECT id FROM locations WHERE name = 'DC1'),
    'PostgreSQL database server', '16vCPU, 64GB RAM', 'SN-002-DB',
    TRUE, '192.168.1.101', 'InSupport', 'postgres', 'encrypted_password_2',
    (SELECT id FROM users WHERE username = 'admin')
),
(
    'APP-SERVER-01', 'app-server-01.corp.local', '192.168.1.30',
    (SELECT id FROM asset_types WHERE name = 'VM'),
    (SELECT id FROM os_types WHERE name = 'Windows'),
    (SELECT id FROM os_versions WHERE name = 'Windows Server 2022'),
    'Mike Johnson', (SELECT id FROM departments WHERE name = 'Application Team'),
    'Application Server', (SELECT id FROM server_status WHERE name = 'Alive'),
    FALSE, TRUE, (SELECT id FROM patching_schedule WHERE name = 'Monthly'),
    (SELECT id FROM patching_type WHERE name = 'Manual'),
    (SELECT id FROM server_patch_type WHERE name = 'Non-Critical'),
    (SELECT id FROM locations WHERE name = 'Azure'),
    'Azure-hosted application server', '4vCPU, 8GB RAM', 'SN-003-APP',
    FALSE, NULL, 'InSupport', 'admin', 'encrypted_password_3',
    (SELECT id FROM users WHERE username = 'admin')
),
(
    'BACKUP-SERVER-01', 'backup-server-01.corp.local', '192.168.1.40',
    (SELECT id FROM asset_types WHERE name = 'Physical Server'),
    (SELECT id FROM os_types WHERE name = 'Linux'),
    (SELECT id FROM os_versions WHERE name = 'CentOS 8'),
    'Sarah Williams', (SELECT id FROM departments WHERE name = 'Infrastructure'),
    'Backup and Archive Server', (SELECT id FROM server_status WHERE name = 'Powered Off'),
    FALSE, FALSE, (SELECT id FROM patching_schedule WHERE name = 'Quarterly'),
    (SELECT id FROM patching_type WHERE name = 'Manual'),
    (SELECT id FROM server_patch_type WHERE name = 'Non-Critical'),
    (SELECT id FROM locations WHERE name = 'DC2'),
    'Offline backup storage', '8vCPU, 32GB RAM', 'SN-004-BACKUP',
    FALSE, NULL, 'EOL', 'backup', 'encrypted_password_4',
    (SELECT id FROM users WHERE username = 'admin')
);

-- Insert default settings
INSERT INTO settings (company_name, software_name, primary_color, secondary_color) 
VALUES ('Your Company', 'Infrastructure Inventory System', '#0066cc', '#333333');

-- Initialize page permissions for admin
INSERT INTO page_permissions (user_id, page_name, is_visible)
SELECT 
    (SELECT id FROM users WHERE username = 'admin') as user_id,
    page_name,
    TRUE
FROM (VALUES 
    ('Dashboard'), ('AssetForm'), ('AssetInventory'), 
    ('InventoryConfiguration'), ('UserManagement'), 
    ('Settings'), ('PasswordVisibility'), ('CustomFields')
) AS pages(page_name);

-- Initialize password visibility settings for admin
INSERT INTO password_visibility_settings (user_id, show_asset_passwords)
VALUES ((SELECT id FROM users WHERE username = 'admin'), TRUE);

-- Create sample custom field
INSERT INTO custom_fields (field_name, field_type, field_label, field_order, is_active, dropdown_options)
VALUES ('support_contract', 'dropdown', 'Support Contract Type', 1, TRUE, '["Gold", "Silver", "Bronze", "None"]');

COMMIT;
