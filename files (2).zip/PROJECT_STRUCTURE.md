# Infrastructure Inventory Management System - Project Structure

```
infrastructure-inventory-app/
│
├── backend/
│   ├── config/
│   │   ├── database.js
│   │   └── env.js
│   ├── controllers/
│   │   ├── authController.js
│   │   ├── assetController.js
│   │   ├── configController.js
│   │   ├── dashboardController.js
│   │   ├── userController.js
│   │   └── settingsController.js
│   ├── middleware/
│   │   ├── auth.js
│   │   └── errorHandler.js
│   ├── routes/
│   │   ├── authRoutes.js
│   │   ├── assetRoutes.js
│   │   ├── configRoutes.js
│   │   ├── dashboardRoutes.js
│   │   ├── userRoutes.js
│   │   └── settingsRoutes.js
│   ├── models/
│   │   ├── User.js
│   │   ├── Asset.js
│   │   └── Config.js
│   ├── utils/
│   │   ├── csvParser.js
│   │   └── validators.js
│   ├── .env
│   ├── .env.example
│   ├── server.js
│   ├── package.json
│   └── db/
│       └── init.sql
│
├── frontend/
│   ├── public/
│   │   └── index.html
│   ├── src/
│   │   ├── components/
│   │   │   ├── Sidebar.jsx
│   │   │   ├── Header.jsx
│   │   │   ├── DashboardCard.jsx
│   │   │   └── LoadingSpinner.jsx
│   │   ├── pages/
│   │   │   ├── Login.jsx
│   │   │   ├── Register.jsx
│   │   │   ├── Dashboard.jsx
│   │   │   ├── AssetForm.jsx
│   │   │   ├── AssetInventory.jsx
│   │   │   ├── InventoryConfiguration.jsx
│   │   │   ├── UserManagement.jsx
│   │   │   ├── Settings.jsx
│   │   │   ├── PasswordVisibility.jsx
│   │   │   └── CustomFields.jsx
│   │   ├── context/
│   │   │   ├── AuthContext.jsx
│   │   │   ├── AssetContext.jsx
│   │   │   └── ConfigContext.jsx
│   │   ├── hooks/
│   │   │   ├── useAuth.js
│   │   │   └── useApi.js
│   │   ├── services/
│   │   │   ├── api.js
│   │   │   └── auth.js
│   │   ├── utils/
│   │   │   ├── constants.js
│   │   │   └── helpers.js
│   │   ├── styles/
│   │   │   └── tailwind.config.js
│   │   ├── App.jsx
│   │   ├── main.jsx
│   │   └── index.css
│   ├── .env
│   ├── .env.example
│   ├── package.json
│   ├── tailwind.config.js
│   └── vite.config.js
│
├── docs/
│   ├── DATABASE_SETUP.md
│   ├── API_DOCUMENTATION.md
│   ├── SETUP_GUIDE.md
│   └── CSV_IMPORT_TEMPLATE.csv
│
├── docker-compose.yml
├── .gitignore
└── README.md
```

## Key Directories Explained

- **backend/config/**: Database and environment configuration
- **backend/controllers/**: Business logic for each module
- **backend/middleware/**: Authentication and error handling middleware
- **backend/routes/**: API route definitions
- **backend/models/**: Database model definitions
- **backend/utils/**: CSV parsing, validators, helpers
- **backend/db/**: Database initialization scripts

- **frontend/components/**: Reusable UI components
- **frontend/pages/**: Full page components
- **frontend/context/**: React Context for state management
- **frontend/hooks/**: Custom React hooks
- **frontend/services/**: API service calls
- **frontend/utils/**: Utility functions and constants

## File Organization Benefits

1. **Scalability**: Easy to add new modules
2. **Maintainability**: Clear separation of concerns
3. **Testability**: Each component is independently testable
4. **Collaboration**: Multiple developers can work on different areas
5. **Performance**: Code splitting and lazy loading optimization possible
