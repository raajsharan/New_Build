# QUICK START GUIDE

## Prerequisites Checklist

Before you begin, ensure you have:

- [ ] Node.js 16+ installed (check with `node -v`)
- [ ] npm 8+ installed (check with `npm -v`)
- [ ] PostgreSQL 12+ installed and running
- [ ] Git installed (check with `git -v`)
- [ ] ~2GB disk space available
- [ ] 4GB RAM minimum (8GB+ recommended)

## Installation Steps (5 minutes)

### Step 1: Clone Repository

```bash
git clone https://github.com/yourusername/infrastructure-inventory.git
cd infrastructure-inventory
```

### Step 2: Setup PostgreSQL Database

**On macOS/Linux:**
```bash
# Connect to PostgreSQL
psql -U postgres

# Create user and database (copy-paste these commands)
CREATE ROLE infra_user WITH PASSWORD 'secure_password' LOGIN;
ALTER ROLE infra_user CREATEDB;

# Exit psql
\q

# Initialize database schema
psql -U postgres -f database_init.sql
```

**On Windows:**
```bash
# Using PowerShell or Command Prompt
psql -U postgres

# Then run the same SQL commands above

# Exit
\q

# Initialize
psql -U postgres -f database_init.sql
```

**Verify Database:**
```bash
psql -U infra_user -h localhost -d infrastructure_inventory

# Should connect successfully. Type \q to exit.
```

### Step 3: Setup Backend

```bash
cd backend
npm install

# Create .env file
cp .env.example .env

# Edit .env with your database credentials
# Change only if different from defaults:
# DB_PASSWORD=secure_password
# JWT_SECRET=your-secret-key

npm start
```

✅ Backend running on http://localhost:5000

### Step 4: Setup Frontend (new terminal)

```bash
cd frontend
npm install

# Create .env file  
echo "VITE_API_URL=http://localhost:5000/api" > .env

npm run dev
```

✅ Frontend running on http://localhost:5173

### Step 5: Login

1. Open browser: http://localhost:5173
2. Enter credentials:
   - **Username:** admin@infra.local
   - **Password:** admin123
3. Click "Login"

✅ You're in! Change the password immediately.

---

## First Steps After Login

### 1. Change Admin Password
- Click user menu (top right)
- Go to Settings
- Update password

### 2. Explore Sample Data
- Go to **Dashboard** - view statistics
- Go to **Asset Inventory** - see 4 sample assets
- Click on any asset to view details

### 3. Add New Asset
- Click **Add Asset** button
- Fill in asset details
- Click **Add Asset**
- View it in Asset Inventory

### 4. Configure Dropdowns (Admin Only)
- Go to **Configuration**
- Edit or add new:
  - Asset Types
  - OS Types
  - Departments
  - Locations
  - And more...

### 5. Manage Users (Admin Only)
- Go to **User Management**
- Create new users
- Set permissions (Read Only vs Read & Write)

---

## Using Docker (Alternative)

Skip PostgreSQL and Node.js installation - use Docker instead:

```bash
# Build and start all services
docker-compose up -d

# Wait 30 seconds for database to initialize

# Access application
# Frontend: http://localhost:3000
# Backend: http://localhost:5000
# Database: localhost:5432
```

Stop services:
```bash
docker-compose down
```

---

## Common Issues & Solutions

### ❌ "Cannot connect to database"

**Solution:**
```bash
# Check PostgreSQL is running
psql -U postgres

# If fails, start PostgreSQL:
# macOS: brew services start postgresql
# Linux: sudo systemctl start postgresql
# Windows: Check Services app for PostgreSQL

# Verify .env credentials
cat backend/.env
```

### ❌ "Port 5000 already in use"

**Solution:**
```bash
# Kill process using port 5000
lsof -i :5000
kill -9 <PID>

# Or use different port
# Edit backend/.env: PORT=5001
```

### ❌ "Frontend can't reach backend"

**Solution:**
```bash
# Check backend is running
curl http://localhost:5000/api/dashboard/summary

# Check frontend .env
cat frontend/.env

# Should be: VITE_API_URL=http://localhost:5000/api
```

### ❌ "Login fails with credentials"

**Solution:**
```bash
# Make sure you used default credentials:
# Username: admin@infra.local
# Password: admin123

# If database wasn't initialized:
psql -U postgres -f database_init.sql

# Then restart backend: npm start
```

### ❌ "npm install fails"

**Solution:**
```bash
# Clear npm cache
npm cache clean --force

# Delete node_modules and lock file
rm -rf node_modules package-lock.json

# Try again
npm install
```

---

## Development Workflows

### Adding a New Asset Type

1. **Via UI (Admin)**
   - Go to Configuration
   - Click "Asset Types" section
   - Click "Add Value"
   - Enter name (e.g., "Container")
   - Click Add

2. **Automatic in Forms**
   - New type appears in all asset forms immediately
   - Dropdown refreshes automatically

### Bulk Importing Assets

1. Download CSV template from Asset Inventory page
2. Fill in your asset data
3. Upload file
4. System validates and imports
5. View results in Asset Inventory

### Giving User Read-Only Access

1. Go to User Management
2. Find user
3. Change permission to "Read Only"
4. User can view but not modify assets

### Hiding Pages from Users

1. Go to Password Visibility page (Admin only)
2. Uncheck pages you want to hide
3. Those pages won't appear in their sidebar

---

## File Structure Quick Reference

```
infrastructure-inventory/
├── backend/              ← Express API server
│   ├── server.js         ← Start here
│   ├── .env              ← Config
│   └── package.json
├── frontend/             ← React app
│   ├── src/
│   │   ├── App.jsx       ← Main component
│   │   └── main.jsx      ← Entry point
│   └── package.json
├── docs/                 ← Documentation
│   ├── API_DOCUMENTATION.md
│   ├── SETUP_GUIDE.md
│   └── DATABASE_SETUP.md
├── database_init.sql     ← Database schema
└── README.md             ← Project overview
```

---

## Useful Commands

### Backend
```bash
npm start           # Start backend server
npm run dev         # Start with auto-reload (if configured)
```

### Frontend
```bash
npm run dev         # Start dev server
npm run build       # Build for production
npm run preview     # Preview production build
```

### Database
```bash
psql -U infra_user -h localhost -d infrastructure_inventory
SELECT COUNT(*) FROM assets;  # See how many assets
\dt                            # List tables
```

### Docker
```bash
docker-compose up -d           # Start all services
docker-compose down            # Stop all services
docker-compose logs -f backend # View backend logs
docker-compose logs -f postgres # View database logs
```

---

## Next Steps

### Learning More
- Read [API_DOCUMENTATION.md](docs/API_DOCUMENTATION.md) for API reference
- Read [SETUP_GUIDE.md](docs/SETUP_GUIDE.md) for detailed setup
- Check code comments in source files

### Customization
- Edit company name in Settings page
- Change colors and branding
- Add custom fields for your assets
- Configure dropdown values

### Going to Production
- See "Production Deployment" section in README.md
- Change default admin password
- Use strong JWT_SECRET
- Enable HTTPS
- Configure database backups

### Getting Help
- Check troubleshooting section above
- Review error messages in browser console (F12)
- Check backend logs (terminal)
- See /docs folder for detailed guides

---

## Support Resources

| Resource | Location |
|----------|----------|
| API Docs | `/docs/API_DOCUMENTATION.md` |
| Setup Guide | `/docs/SETUP_GUIDE.md` |
| Database Schema | `/docs/DATABASE_SETUP.md` |
| Project Structure | `/docs/PROJECT_STRUCTURE.md` |
| Main README | `/README.md` |

---

## Quick Reference: Default Values

```
Admin Username: admin@infra.local
Admin Password: admin123
Backend: http://localhost:5000
Frontend: http://localhost:5173
Database: localhost:5432
Database Name: infrastructure_inventory
Database User: infra_user
```

---

## You're Ready! 🎉

Your Infrastructure Inventory Management System is now ready to use!

**Next:** Open http://localhost:5173 and login with the default credentials.

---

**Last Updated:** January 2024
**Version:** 1.0.0
