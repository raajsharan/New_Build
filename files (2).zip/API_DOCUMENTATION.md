# Infrastructure Inventory Management System - API Documentation

## Overview

This document provides complete API endpoint reference for the Infrastructure Inventory Management System.

**Base URL:** `http://localhost:5000/api`

**Authentication:** All endpoints (except auth) require JWT token in Authorization header:
```
Authorization: Bearer <token>
```

---

## Authentication Endpoints

### Register New User

**Endpoint:** `POST /auth/register`

**Description:** Register a new user account (self-signup, no approval required)

**Request Body:**
```json
{
  "username": "john_doe",
  "email": "john@example.com",
  "full_name": "John Doe",
  "password": "securePassword123",
  "confirm_password": "securePassword123"
}
```

**Response (201):**
```json
{
  "success": true,
  "message": "User registered successfully",
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "user": {
    "id": 1,
    "username": "john_doe",
    "email": "john@example.com",
    "full_name": "John Doe",
    "is_admin": false,
    "can_write": true
  }
}
```

**Error (400):**
```json
{
  "success": false,
  "message": "User already exists"
}
```

---

### Login

**Endpoint:** `POST /auth/login`

**Description:** Login with username/email and password

**Request Body:**
```json
{
  "username": "admin@infra.local",
  "password": "admin123"
}
```

**Response (200):**
```json
{
  "success": true,
  "message": "Login successful",
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "user": {
    "id": 1,
    "username": "admin",
    "email": "admin@infra.local",
    "full_name": "System Administrator",
    "is_admin": true,
    "can_write": true
  }
}
```

**Error (401):**
```json
{
  "success": false,
  "message": "Invalid credentials"
}
```

---

### Verify Token

**Endpoint:** `GET /auth/verify`

**Description:** Verify JWT token and get user info

**Headers:**
```
Authorization: Bearer <token>
```

**Response (200):**
```json
{
  "success": true,
  "user": {
    "id": 1,
    "username": "admin",
    "email": "admin@infra.local",
    "is_admin": true,
    "can_write": true
  }
}
```

---

## Asset Endpoints

### Get All Assets

**Endpoint:** `GET /assets`

**Description:** Retrieve all assets with pagination, search, and filtering

**Query Parameters:**
```
page=1              (default: 1)
limit=10            (default: 10, max: 100)
search=hostname     (search in hostname, IP, assigned user)
filter_location=1   (filter by location ID)
filter_department=1 (filter by department ID)
filter_status=1     (filter by server status ID)
filter_asset_type=1 (filter by asset type ID)
```

**Example Request:**
```
GET /assets?page=1&limit=10&search=server&filter_location=1
```

**Response (200):**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "vm_name": "WEB-SERVER-01",
      "os_hostname": "web-server-01.corp.local",
      "ip_address": "192.168.1.10",
      "asset_type_id": 1,
      "asset_type_name": "VM",
      "os_type_id": 1,
      "os_type_name": "Linux",
      "os_version_id": 1,
      "os_version_name": "Ubuntu 22.04 LTS",
      "assigned_user": "John Doe",
      "department_id": 2,
      "department_name": "DevOps",
      "business_purpose": "Production Web Server",
      "server_status_id": 1,
      "server_status_name": "Alive",
      "me_installed_status": true,
      "tenable_installed_status": true,
      "patching_schedule_id": 1,
      "patching_schedule_name": "Weekly",
      "patching_type_id": 1,
      "patching_type_name": "Auto",
      "server_patch_type_id": 1,
      "server_patch_type_name": "Critical",
      "location_id": 1,
      "location_name": "DC1",
      "additional_remarks": "Primary production web server",
      "host_details": "8vCPU, 16GB RAM",
      "serial_no": "SN-001-WEB",
      "idrac_enabled": true,
      "idrac_ip": "192.168.1.100",
      "eol_status": "InSupport",
      "asset_username": "root",
      "asset_password": "encrypted_password",
      "created_at": "2024-01-15T10:30:00Z",
      "updated_at": "2024-01-15T10:30:00Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 10,
    "total": 45,
    "pages": 5
  }
}
```

---

### Get Single Asset

**Endpoint:** `GET /assets/:id`

**Description:** Retrieve a specific asset by ID

**Parameters:**
```
id - Asset ID (required)
```

**Response (200):**
```json
{
  "success": true,
  "data": {
    "id": 1,
    "vm_name": "WEB-SERVER-01",
    ...
  }
}
```

**Error (404):**
```json
{
  "success": false,
  "message": "Asset not found"
}
```

---

### Create Asset

**Endpoint:** `POST /assets`

**Description:** Create a new asset (requires write permission)

**Request Body:**
```json
{
  "vm_name": "WEB-SERVER-02",
  "os_hostname": "web-server-02.corp.local",
  "ip_address": "192.168.1.11",
  "asset_type_id": 1,
  "os_type_id": 1,
  "os_version_id": 1,
  "assigned_user": "Jane Smith",
  "department_id": 2,
  "business_purpose": "Production Web Server",
  "server_status_id": 1,
  "me_installed_status": true,
  "tenable_installed_status": true,
  "patching_schedule_id": 1,
  "patching_type_id": 1,
  "server_patch_type_id": 1,
  "location_id": 1,
  "additional_remarks": "Secondary web server",
  "host_details": "8vCPU, 16GB RAM",
  "serial_no": "SN-001-WEB2",
  "idrac_enabled": false,
  "idrac_ip": null,
  "eol_status": "InSupport",
  "asset_username": "root",
  "asset_password": "password123"
}
```

**Response (201):**
```json
{
  "success": true,
  "message": "Asset created successfully",
  "data": {
    "id": 2,
    "vm_name": "WEB-SERVER-02",
    ...
  }
}
```

**Error (403):**
```json
{
  "success": false,
  "message": "Write access required"
}
```

---

### Update Asset

**Endpoint:** `PUT /assets/:id`

**Description:** Update an existing asset (requires write permission)

**Parameters:**
```
id - Asset ID (required)
```

**Request Body:** (same as Create Asset, include only fields to update)

**Response (200):**
```json
{
  "success": true,
  "message": "Asset updated successfully",
  "data": {
    "id": 1,
    "vm_name": "WEB-SERVER-01-UPDATED",
    ...
  }
}
```

---

### Delete Asset

**Endpoint:** `DELETE /assets/:id`

**Description:** Delete an asset (requires write permission)

**Parameters:**
```
id - Asset ID (required)
```

**Response (200):**
```json
{
  "success": true,
  "message": "Asset deleted successfully"
}
```

---

### Bulk Import Assets

**Endpoint:** `POST /assets/bulk/import`

**Description:** Import multiple assets from CSV data (requires write permission)

**Request Body:**
```json
{
  "assets": [
    {
      "vm_name": "SERVER-01",
      "os_hostname": "server-01.local",
      "ip_address": "192.168.1.10",
      "asset_type_id": 1,
      "os_type_id": 1,
      "os_version_id": 1,
      ...
    },
    {
      "vm_name": "SERVER-02",
      ...
    }
  ]
}
```

**Response (200):**
```json
{
  "success": true,
  "message": "4 assets imported successfully",
  "data": {
    "created_count": 4,
    "failed_count": 0,
    "errors": []
  }
}
```

---

## Configuration Endpoints

### Get Configuration Values

**Endpoint:** `GET /config/:table`

**Description:** Get all values from a configuration table

**Parameters:**
```
table - Table name (required)
Valid values: asset_types, os_types, os_versions, departments, server_status, 
patching_schedule, patching_type, server_patch_type, locations, custom_fields
```

**Response (200):**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "name": "VM",
      "created_at": "2024-01-01T00:00:00Z"
    },
    {
      "id": 2,
      "name": "Physical Server",
      "created_at": "2024-01-01T00:00:00Z"
    }
  ]
}
```

---

### Get OS Versions by Type

**Endpoint:** `GET /config/os-versions/:os_type_id`

**Description:** Get OS versions for a specific OS type

**Parameters:**
```
os_type_id - OS Type ID (required)
```

**Response (200):**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "os_type_id": 1,
      "name": "Ubuntu 22.04 LTS",
      "created_at": "2024-01-01T00:00:00Z"
    },
    {
      "id": 2,
      "os_type_id": 1,
      "name": "Ubuntu 20.04 LTS",
      "created_at": "2024-01-01T00:00:00Z"
    }
  ]
}
```

---

### Create Configuration Value

**Endpoint:** `POST /config/:table`

**Description:** Add new value to configuration table (admin only)

**Parameters:**
```
table - Table name (required)
```

**Request Body:**
```json
{
  "name": "New Location",
  "os_type_id": 1  // Only for os_versions table
}
```

**Response (201):**
```json
{
  "success": true,
  "message": "Configuration created successfully",
  "data": {
    "id": 7,
    "name": "New Location",
    "created_at": "2024-01-15T10:30:00Z"
  }
}
```

---

### Update Configuration Value

**Endpoint:** `PUT /config/:table/:id`

**Description:** Update configuration value (admin only)

**Parameters:**
```
table - Table name (required)
id - Configuration ID (required)
```

**Request Body:**
```json
{
  "name": "Updated Name"
}
```

**Response (200):**
```json
{
  "success": true,
  "message": "Configuration updated successfully",
  "data": {
    "id": 7,
    "name": "Updated Name",
    "updated_at": "2024-01-15T10:35:00Z"
  }
}
```

---

### Delete Configuration Value

**Endpoint:** `DELETE /config/:table/:id`

**Description:** Delete configuration value (admin only)

**Parameters:**
```
table - Table name (required)
id - Configuration ID (required)
```

**Response (200):**
```json
{
  "success": true,
  "message": "Configuration deleted successfully"
}
```

**Error (400):**
```json
{
  "success": false,
  "message": "Cannot delete - this value is in use"
}
```

---

## Dashboard Endpoints

### Get Dashboard Summary

**Endpoint:** `GET /dashboard/summary`

**Description:** Get dashboard statistics and metrics

**Response (200):**
```json
{
  "success": true,
  "data": {
    "total_assets": 45,
    "vm_count": 30,
    "physical_server_count": 15,
    "me_installed_count": 38,
    "tenable_installed_count": 40,
    "auto_patch_count": 35,
    "manual_patch_count": 10,
    "alive_servers": 42,
    "powered_off_servers": 2,
    "not_alive_servers": 1,
    "location_distribution": [
      {
        "location": "DC1",
        "count": 20
      },
      {
        "location": "DC2",
        "count": 15
      },
      {
        "location": "Azure",
        "count": 8
      },
      {
        "location": "AWS",
        "count": 2
      }
    ],
    "patching_distribution": [
      {
        "patching_type": "Auto",
        "count": 35
      },
      {
        "patching_type": "Manual",
        "count": 10
      }
    ]
  }
}
```

---

## User Endpoints

### Get All Users

**Endpoint:** `GET /users`

**Description:** Get all users (admin only)

**Response (200):**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "username": "admin",
      "email": "admin@infra.local",
      "full_name": "System Administrator",
      "is_admin": true,
      "can_write": true,
      "is_active": true
    },
    {
      "id": 2,
      "username": "john_doe",
      "email": "john@example.com",
      "full_name": "John Doe",
      "is_admin": false,
      "can_write": true,
      "is_active": true
    }
  ]
}
```

---

### Get User by ID

**Endpoint:** `GET /users/:id`

**Description:** Get user details

**Parameters:**
```
id - User ID (required)
```

**Response (200):**
```json
{
  "success": true,
  "data": {
    "id": 2,
    "username": "john_doe",
    "email": "john@example.com",
    "full_name": "John Doe",
    "is_admin": false,
    "can_write": true,
    "is_active": true
  }
}
```

---

### Update User Permissions

**Endpoint:** `PATCH /users/:id`

**Description:** Update user write permissions (admin only)

**Parameters:**
```
id - User ID (required)
```

**Request Body:**
```json
{
  "can_write": false
}
```

**Response (200):**
```json
{
  "success": true,
  "message": "User updated successfully",
  "data": {
    "id": 2,
    "username": "john_doe",
    "can_write": false
  }
}
```

---

### Delete User

**Endpoint:** `DELETE /users/:id`

**Description:** Delete user account (admin only)

**Parameters:**
```
id - User ID (required)
```

**Response (200):**
```json
{
  "success": true,
  "message": "User deleted successfully"
}
```

---

### Toggle Password Visibility

**Endpoint:** `POST /users/:id/password-visibility`

**Description:** Enable/disable password visibility for user (admin only)

**Parameters:**
```
id - User ID (required)
```

**Request Body:**
```json
{
  "show_asset_passwords": true
}
```

**Response (200):**
```json
{
  "success": true,
  "message": "Password visibility updated"
}
```

---

### Update Page Permissions

**Endpoint:** `POST /users/:id/page-permissions`

**Description:** Control page visibility for user (admin only)

**Parameters:**
```
id - User ID (required)
```

**Request Body:**
```json
{
  "page_name": "AssetInventory",
  "is_visible": false
}
```

**Response (200):**
```json
{
  "success": true,
  "message": "Page permission updated"
}
```

**Valid Page Names:**
```
Dashboard
AssetForm
AssetInventory
InventoryConfiguration
UserManagement
Settings
PasswordVisibility
CustomFields
```

---

### Get All Permissions

**Endpoint:** `GET /users/permissions/all`

**Description:** Get all user page permissions (admin only)

**Response (200):**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "user_id": 1,
      "page_name": "Dashboard",
      "is_visible": true,
      "created_at": "2024-01-01T00:00:00Z"
    },
    {
      "id": 2,
      "user_id": 1,
      "page_name": "AssetInventory",
      "is_visible": true,
      "created_at": "2024-01-01T00:00:00Z"
    }
  ]
}
```

---

## Settings Endpoints

### Get Settings

**Endpoint:** `GET /settings`

**Description:** Get system settings

**Response (200):**
```json
{
  "success": true,
  "data": {
    "id": 1,
    "company_name": "Your Company",
    "logo_path": null,
    "software_name": "Infrastructure Inventory System",
    "primary_color": "#0066cc",
    "secondary_color": "#333333",
    "created_at": "2024-01-01T00:00:00Z",
    "updated_at": "2024-01-01T00:00:00Z"
  }
}
```

---

### Update Settings

**Endpoint:** `POST /settings`

**Description:** Update system settings (admin only)

**Request Body:**
```json
{
  "company_name": "Acme Corporation",
  "software_name": "Acme Infrastructure Manager",
  "primary_color": "#ff6b6b",
  "secondary_color": "#1a1a1a"
}
```

**Response (200):**
```json
{
  "success": true,
  "message": "Settings updated successfully",
  "data": {
    "id": 1,
    "company_name": "Acme Corporation",
    "software_name": "Acme Infrastructure Manager",
    "primary_color": "#ff6b6b",
    "secondary_color": "#1a1a1a",
    "updated_at": "2024-01-15T10:35:00Z"
  }
}
```

---

## Error Responses

All error responses follow this format:

```json
{
  "success": false,
  "message": "Error description",
  "error": "Technical error details (dev mode only)"
}
```

### Common HTTP Status Codes

| Code | Meaning |
|------|---------|
| 200 | Success |
| 201 | Created |
| 400 | Bad Request |
| 401 | Unauthorized |
| 403 | Forbidden |
| 404 | Not Found |
| 500 | Server Error |

### Common Error Messages

```
"Invalid credentials" - Wrong username/password
"No token provided" - Missing Authorization header
"Invalid or expired token" - JWT token invalid/expired
"Admin access required" - User not admin
"Write access required" - User is read-only
"User already exists" - Email/username taken
"Asset not found" - Asset ID doesn't exist
"Cannot delete - value in use" - Foreign key constraint
```

---

## Rate Limiting

Currently no rate limiting is implemented. In production, add:
- 100 requests per minute per IP
- 1000 requests per hour per user

---

## Pagination

List endpoints support pagination:

```
page=1        (page number, starts at 1)
limit=10      (items per page, default 10, max 100)
```

Response includes:
```json
"pagination": {
  "page": 1,
  "limit": 10,
  "total": 250,
  "pages": 25
}
```

---

## Data Types

| Type | Format | Example |
|------|--------|---------|
| Integer | Whole number | 1, 100, -5 |
| String | Text | "example", "VM Name" |
| Boolean | true/false | true, false |
| DateTime | ISO 8601 | "2024-01-15T10:30:00Z" |
| JSON | JSON object/array | {"key": "value"} |

---

## Support

For API issues or questions, refer to:
- Backend logs: `npm start`
- Database queries: Check PostgreSQL logs
- Frontend console: Browser DevTools F12
