# Infrastructure Inventory Management System - Setup Guide

## System Requirements

- **Node.js:** v16.0.0 or higher
- **PostgreSQL:** v12.0 or higher
- **npm:** v8.0.0 or higher
- **Git:** For version control

## Installation Steps

### 1. Database Setup

#### On Linux/Mac:

```bash
# Connect to PostgreSQL
psql -U postgres

# Create database and user
CREATE ROLE infra_user WITH PASSWORD 'secure_password' LOGIN;
ALTER ROLE infra_user CREATEDB;

# Exit psql
\q

# Run the initialization script
psql -U postgres -f database_init.sql
```

#### On Windows:

```bash
# Using pgAdmin or psql
psql -U postgres -h localhost

# Run initialization script
psql -U postgres -h localhost -d postgres -f database_init.sql
```

#### Verify Database:

```bash
psql -U infra_user -d infrastructure_inventory

# Check tables
\dt

# Should show ~16 tables including assets, users, etc.
```

### 2. Backend Setup

```bash
# Navigate to backend directory
cd backend

# Install dependencies
npm install

# Create .env file
cp .env.example .env

# Edit .env with your database credentials
# DB_HOST=localhost
# DB_PORT=5432
# DB_USER=infra_user
# DB_PASSWORD=secure_password
# DB_NAME=infrastructure_inventory
# JWT_SECRET=your-super-secret-key

# Start the server
npm start

# Server should start on http://localhost:5000
```

### 3. Frontend Setup

```bash
# Navigate to frontend directory
cd frontend

# Install dependencies
npm install

# Create .env file
cat > .env << EOF
VITE_API_URL=http://localhost:5000/api
EOF

# Start development server
npm run dev

# Frontend should start on http://localhost:5173
```

### 4. Access the Application

1. Open browser: `http://localhost:5173`
2. Login with default credentials:
   - **Username:** `admin@infra.local`
   - **Password:** `admin123`

## Default Admin User

```
Username: admin@infra.local
Password: admin123
Email: admin@infra.local
Permissions: Full Admin Access
```

**⚠️ IMPORTANT:** Change the default password after first login!

## Sample Data

The system comes with 4 sample assets for demonstration:

1. **WEB-SERVER-01** - Production Web Server (VM, Ubuntu, DC1)
2. **DB-SERVER-01** - Production Database Server (Physical, RHEL, DC1)
3. **APP-SERVER-01** - Application Server (VM, Windows, Azure)
4. **BACKUP-SERVER-01** - Backup Server (Physical, CentOS, DC2, Powered Off)

## Database Schema

### Core Tables

```
users               - System users and authentication
assets              - Main asset records
asset_types        - Dropdown: Asset Type (VM, Physical Server)
os_types           - Dropdown: OS Type (Linux, Windows, ESXi)
os_versions        - Dropdown: OS Versions (linked to os_types)
departments        - Dropdown: Departments
server_status      - Dropdown: Server Status
patching_schedule  - Dropdown: Patching Schedule
patching_type      - Dropdown: Patching Type (Auto/Manual)
server_patch_type  - Dropdown: Patch Priority (Critical/Non-Critical/Test)
locations          - Dropdown: Locations
custom_fields      - Admin-defined custom asset fields
page_permissions   - User page visibility controls
password_visibility_settings - Password display permissions
settings           - System branding and configuration
audit_logs         - Activity logging
```

## API Documentation

### Authentication Endpoints

```
POST /api/auth/register        - Register new user
POST /api/auth/login           - Login user
GET  /api/auth/verify          - Verify JWT token
```

### Asset Endpoints

```
GET    /api/assets             - Get all assets (with pagination, search, filters)
GET    /api/assets/:id         - Get single asset
POST   /api/assets             - Create asset (requires write permission)
PUT    /api/assets/:id         - Update asset (requires write permission)
DELETE /api/assets/:id         - Delete asset (requires write permission)
POST   /api/assets/bulk/import - Bulk import from CSV
```

### Configuration Endpoints

```
GET    /api/config/:table      - Get all values from config table
POST   /api/config/:table      - Create config value (admin only)
PUT    /api/config/:table/:id  - Update config value (admin only)
DELETE /api/config/:table/:id  - Delete config value (admin only)
```

### Dashboard Endpoints

```
GET /api/dashboard/summary     - Get dashboard statistics
```

### User Endpoints

```
GET    /api/users              - Get all users (admin only)
GET    /api/users/:id          - Get user details
PATCH  /api/users/:id          - Update user permissions (admin only)
DELETE /api/users/:id          - Delete user (admin only)
```

### Settings Endpoints

```
GET  /api/settings             - Get system settings
POST /api/settings             - Update settings (admin only)
```

## CSV Bulk Import

### Using the CSV Template

1. Go to **Asset Inventory** page
2. Click **Bulk Import** button
3. Download template or use provided `CSV_IMPORT_TEMPLATE.csv`
4. Fill in asset data
5. Upload file
6. System validates and imports

### CSV Format

```csv
vm_name,os_hostname,ip_address,asset_type_id,os_type_id,os_version_id,...
SERVER-01,server-01.local,192.168.1.10,1,1,1,...
```

See `CSV_IMPORT_TEMPLATE.csv` for complete format and ID reference.

## User Roles & Permissions

### Admin Users

- ✅ Full access to all pages
- ✅ Add/Edit/Delete assets
- ✅ Manage user accounts
- ✅ Configure dropdowns and system settings
- ✅ Control password visibility
- ✅ Manage page permissions
- ✅ Create custom fields
- ✅ Manage company branding

### Read & Write Users

- ✅ View dashboard
- ✅ Add/Edit/Delete assets
- ❌ Manage users
- ❌ System settings
- ❌ Cannot see admin-only pages

### Read Only Users

- ✅ View dashboard and assets
- ❌ Cannot add/edit/delete assets
- ❌ Cannot access admin pages

## Configuration

### Environment Variables

**Backend (.env)**

```
# Database
DB_HOST=localhost
DB_PORT=5432
DB_USER=infra_user
DB_PASSWORD=secure_password
DB_NAME=infrastructure_inventory

# Server
PORT=5000
NODE_ENV=development

# Authentication
JWT_SECRET=your-super-secret-jwt-key-change-in-production

# Frontend URL
FRONTEND_URL=http://localhost:5173
```

**Frontend (.env)**

```
VITE_API_URL=http://localhost:5000/api
```

### Deployment Configuration

For production deployment:

1. Change `NODE_ENV=production`
2. Use strong `JWT_SECRET`
3. Configure HTTPS
4. Use environment-specific database
5. Enable CORS for production domain
6. Set secure passwords
7. Enable SSL/TLS

## Troubleshooting

### Database Connection Error

```bash
# Check PostgreSQL is running
psql -U postgres

# Verify credentials in .env
# Check DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_NAME

# Test connection
psql -U infra_user -h localhost -d infrastructure_inventory
```

### Port Already in Use

```bash
# Backend (5000)
lsof -i :5000
kill -9 <PID>

# Frontend (5173)
lsof -i :5173
kill -9 <PID>
```

### JWT Token Expired

- Clear browser localStorage
- Login again
- Tokens expire after 24 hours

### Assets Not Loading

- Check API connection in browser console
- Verify backend is running
- Check CORS settings
- Verify authentication token

## Security Best Practices

1. **Change Default Password:** Change admin password immediately after setup
2. **Use Strong JWT Secret:** Generate random 32+ character secret
3. **Enable HTTPS:** Always use HTTPS in production
4. **Database Backup:** Regular backups of infrastructure_inventory database
5. **Update Dependencies:** Keep npm packages updated
6. **Access Control:** Regularly review user permissions
7. **Password Storage:** Passwords are encrypted - never share credentials
8. **API Security:** All endpoints require authentication token
9. **Admin Access:** Limit admin access to trusted users
10. **Audit Logs:** Monitor audit_logs table for suspicious activity

## Backup & Restore

### Backup Database

```bash
# Full backup
pg_dump -U infra_user infrastructure_inventory > backup.sql

# With timestamp
pg_dump -U infra_user infrastructure_inventory > backup_$(date +%Y%m%d_%H%M%S).sql
```

### Restore Database

```bash
# Drop existing database
psql -U postgres -c "DROP DATABASE infrastructure_inventory;"

# Restore from backup
psql -U postgres -f backup.sql
```

## Performance Optimization

1. **Database Indexes:** Already created on frequently queried columns
2. **Pagination:** Assets table uses pagination (default 10 per page)
3. **Caching:** Frontend caches config dropdowns
4. **Connection Pooling:** Backend uses connection pool (max 20)
5. **Response Compression:** Enable GZIP in production

## Monitoring

### Check System Health

```bash
# Backend health check
curl http://localhost:5000/api/auth/verify -H "Authorization: Bearer <token>"

# Database connection
psql -U infra_user -c "SELECT COUNT(*) FROM assets;"
```

### View Logs

```bash
# Backend logs (console)
npm start

# Database logs
tail -f /var/log/postgresql/postgresql.log
```

## Support & Documentation

- **API Docs:** See API_DOCUMENTATION.md
- **Database Schema:** See DATABASE_SETUP.md
- **Project Structure:** See PROJECT_STRUCTURE.md

## License

This project is proprietary. All rights reserved.

## Version

Current Version: 1.0.0
Last Updated: 2024
