# Infrastructure Inventory Management System

A professional, enterprise-grade web application for managing and tracking server and virtual machine assets in your infrastructure. Built with React, Node.js, Express, and PostgreSQL.

## 🎯 Features

### Core Functionality
- ✅ **Asset Management** - Add, edit, delete infrastructure assets with detailed information
- ✅ **Multiple Asset Types** - Support for VMs, physical servers, and other infrastructure
- ✅ **Advanced Filtering** - Search and filter by location, department, status, and more
- ✅ **Bulk Import** - Import multiple assets via CSV file upload
- ✅ **Real-time Dashboard** - View key metrics and statistics at a glance

### Administration
- ✅ **User Management** - Create users, assign permissions, control access
- ✅ **Role-based Access Control** - Admin, Read & Write, Read Only roles
- ✅ **Dropdown Configuration** - Manage all dropdown values from dedicated page
- ✅ **Custom Fields** - Define custom asset fields for your organization
- ✅ **Page Permissions** - Control which pages each user can access

### Security & Compliance
- ✅ **JWT Authentication** - Secure token-based authentication
- ✅ **Password Management** - Control password visibility per user
- ✅ **Audit Logging** - Track all asset changes
- ✅ **Encrypted Passwords** - Asset credentials are encrypted
- ✅ **Permission-based Operations** - Read-only users cannot modify assets

### System Administration
- ✅ **Branding Customization** - Change company name, logo, and colors
- ✅ **System Settings** - Configure application appearance
- ✅ **Database Management** - Automated schema creation
- ✅ **API Documentation** - Complete endpoint reference

## 🚀 Quick Start

### Prerequisites
- Node.js 16+ (LTS)
- PostgreSQL 12+
- npm or yarn
- Git

### Installation

1. **Clone the repository**
```bash
git clone https://github.com/yourusername/infrastructure-inventory.git
cd infrastructure-inventory
```

2. **Setup Database**
```bash
# Create PostgreSQL user and database
psql -U postgres

CREATE ROLE infra_user WITH PASSWORD 'secure_password' LOGIN;
ALTER ROLE infra_user CREATEDB;

\q

# Initialize database
psql -U infra_user -h localhost -d postgres -f database_init.sql
```

3. **Setup Backend**
```bash
cd backend
npm install
cp .env.example .env

# Edit .env with your database credentials
# Then start the server
npm start
# Server runs on http://localhost:5000
```

4. **Setup Frontend**
```bash
cd frontend
npm install
npm run dev
# Frontend runs on http://localhost:5173
```

5. **Login**
```
URL: http://localhost:5173
Username: admin@infra.local
Password: admin123
```

## 📋 System Architecture

### Frontend Stack
- **React 18** - UI framework
- **React Router** - Client-side routing
- **Axios** - HTTP client
- **Recharts** - Data visualization
- **TailwindCSS** - Styling
- **Lucide React** - Icons
- **Vite** - Build tool

### Backend Stack
- **Node.js** - Runtime
- **Express** - Web framework
- **PostgreSQL** - Database
- **JWT** - Authentication
- **bcryptjs** - Password hashing

### Database
- **PostgreSQL 12+**
- 16 tables with proper relationships
- Pre-populated lookup tables
- Sample assets for demonstration

## 📁 Project Structure

```
infrastructure-inventory-app/
├── backend/
│   ├── config/
│   │   ├── database.js
│   │   └── env.js
│   ├── controllers/
│   ├── middleware/
│   ├── routes/
│   ├── utils/
│   ├── db/
│   │   └── init.sql
│   ├── server.js
│   ├── package.json
│   └── .env
│
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   ├── pages/
│   │   ├── context/
│   │   ├── hooks/
│   │   ├── services/
│   │   ├── utils/
│   │   ├── styles/
│   │   ├── App.jsx
│   │   └── main.jsx
│   ├── public/
│   ├── index.html
│   ├── package.json
│   ├── vite.config.js
│   └── tailwind.config.js
│
├── docs/
│   ├── SETUP_GUIDE.md
│   ├── API_DOCUMENTATION.md
│   └── PROJECT_STRUCTURE.md
│
├── docker-compose.yml
└── README.md
```

## 🔧 API Endpoints

### Authentication
```
POST   /api/auth/register          Register new user
POST   /api/auth/login             Login user
GET    /api/auth/verify            Verify token
```

### Assets
```
GET    /api/assets                 Get all assets
GET    /api/assets/:id             Get single asset
POST   /api/assets                 Create asset
PUT    /api/assets/:id             Update asset
DELETE /api/assets/:id             Delete asset
POST   /api/assets/bulk/import     Bulk import
```

### Configuration
```
GET    /api/config/:table          Get config values
POST   /api/config/:table          Create value
PUT    /api/config/:table/:id      Update value
DELETE /api/config/:table/:id      Delete value
```

### Dashboard
```
GET    /api/dashboard/summary      Get statistics
```

### Users
```
GET    /api/users                  Get all users
PATCH  /api/users/:id              Update permissions
DELETE /api/users/:id              Delete user
POST   /api/users/:id/page-permissions  Set page access
```

See [API_DOCUMENTATION.md](docs/API_DOCUMENTATION.md) for complete reference.

## 🐳 Docker Deployment

### Quick Start with Docker
```bash
# Build and start all services
docker-compose up -d

# Services will be available at:
# Frontend: http://localhost:3000
# Backend: http://localhost:5000
# Database: localhost:5432
```

### Stop Services
```bash
docker-compose down

# Remove volumes as well
docker-compose down -v
```

## 👤 Default Credentials

```
Username: admin@infra.local
Password: admin123
```

⚠️ **IMPORTANT:** Change the default password after first login!

## 📊 Sample Data

The system comes with 4 sample assets:

1. **WEB-SERVER-01** - Production Web Server (Ubuntu, DC1)
2. **DB-SERVER-01** - Production Database (RHEL, DC1)
3. **APP-SERVER-01** - Application Server (Windows, Azure)
4. **BACKUP-SERVER-01** - Backup Server (CentOS, DC2)

## 🔐 Security Features

- JWT token-based authentication
- Role-based access control (Admin, Read & Write, Read Only)
- Password encryption for stored credentials
- Audit logging of all changes
- Permission-based operations
- CORS protection
- SQL injection prevention via prepared statements
- XSS protection via TailwindCSS escaping
- CSRF tokens available for sensitive operations

## 📈 Performance

- Database connection pooling (max 20 connections)
- Pagination support (default 10 items per page)
- Response compression (GZIP)
- Efficient SQL queries with indexes
- Frontend code splitting
- Caching of configuration dropdowns

## 🛠️ Configuration

### Environment Variables

**Backend (.env)**
```
DB_HOST=localhost
DB_PORT=5432
DB_USER=infra_user
DB_PASSWORD=secure_password
DB_NAME=infrastructure_inventory
PORT=5000
NODE_ENV=development
JWT_SECRET=your-secret-key
FRONTEND_URL=http://localhost:5173
```

**Frontend (.env)**
```
VITE_API_URL=http://localhost:5000/api
```

## 📚 Documentation

- [Setup Guide](docs/SETUP_GUIDE.md) - Detailed installation and configuration
- [API Documentation](docs/API_DOCUMENTATION.md) - Complete API reference
- [Project Structure](docs/PROJECT_STRUCTURE.md) - Codebase organization
- [Database Schema](docs/DATABASE_SETUP.md) - Database design

## 🆘 Troubleshooting

### Database Connection Failed
```bash
# Verify PostgreSQL is running
psql -U postgres

# Check credentials in .env file
# Test connection directly
psql -U infra_user -h localhost -d infrastructure_inventory
```

### Port Already in Use
```bash
# Find and kill process using port 5000
lsof -i :5000
kill -9 <PID>

# For port 5173
lsof -i :5173
kill -9 <PID>
```

### Assets Not Loading
- Check browser console (F12) for errors
- Verify backend is running: `http://localhost:5000/api/assets`
- Verify authentication token in localStorage
- Check CORS settings

## 📦 Database Backup

### Backup
```bash
pg_dump -U infra_user infrastructure_inventory > backup.sql
```

### Restore
```bash
psql -U postgres -f backup.sql
```

## 🚀 Production Deployment

### Before Going Live

1. **Change Default Credentials**
   - Update admin password
   - Create new admin user

2. **Update Environment**
   - Set `NODE_ENV=production`
   - Use strong `JWT_SECRET`
   - Configure HTTPS

3. **Database**
   - Use managed PostgreSQL service (RDS, Cloud SQL, etc.)
   - Enable automated backups
   - Configure read replicas

4. **Security**
   - Enable HTTPS/SSL
   - Configure firewall rules
   - Set up monitoring
   - Enable audit logging

5. **Performance**
   - Configure CDN for static assets
   - Set up load balancing
   - Monitor API response times
   - Configure database indexes

## 🤝 Contributing

Contributions are welcome! Please follow these guidelines:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📝 License

This project is proprietary. All rights reserved.

## 💼 Support

For support and inquiries:
- Email: support@infra-inventory.local
- Documentation: See `/docs` folder
- Issues: GitHub Issues

## 📋 Changelog

### v1.0.0 (2024-01-15)
- Initial release
- Core asset management features
- User authentication and authorization
- Dashboard with statistics
- Configuration management
- Bulk import functionality
- API documentation

## 🙏 Acknowledgments

Built with ❤️ using React, Node.js, and PostgreSQL.

---

**Last Updated:** January 2024  
**Current Version:** 1.0.0
