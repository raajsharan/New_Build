import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { assetsAPI, dropdownsAPI, settingsAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useConfig } from '../context/ConfigContext';
import { RenderCustomField } from '../components/CustomFieldEditor';
import { MEIcon, TenableIcon } from '../components/AgentIcon';
import AssetTagWidget from '../components/AssetTagWidget';
import Toggle from '../components/Toggle';
import toast from 'react-hot-toast';
import {
  PlusCircle, RotateCcw, Upload, Download, List, Plus,
  Search, Edit2, Trash2, ChevronLeft, ChevronRight,
  Eye, EyeOff, RefreshCw, ExternalLink, Server,
  AlertTriangle, CheckCircle
} from 'lucide-react';

// ─────────────────────────────────────────────────────────────
// Default field → group layout (mirrors migrate_v7.sql)
// ─────────────────────────────────────────────────────────────
const DEFAULT_FIELD_LAYOUT = {
  vm_name:                  {group:'Basic Information', sort:1},
  os_hostname:              {group:'Basic Information', sort:2},
  ip_address:               {group:'Basic Information', sort:3},
  asset_type_id:            {group:'Basic Information', sort:4},
  os_type_id:               {group:'Basic Information', sort:5},
  os_version_id:            {group:'Basic Information', sort:6},
  assigned_user:            {group:'Ownership', sort:1},
  department_id:            {group:'Ownership', sort:2},
  business_purpose:         {group:'Ownership', sort:3},
  asset_tag:                {group:'Ownership', sort:4},
  server_status_id:         {group:'Status & Patching', sort:1},
  server_patch_type_id:     {group:'Status & Patching', sort:2},
  patching_schedule_id:     {group:'Status & Patching', sort:3},
  patching_type_id:         {group:'Status & Patching', sort:4},
  location_id:              {group:'Status & Patching', sort:5},
  eol_status:               {group:'Status & Patching', sort:6},
  me_installed_status:      {group:'Agent Status', sort:1},
  tenable_installed_status: {group:'Agent Status', sort:2},
  serial_number:            {group:'Host Details', sort:1},
  idrac_enabled:            {group:'Host Details', sort:2},
  idrac_ip:                 {group:'Host Details', sort:3},
  oem_status:               {group:'Host Details', sort:4},
  asset_username:           {group:'Credentials', sort:1},
  asset_password:           {group:'Credentials', sort:2},
  hosted_ip:                {group:'Extended Info', sort:1},
  additional_remarks:       {group:'Extended Info', sort:2},
};

// Standard group display order
const GROUP_ORDER = [
  'Basic Information','Ownership','Status & Patching',
  'Agent Status','Host Details','Credentials','Extended Info',
];

const ASSET_INIT = {
  vm_name:'', os_hostname:'', ip_address:'', asset_type_id:'', os_type_id:'', os_version_id:'',
  assigned_user:'', department_id:'', business_purpose:'', server_status_id:'',
  me_installed_status:false, tenable_installed_status:false,
  patching_schedule_id:'', patching_type_id:'', server_patch_type_id:'', location_id:'',
  additional_remarks:'', serial_number:'', idrac_enabled:false, idrac_ip:'',
  eol_status:'InSupport', asset_username:'', asset_password:'', custom_field_values:{},
  hosted_ip:'', asset_tag:'', oem_status:'',
};

const Field = ({ label, required, children, hint }) => (
  <div>
    <label className="block text-sm font-medium text-gray-700 mb-1.5">
      {label}{required && <span className="text-red-500 ml-0.5">*</span>}
    </label>
    {children}
    {hint && <p className="text-xs text-gray-400 mt-1">{hint}</p>}
  </div>
);

const SectionTitle = ({ title }) => (
  <div className="col-span-full pt-2 pb-1 border-b border-gray-100">
    <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider">{title}</p>
  </div>
);

// ─────────────────────────────────────────────────────────────
// Dynamic form renderer — reads layout config to order fields
// ─────────────────────────────────────────────────────────────
function renderFormGroups({ layout, form, set, dropdowns, osVersions, canWrite, showPw, setShowPw, dupState, checking, tagValidation, setTagValidation, editAsset, handleIPChange, oemOptions, fieldTypeOverrides }) {
  // Returns overridden type+options for a built-in field, or null if unchanged
  const getOverride = (key) => {
    const o = fieldTypeOverrides?.[key];
    if (!o || !o.type) return null;
    return o;
  };
  // Renders a field that may be text→dropdown or text→radio based on override
  const renderOverridableText = (key, label, inputJsx) => {
    const o = getOverride(key);
    if (!o) return inputJsx;
    const opts = (o.options || []).filter(Boolean);
    if (o.type === 'dropdown') {
      return (
        <Field key={key} label={o.label || label}>
          <select className="input-field" value={form[key]} onChange={e => set(key, e.target.value)}>
            <option value="">Select…</option>
            {opts.map(opt => <option key={opt} value={opt}>{opt}</option>)}
          </select>
        </Field>
      );
    }
    if (o.type === 'radio') {
      return (
        <Field key={key} label={o.label || label}>
          <div className="flex flex-wrap gap-3 pt-1">
            {opts.map(opt => (
              <label key={opt} className="flex items-center gap-2 cursor-pointer text-sm text-gray-700">
                <input type="radio" name={key} value={opt}
                  checked={form[key] === opt}
                  onChange={() => set(key, opt)}
                  className="accent-blue-600 w-4 h-4"/>
                {opt}
              </label>
            ))}
          </div>
        </Field>
      );
    }
    return inputJsx;
  };

  const groupMap = {};
  for (const [key, cfg] of Object.entries(layout)) {
    const g = cfg.group || 'General';
    if (!groupMap[g]) groupMap[g] = [];
    groupMap[g].push({ key, sort: cfg.sort || 99 });
  }
  for (const g of Object.keys(groupMap)) groupMap[g].sort((a,b)=>a.sort-b.sort);

  const allGroups = [...new Set([...GROUP_ORDER, ...Object.keys(groupMap)])];

  const renderField = (key) => {
    switch (key) {
      case 'vm_name':       return renderOverridableText('vm_name','VM Name',<Field key={key} label={getOverride('vm_name')?.label||'VM Name'}><input className="input-field" value={form.vm_name} onChange={e=>set('vm_name',e.target.value)} placeholder="SERVER-01"/></Field>);
      case 'os_hostname':   return <Field key={key} label="OS Hostname"><input className="input-field" value={form.os_hostname} onChange={e=>set('os_hostname',e.target.value)} placeholder="server-01.local"/></Field>;
      case 'ip_address':    return (
        <Field key={key} label="IP Address">
          <input className={`input-field ${dupState.ip?'border-red-400':dupState.ip===false?'border-green-400':''}`} value={form.ip_address} onChange={e=>handleIPChange(e.target.value)} placeholder="192.168.1.10"/>
          {checking.ip&&<p className="text-xs text-gray-400 mt-1 flex items-center gap-1"><span className="inline-block w-3 h-3 border border-t-transparent rounded-full animate-spin border-gray-400"/>Checking…</p>}
          {dupState.ip===false&&<p className="text-xs text-green-600 mt-1 flex items-center gap-1"><CheckCircle size={11}/> Available</p>}
        </Field>
      );
      case 'asset_type_id': return <Field key={key} label="Asset Type"><select className="input-field" value={form.asset_type_id} onChange={e=>set('asset_type_id',e.target.value)}><option value="">Select…</option>{(dropdowns.asset_types||[]).map(t=><option key={t.id} value={t.id}>{t.name}</option>)}</select></Field>;
      case 'os_type_id':    return <Field key={key} label="OS Type"><select className="input-field" value={form.os_type_id} onChange={e=>set('os_type_id',e.target.value)}><option value="">Select…</option>{(dropdowns.os_types||[]).map(t=><option key={t.id} value={t.id}>{t.name}</option>)}</select></Field>;
      case 'os_version_id': return <Field key={key} label="OS Version"><select className="input-field" value={form.os_version_id} onChange={e=>set('os_version_id',e.target.value)} disabled={!form.os_type_id}><option value="">{form.os_type_id?'Select version…':'Select OS Type first'}</option>{osVersions.map(v=><option key={v.id} value={v.id}>{v.name}</option>)}</select></Field>;
      case 'assigned_user': return renderOverridableText('assigned_user','Assigned User',<Field key={key} label={getOverride('assigned_user')?.label||'Assigned User'}><input className="input-field" value={form.assigned_user} onChange={e=>set('assigned_user',e.target.value)} placeholder="john.doe"/></Field>);
      case 'department_id': return <Field key={key} label="Department"><select className="input-field" value={form.department_id} onChange={e=>set('department_id',e.target.value)}><option value="">Select…</option>{(dropdowns.departments||[]).map(d=><option key={d.id} value={d.id}>{d.name}</option>)}</select></Field>;
      case 'business_purpose': return <Field key={key} label="Business Purpose"><input className="input-field" value={form.business_purpose} onChange={e=>set('business_purpose',e.target.value)} placeholder="Web server"/></Field>;
      case 'asset_tag':     return (
        <div key={key} className="col-span-full">
          <label className="block text-sm font-medium text-gray-700 mb-0.5">Asset Tag</label>
          <AssetTagWidget departmentId={form.department_id} departments={dropdowns.departments||[]} value={form.asset_tag} onChange={tag=>set('asset_tag',tag)} onValidation={err=>setTagValidation(err)} excludeAssetId={editAsset?.id} disabled={!canWrite}/>
        </div>
      );
      case 'server_status_id':      return <Field key={key} label="Server Status"><select className="input-field" value={form.server_status_id} onChange={e=>set('server_status_id',e.target.value)}><option value="">Select…</option>{(dropdowns.server_status||[]).map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select></Field>;
      case 'server_patch_type_id':  return <Field key={key} label="Server Patch Type"><select className="input-field" value={form.server_patch_type_id} onChange={e=>set('server_patch_type_id',e.target.value)}><option value="">Select…</option>{(dropdowns.server_patch_types||[]).map(t=><option key={t.id} value={t.id}>{t.name}</option>)}</select></Field>;
      case 'patching_schedule_id':  return <Field key={key} label="Patching Schedule"><select className="input-field" value={form.patching_schedule_id} onChange={e=>set('patching_schedule_id',e.target.value)}><option value="">Select…</option>{(dropdowns.patching_schedules||[]).map(t=><option key={t.id} value={t.id}>{t.name}</option>)}</select></Field>;
      case 'patching_type_id':      return <Field key={key} label="Patching Type"><select className="input-field" value={form.patching_type_id} onChange={e=>set('patching_type_id',e.target.value)}><option value="">Select…</option>{(dropdowns.patching_types||[]).map(t=><option key={t.id} value={t.id}>{t.name}</option>)}</select></Field>;
      case 'location_id':           return <Field key={key} label="Location"><select className="input-field" value={form.location_id} onChange={e=>set('location_id',e.target.value)}><option value="">Select…</option>{(dropdowns.locations||[]).map(t=><option key={t.id} value={t.id}>{t.name}</option>)}</select></Field>;
      case 'eol_status':            return <Field key={key} label="EOL Status"><select className="input-field" value={form.eol_status} onChange={e=>set('eol_status',e.target.value)}><option value="InSupport">In Support</option><option value="EOL">EOL</option><option value="Decom">Decommissioned</option></select></Field>;
      case 'me_installed_status':   return <Field key={key} label="ManageEngine Installed"><div className="flex items-center gap-3 h-9"><Toggle checked={form.me_installed_status} onChange={v=>set('me_installed_status',v)} disabled={!canWrite}/><span className="text-sm text-gray-600">{form.me_installed_status?'Installed':'Not Installed'}</span></div></Field>;
      case 'tenable_installed_status': return <Field key={key} label="Tenable Installed"><div className="flex items-center gap-3 h-9"><Toggle checked={form.tenable_installed_status} onChange={v=>set('tenable_installed_status',v)} disabled={!canWrite}/><span className="text-sm text-gray-600">{form.tenable_installed_status?'Installed':'Not Installed'}</span></div></Field>;
      case 'serial_number':         return <Field key={key} label="Serial Number"><input className="input-field" value={form.serial_number} onChange={e=>set('serial_number',e.target.value)} placeholder="SRV-001"/></Field>;
      case 'idrac_enabled':         return (
        <Field key={key} label="iDRAC">
          <div className="flex items-center gap-3 h-9">
            <Toggle checked={form.idrac_enabled} onChange={v=>set('idrac_enabled',v)} disabled={!canWrite}/>
            <span className="text-sm text-gray-600">{form.idrac_enabled?'Yes':'No'}</span>
          </div>
        </Field>
      );
      case 'idrac_ip':    return form.idrac_enabled ? <Field key={key} label="iDRAC IP Address"><input className="input-field font-mono" value={form.idrac_ip} onChange={e=>set('idrac_ip',e.target.value)} placeholder="10.0.0.100"/></Field> : null;
      case 'oem_status':  return form.idrac_enabled ? (
        <Field key={key} label="OEM Status">
          <select className="input-field" value={form.oem_status} onChange={e=>set('oem_status',e.target.value)}>
            <option value="">Select…</option>
            {(oemOptions||[]).map(o=><option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
        </Field>
      ) : null;
      case 'asset_username': return <Field key={key} label="Asset Username"><input className="input-field" value={form.asset_username} onChange={e=>set('asset_username',e.target.value)} placeholder="admin"/></Field>;
      case 'asset_password': return (
        <Field key={key} label="Asset Password">
          <div className="relative">
            <input type={showPw?'text':'password'} className="input-field pr-10" value={form.asset_password} onChange={e=>set('asset_password',e.target.value)} placeholder="••••••••"/>
            <button type="button" onClick={()=>setShowPw(!showPw)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">{showPw?<EyeOff size={15}/>:<Eye size={15}/>}</button>
          </div>
        </Field>
      );
      case 'hosted_ip':          return <Field key={key} label="Hosted IP (Physical Host)" hint="Physical/ESXi server IP hosting this VM"><input className="input-field font-mono" value={form.hosted_ip} onChange={e=>set('hosted_ip',e.target.value)} placeholder="10.0.0.1"/></Field>;
      case 'additional_remarks': return renderOverridableText('additional_remarks','Additional Remarks',<div key={key} className="col-span-full"><Field label={getOverride('additional_remarks')?.label||'Additional Remarks'}><textarea className="input-field" rows={3} value={form.additional_remarks} onChange={e=>set('additional_remarks',e.target.value)} placeholder="Any notes…"/></Field></div>);
      default: return null;
    }
  };

  return allGroups.flatMap(group => {
    const fields = groupMap[group];
    if (!fields?.length) return [];
    return [
      <SectionTitle key={`st-${group}`} title={group}/>,
      ...fields.map(f => renderField(f.key)).filter(Boolean),
    ];
  });
}

const StatusBadge = ({ s }) => {
  const cls = { 'Alive':'bg-green-100 text-green-700','Powered Off':'bg-orange-100 text-orange-700','Not Alive':'bg-red-100 text-red-700' }[s]||'bg-gray-100 text-gray-500';
  return s?<span className={`px-2 py-0.5 rounded-full text-xs font-medium ${cls}`}>{s}</span>:<span className="text-gray-300 text-xs">—</span>;
};

const PatchBadge = ({ s }) => {
  const cls = {'Auto':'bg-green-100 text-green-700','Manual':'bg-blue-100 text-blue-700','Exception':'bg-amber-100 text-amber-700','Beijing IT Team':'bg-purple-100 text-purple-700','EOL - No Patches':'bg-red-100 text-red-700','Onboard Pending':'bg-cyan-100 text-cyan-700','On Hold':'bg-gray-100 text-gray-600'}[s]||'bg-gray-100 text-gray-500';
  return s?<span className={`px-2 py-0.5 rounded-full text-xs font-medium ${cls}`}>{s}</span>:<span className="text-gray-300 text-xs">—</span>;
};

function PasswordCell({ password, canView }) {
  const [show, setShow] = useState(false);
  if (!password) return <span className="text-gray-300 text-xs">—</span>;
  if (!canView) return <span className="text-gray-300 tracking-widest text-xs">••••••••</span>;
  return (
    <div className="flex items-center gap-1">
      <span className="font-mono text-xs text-gray-700">{show?password:'••••••••'}</span>
      <button type="button" onClick={()=>setShow(!show)} className="p-0.5 text-gray-400 hover:text-gray-600">
        {show?<EyeOff size={11}/>:<Eye size={11}/>}
      </button>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// ADD ASSET sub-tab content
// ─────────────────────────────────────────────────────────────
function AddAssetTab({ onSaved, editAsset, onClearEdit }) {
  const { canWrite } = useAuth();
  const { configVersion } = useConfig();
  const [form, setForm]               = useState(ASSET_INIT);
  const [dropdowns, setDropdowns]     = useState({});
  const [osVersions, setOsVersions]   = useState([]);
  const [customFields, setCustomFields] = useState([]);
  const [fieldLayout, setFieldLayout]   = useState(null); // null = loading, {} = DB default
  const [oemOptions, setOemOptions]     = useState([
    { value:'YES', label:'YES — OEM Support Active' },
    { value:'NO',  label:'NO — OEM Support Expired' },
    { value:'NA',  label:'NA — Not Applicable' },
  ]);
  const [loading, setLoading]         = useState(false);
  const [showPw, setShowPw]           = useState(false);
  const [dupState, setDupState]       = useState({ ip: null });
  const [checking, setChecking]       = useState({ ip: false });
  const [tagValidation, setTagValidation] = useState(null); // null=ok, string=error
  const [csvFile, setCsvFile]         = useState(null);
  const [importing, setImporting]     = useState(false);
  const [fieldTypeOverrides, setFieldTypeOverrides] = useState({});
  const ipTimer = useRef(null);

  const fetchMeta = useCallback(async () => {
    try {
      const [dd, cf, layout, oem] = await Promise.all([
        dropdownsAPI.getAll(),
        settingsAPI.getCustomFields(),
        settingsAPI.getFieldLayout(),
        settingsAPI.getOemOptions(),
      ]);
      setDropdowns(dd.data);
      setCustomFields(cf.data.filter(f => f.is_active));
      setFieldLayout(layout.data && Object.keys(layout.data).length > 0 ? layout.data : DEFAULT_FIELD_LAYOUT);
      if (oem.data?.length) setOemOptions(oem.data);
      const ft = await settingsAPI.getBuiltinFieldTypes('asset').catch(()=>({data:{}}));
      setFieldTypeOverrides(ft.data || {});
    } catch { setFieldLayout(DEFAULT_FIELD_LAYOUT); }
  }, []);

  useEffect(() => { fetchMeta(); }, [fetchMeta, configVersion]);
  useEffect(() => {
    if (editAsset) setForm({ ...ASSET_INIT, ...editAsset, custom_field_values: editAsset.custom_field_values || {} });
    else setForm(ASSET_INIT);
  }, [editAsset]);

  useEffect(() => {
    const versions = form.os_type_id ? (dropdowns.os_versions||[]).filter(v=>v.os_type_id===parseInt(form.os_type_id)) : [];
    setOsVersions(versions);
  }, [form.os_type_id, dropdowns.os_versions]);

  const set = (k,v) => setForm(p=>({...p,[k]:v}));
  const setCustom = (k,v) => setForm(p=>({...p,custom_field_values:{...p.custom_field_values,[k]:v}}));

  const checkIP = async (ip) => {
    if (!ip?.trim()) { setDupState({ip:null}); return; }
    setChecking({ip:true});
    try {
      const r = await assetsAPI.checkDuplicate({ip_address:ip.trim(), exclude_id:editAsset?.id});
      setDupState({ip: r.data.duplicate ? r.data.errors[0] : false});
    } catch { setDupState({ip:null}); }
    finally { setChecking({ip:false}); }
  };

  const handleIPChange = (v) => {
    set('ip_address', v);
    clearTimeout(ipTimer.current);
    ipTimer.current = setTimeout(()=>checkIP(v), 700);
  };

  const hasDupError = !!dupState.ip;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!canWrite||hasDupError||tagValidation) { toast.error(hasDupError?'Fix duplicate IP':tagValidation||'Fix errors'); return; }
    setLoading(true);
    try {
      const payload = {...form, asset_type_id:form.asset_type_id||null, os_type_id:form.os_type_id||null, os_version_id:form.os_version_id||null, department_id:form.department_id||null, server_status_id:form.server_status_id||null, patching_schedule_id:form.patching_schedule_id||null, patching_type_id:form.patching_type_id||null, server_patch_type_id:form.server_patch_type_id||null, location_id:form.location_id||null};
      if (editAsset) { await assetsAPI.update(editAsset.id, payload); toast.success('Asset updated'); }
      else           { await assetsAPI.create(payload);               toast.success('Asset added'); }
      setForm(ASSET_INIT); setDupState({ip:null}); setTagValidation(null);
      onSaved();
    } catch(err) {
      const msg = err.response?.data?.error||'Failed';
      if (err.response?.data?.duplicate) toast.error('Duplicate IP: '+msg,{duration:6000});
      else toast.error(msg);
    } finally { setLoading(false); }
  };

  const handleImport = async () => {
    if (!csvFile) { toast.error('Select a CSV'); return; }
    setImporting(true);
    try {
      const r = await assetsAPI.importCSV(csvFile);
      toast.success(`Imported ${r.data.success}${r.data.skipped>0?`, ${r.data.skipped} skipped`:''}`);
      setCsvFile(null); onSaved();
    } catch(err) { toast.error(err.response?.data?.error||'Import failed'); }
    finally { setImporting(false); }
  };

  const grouped = customFields.reduce((acc,cf)=>{ const g=cf.field_group||'General'; if(!acc[g])acc[g]=[]; acc[g].push(cf); return acc; },{});

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm text-gray-500">{editAsset?`Editing: ${editAsset.vm_name||editAsset.os_hostname||'Asset #'+editAsset.id}`:'Fill in the details below to add a new asset'}</p>
        <div className="flex items-center gap-2">
          {!editAsset && (
            <>
              <button onClick={async()=>{try{const r=await assetsAPI.downloadTemplate();const url=URL.createObjectURL(new Blob([r.data]));const a=document.createElement('a');a.href=url;a.download='asset_import_template.csv';a.click();URL.revokeObjectURL(url);}catch{toast.error('Download failed');}}} className="btn-secondary text-xs"><Download size={13}/> Template</button>
              <label className="btn-secondary text-xs cursor-pointer"><Upload size={13}/>{csvFile?csvFile.name.slice(0,14)+'…':'Select CSV'}<input type="file" accept=".csv" className="hidden" onChange={e=>setCsvFile(e.target.files[0])}/></label>
              {csvFile && <button onClick={handleImport} disabled={importing} className="btn-success text-xs">{importing?'Importing…':'Import'}</button>}
            </>
          )}
          {editAsset && <button onClick={()=>{ setForm(ASSET_INIT); onClearEdit(); }} className="btn-secondary text-xs"><RotateCcw size={13}/> Cancel Edit</button>}
        </div>
      </div>

      {!canWrite && <div className="mb-4 p-3 bg-amber-50 border border-amber-200 rounded-lg text-sm text-amber-700">Read-only access.</div>}
      {dupState.ip && <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700 flex items-center gap-2"><AlertTriangle size={16}/> {dupState.ip}</div>}

      <form onSubmit={handleSubmit}>
        <div className="card mb-4">
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {renderFormGroups({
              layout: fieldLayout || DEFAULT_FIELD_LAYOUT,
              form, set, dropdowns, osVersions,
              canWrite, showPw, setShowPw,
              dupState, checking,
              tagValidation, setTagValidation,
              editAsset,
              handleIPChange,
              oemOptions,
              fieldTypeOverrides,
            })}
            {/* Dynamic custom field groups */}
            {Object.entries(grouped).map(([group,fields])=>(
              <React.Fragment key={group}>
                <SectionTitle title={group}/>
                {fields.map(cf=><Field key={cf.id} label={cf.field_label}><RenderCustomField cf={cf} value={form.custom_field_values[cf.field_key]} onChange={v=>setCustom(cf.field_key,v)} disabled={!canWrite}/></Field>)}
              </React.Fragment>
            ))}
          </div>
        </div>
        <div className="flex gap-3">
          <button type="submit" disabled={loading||!canWrite||hasDupError||!!tagValidation} className="btn-primary">
            <PlusCircle size={16}/>{loading?'Saving…':editAsset?'Update Asset':'Add Asset'}
          </button>
          <button type="button" onClick={()=>{setForm(ASSET_INIT);setDupState({ip:null});setTagValidation(null);if(editAsset)onClearEdit();}} className="btn-secondary"><RotateCcw size={16}/> Clear</button>
        </div>
      </form>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// ASSET LIST sub-tab content
// ─────────────────────────────────────────────────────────────
// ── Default column order + visibility for Asset List ──────────────────────────
const ASSET_COL_DEFAULTS = [
  {key:'os_hostname',visible:true},{key:'asset_type',visible:true},{key:'os_type',visible:true},
  {key:'os_version',visible:true},{key:'assigned_user',visible:true},{key:'department',visible:true},
  {key:'server_status',visible:true},{key:'patching_type',visible:true},{key:'server_patch_type',visible:true},
  {key:'patching_schedule',visible:true},{key:'location',visible:true},{key:'serial_number',visible:true},
  {key:'idrac',visible:true},{key:'oem_status',visible:true},{key:'eol_status',visible:true},
  {key:'me_installed',visible:true},{key:'tenable_installed',visible:true},{key:'hosted_ip',visible:true},
  {key:'asset_tag',visible:true},{key:'business_purpose',visible:false},{key:'additional_remarks',visible:false},
  {key:'asset_username',visible:false},{key:'asset_password',visible:false},{key:'submitted_by',visible:false},
  {key:'updated_at',visible:true},
];

function mergeAssetColConfig(saved){
  if(!saved||!saved.length) return ASSET_COL_DEFAULTS;
  const savedMap=Object.fromEntries(saved.map((s,i)=>[s.key,{...s,order:i}]));
  const merged=ASSET_COL_DEFAULTS.map((d,i)=>({...d,visible:savedMap[d.key]!==undefined?savedMap[d.key].visible:d.visible,order:savedMap[d.key]!==undefined?savedMap[d.key].order:999+i}));
  return merged.sort((a,b)=>a.order-b.order);
}

function AssetListTab({ onEdit, refreshKey }) {
  const { canWrite, user } = useAuth();
  const { configVersion } = useConfig();
  const navigate = useNavigate();
  const [assets, setAssets]       = useState([]);
  const [total, setTotal]         = useState(0);
  const [page, setPage]           = useState(1);
  const limit = 15;
  const [loading, setLoading]     = useState(true);
  const [exporting, setExporting] = useState(false);
  const [dropdowns, setDropdowns] = useState({});
  const [customFields, setCustomFields] = useState([]);
  const [colConfig, setColConfig]  = useState(ASSET_COL_DEFAULTS);
  const [filters, setFilters]     = useState({search:'',location:'',department:'',server_status:'',asset_type:''});

  const fetchMeta = useCallback(async () => {
    try {
      const [dd,cf,colR]=await Promise.all([
        dropdownsAPI.getAll(),
        settingsAPI.getCustomFields(),
        settingsAPI.getColumnConfig('asset').catch(()=>({data:[]})),
      ]);
      setDropdowns(dd.data);
      setCustomFields(cf.data.filter(f=>f.is_active));
      setColConfig(mergeAssetColConfig(colR.data));
    } catch {}
  },[]);
  const fetchAssets = useCallback(async () => {
    setLoading(true);
    try {
      const params={page,limit,...filters};
      Object.keys(params).forEach(k=>{if(!params[k])delete params[k];});
      const r=await assetsAPI.getAll(params);
      setAssets(r.data.assets); setTotal(r.data.total);
    } catch { toast.error('Failed to load'); }
    finally { setLoading(false); }
  },[page,limit,filters]);

  useEffect(()=>{fetchMeta();},[fetchMeta,configVersion]);
  useEffect(()=>{fetchAssets();},[fetchAssets,configVersion,refreshKey]);

  const setFilter=(k,v)=>{setFilters(p=>({...p,[k]:v}));setPage(1);};
  const handleDelete=async(a)=>{if(!confirm(`Delete "${a.vm_name||a.os_hostname}"?`))return;try{await assetsAPI.delete(a.id);toast.success('Deleted');fetchAssets();}catch(err){toast.error(err.response?.data?.error||'Delete failed');}};
  const handleExport=async()=>{setExporting(true);try{const params={...filters};Object.keys(params).forEach(k=>{if(!params[k])delete params[k];});const r=await assetsAPI.exportCSV(params);const url=URL.createObjectURL(new Blob([r.data],{type:'text/csv'}));const a=document.createElement('a');a.href=url;a.download=`inventory-${new Date().toISOString().split('T')[0]}.csv`;a.click();URL.revokeObjectURL(url);toast.success('Exported');}catch{toast.error('Export failed');}finally{setExporting(false);}};
  const canViewPw = user?.can_view_passwords || user?.role === 'admin' || user?.role === 'superadmin';
  const totalPages=Math.ceil(total/limit);
  const COL_VM=140,COL_IP=120;
  const renderCustomVal=(a,cf)=>{const raw=a.custom_field_values?.[cf.field_key];if(raw===undefined||raw===null||raw==='')return<span className="text-gray-300 text-xs">—</span>;if(cf.field_type==='toggle')return raw?<span className="text-green-600 text-xs">✓ Yes</span>:<span className="text-gray-400 text-xs">No</span>;return<span className="text-xs text-gray-700">{String(raw)}</span>;};

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm text-gray-500">{total} total assets</p>
        <div className="flex gap-2">
          <button onClick={handleExport} disabled={exporting} className="btn-secondary text-xs"><Download size={13}/>{exporting?'Exporting…':'Export CSV'}</button>
          <button onClick={fetchAssets} className="btn-secondary text-xs"><RefreshCw size={13}/> Refresh</button>
        </div>
      </div>
      <div className="card mb-4">
        <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
          <div className="relative xl:col-span-2"><Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"/><input className="input-field pl-8" placeholder="VM name, hostname, IP…" value={filters.search} onChange={e=>setFilter('search',e.target.value)}/></div>
          <select className="input-field" value={filters.location} onChange={e=>setFilter('location',e.target.value)}><option value="">All Locations</option>{(dropdowns.locations||[]).map(l=><option key={l.id} value={l.name}>{l.name}</option>)}</select>
          <select className="input-field" value={filters.department} onChange={e=>setFilter('department',e.target.value)}><option value="">All Departments</option>{(dropdowns.departments||[]).map(d=><option key={d.id} value={d.name}>{d.name}</option>)}</select>
          <select className="input-field" value={filters.server_status} onChange={e=>setFilter('server_status',e.target.value)}><option value="">All Statuses</option>{(dropdowns.server_status||[]).map(s=><option key={s.id} value={s.name}>{s.name}</option>)}</select>
          <select className="input-field" value={filters.asset_type} onChange={e=>setFilter('asset_type',e.target.value)}><option value="">All Types</option>{(dropdowns.asset_types||[]).map(t=><option key={t.id} value={t.name}>{t.name}</option>)}</select>
        </div>
      </div>
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm" style={{borderCollapse:'separate',borderSpacing:0}}>
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="table-th bg-gray-50 z-20 border-r border-gray-200" style={{position:'sticky',left:0,minWidth:COL_VM}}>VM Name</th>
                <th className="table-th bg-gray-50 z-20 border-r border-gray-200" style={{position:'sticky',left:COL_VM,minWidth:COL_IP}}>IP Address</th>
                {colConfig.filter(c=>c.visible).map(c=>{
                  const labels={os_hostname:'Hostname',asset_type:'Asset Type',os_type:'OS',os_version:'OS Version',assigned_user:'Assigned User',department:'Dept',server_status:'Status',patching_type:'Patch Type',server_patch_type:'Ser. Patch Type',patching_schedule:'Schedule',location:'Location',serial_number:'Serial',idrac:'iDRAC',oem_status:'OEM',eol_status:'EOL',me_installed:'ME',tenable_installed:'Tenable',hosted_ip:'Hosted IP',asset_tag:'Asset Tag',business_purpose:'Business Purpose',additional_remarks:'Add. Remark',asset_username:'Username',asset_password:'Password',submitted_by:'Submitted By',updated_at:'Last Modified',actions:'Actions'};
                  return <th key={c.key} className="table-th">{labels[c.key]||c.key}</th>;
                })}
                {customFields.map(cf=><th key={cf.field_key} className="table-th">{cf.field_label}</th>)}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {loading?Array(5).fill(0).map((_,i)=><tr key={i} className="animate-pulse"><td className="table-td bg-white" style={{position:'sticky',left:0}}><div className="h-4 bg-gray-100 rounded"/></td><td className="table-td bg-white" style={{position:'sticky',left:COL_VM}}><div className="h-4 bg-gray-100 rounded"/></td>{colConfig.filter(c=>c.visible).map((_,j)=><td key={j} className="table-td"><div className="h-4 bg-gray-100 rounded"/></td>)}{customFields.map(cf=><td key={cf.field_key} className="table-td"><div className="h-4 bg-gray-100 rounded"/></td>)}</tr>)
              :assets.length===0?<tr><td colSpan={2+colConfig.filter(c=>c.visible).length+customFields.length} className="text-center py-16 text-gray-400"><p className="text-4xl mb-2">📭</p><p className="font-medium">No assets found</p></td></tr>
              :assets.map(a=>(
                <tr key={a.id} className="hover:bg-blue-50/20">
                  <td className="table-td font-mono text-xs font-semibold text-blue-800 bg-white border-r border-gray-100" style={{position:'sticky',left:0,minWidth:COL_VM}}>
                    {a.vm_name?<button onClick={()=>navigate(`/assets/${a.id}`)} className="hover:underline text-blue-800 text-left w-full">{a.vm_name}</button>:<span className="text-gray-400">—</span>}
                  </td>
                  <td className="table-td font-mono text-xs bg-white border-r border-gray-100" style={{position:'sticky',left:COL_VM,minWidth:COL_IP}}>
                    {a.ip_address?<button onClick={()=>navigate(`/assets/${a.id}`)} className="hover:underline text-blue-700 font-medium">{a.ip_address}</button>:<span className="text-gray-400">—</span>}
                  </td>
                  {colConfig.filter(c=>c.visible).map(c=>{
                    switch(c.key){
                      case 'os_hostname':    return <td key={c.key} className="table-td font-mono text-xs">{a.os_hostname||'—'}</td>;
                      case 'asset_type':     return <td key={c.key} className="table-td text-xs">{a.asset_type||'—'}</td>;
                      case 'os_type':        return <td key={c.key} className="table-td text-xs">{a.os_type||'—'}</td>;
                      case 'os_version':     return <td key={c.key} className="table-td text-xs max-w-[130px] truncate">{a.os_version||'—'}</td>;
                      case 'assigned_user':  return <td key={c.key} className="table-td text-xs">{a.assigned_user||'—'}</td>;
                      case 'department':     return <td key={c.key} className="table-td text-xs">{a.department||'—'}</td>;
                      case 'server_status':  return <td key={c.key} className="table-td"><StatusBadge s={a.server_status}/></td>;
                      case 'patching_type':  return <td key={c.key} className="table-td"><PatchBadge s={a.patching_type}/></td>;
                      case 'server_patch_type': return <td key={c.key} className="table-td text-xs">{a.server_patch_type||'—'}</td>;
                      case 'patching_schedule': return <td key={c.key} className="table-td text-xs">{a.patching_schedule||'—'}</td>;
                      case 'location':       return <td key={c.key} className="table-td text-xs">{a.location||'—'}</td>;
                      case 'serial_number':  return <td key={c.key} className="table-td font-mono text-xs">{a.serial_number||'—'}</td>;
                      case 'idrac':          return <td key={c.key} className="table-td text-xs">{a.idrac_enabled?<span className="text-green-700 text-xs font-medium" title={a.idrac_ip||''}>Yes{a.idrac_ip?` (${a.idrac_ip})`:''}</span>:<span className="text-gray-400 text-xs">No</span>}</td>;
                      case 'oem_status':     return <td key={c.key} className="table-td">{a.oem_status?<span className={`px-2 py-0.5 rounded-full text-xs font-medium ${a.oem_status==='YES'?'bg-green-100 text-green-700':a.oem_status==='NO'?'bg-red-100 text-red-600':'bg-gray-100 text-gray-500'}`}>{a.oem_status}</span>:<span className="text-gray-300 text-xs">—</span>}</td>;
                      case 'eol_status':     return <td key={c.key} className="table-td text-xs"><span className={a.eol_status==='InSupport'?'text-green-700':a.eol_status==='EOL'?'text-orange-600':'text-red-600'}>{a.eol_status||'—'}</span></td>;
                      case 'me_installed':   return <td key={c.key} className="table-td"><MEIcon installed={a.me_installed_status} size={18}/></td>;
                      case 'tenable_installed': return <td key={c.key} className="table-td"><TenableIcon installed={a.tenable_installed_status} size={18}/></td>;
                      case 'hosted_ip':      return <td key={c.key} className="table-td">{a.hosted_ip?<div className="flex items-center gap-1"><button onClick={()=>navigate(`/physical-assets?ip=${encodeURIComponent(a.hosted_ip)}`)} className="text-xs font-mono text-blue-700 hover:underline flex items-center gap-1"><Server size={11}/>{a.hosted_ip}</button><a href={`https://${a.hosted_ip}/ui/#/login`} target="_blank" rel="noopener noreferrer" className="p-0.5 text-gray-400 hover:text-blue-600"><ExternalLink size={11}/></a></div>:<span className="text-gray-300 text-xs">—</span>}</td>;
                      case 'asset_tag':      return <td key={c.key} className="table-td font-mono text-xs font-medium text-purple-700">{a.asset_tag||'—'}</td>;
                      case 'business_purpose': return <td key={c.key} className="table-td text-xs text-gray-600 max-w-[140px] truncate" title={a.business_purpose||''}>{a.business_purpose||'—'}</td>;
                      case 'additional_remarks': return <td key={c.key} className="table-td text-xs text-gray-600 max-w-[160px] truncate" title={a.additional_remarks||''}>{a.additional_remarks||'—'}</td>;
                      case 'asset_username': return <td key={c.key} className="table-td font-mono text-xs">{a.asset_username||'—'}</td>;
                      case 'asset_password': return <td key={c.key} className="table-td"><PasswordCell password={a.asset_password} canView={canViewPw}/></td>;
                      case 'submitted_by':   return <td key={c.key} className="table-td text-xs text-gray-500">{a.submitted_by||'—'}</td>;
                      case 'updated_at':     return <td key={c.key} className="table-td text-xs text-gray-400 whitespace-nowrap">{a.updated_at?new Date(a.updated_at).toLocaleString('en-GB',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}):''}</td>;
                      case 'actions':        return <td key={c.key} className="table-td"><div className="flex gap-1">{canWrite&&<><button onClick={()=>onEdit(a)} className="p-1.5 text-blue-600 hover:bg-blue-100 rounded" title="Edit"><Edit2 size={12}/></button><button onClick={()=>handleDelete(a)} className="p-1.5 text-red-500 hover:bg-red-100 rounded" title="Delete"><Trash2 size={12}/></button></>}</div></td>;
                      default: return null;
                    }
                  })}
                  {customFields.map(cf=><td key={cf.field_key} className="table-td">{renderCustomVal(a,cf)}</td>)}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {totalPages>1&&(
          <div className="border-t border-gray-200 px-4 py-3 flex items-center justify-between bg-gray-50">
            <p className="text-xs text-gray-500">Showing {(page-1)*limit+1}–{Math.min(page*limit,total)} of {total}</p>
            <div className="flex items-center gap-1">
              <button onClick={()=>setPage(p=>Math.max(1,p-1))} disabled={page===1} className="p-1.5 rounded border border-gray-300 disabled:opacity-40 hover:bg-gray-100"><ChevronLeft size={13}/></button>
              {Array.from({length:Math.min(7,totalPages)},(_,i)=>{const pg=page<=4?i+1:page-3+i;if(pg<1||pg>totalPages)return null;return<button key={pg} onClick={()=>setPage(pg)} className={`px-3 py-1 text-xs rounded border ${pg===page?'bg-blue-800 text-white border-blue-800':'border-gray-300 hover:bg-gray-100'}`}>{pg}</button>;})}
              <button onClick={()=>setPage(p=>Math.min(totalPages,p+1))} disabled={page===totalPages} className="p-1.5 rounded border border-gray-300 disabled:opacity-40 hover:bg-gray-100"><ChevronRight size={13}/></button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// COMBINED PAGE
// ─────────────────────────────────────────────────────────────
export default function AssetListCombinedPage() {
  const { canViewPage } = useAuth();
  const location     = useLocation();
  const [searchParams, setSearchParams] = useSearchParams();
  // Respect tab-level permissions — if add tab is hidden, default to list
  const requestedTab = searchParams.get('tab') || 'list';
  const initialTab = (requestedTab === 'add' && !canViewPage('asset-list-add')) ? 'list' : requestedTab;
  const [activeTab, setActiveTab] = useState(initialTab);
  const [editAsset, setEditAsset]  = useState(null);
  const [refreshKey, setRefreshKey] = useState(0);

  // Handle navigation from AssetDetailPage "Edit" button
  useEffect(() => {
    const state = location.state;
    if (state?.editAssetId) {
      assetsAPI.getById(state.editAssetId).then(r => {
        setEditAsset(r.data);
        setActiveTab('add');
        setSearchParams({ tab: 'add' });
      }).catch(() => {});
      // Clear the state so re-renders don't re-trigger
      window.history.replaceState({}, '', window.location.href);
    }
  }, []); // eslint-disable-line

  const switchTab = (tab) => {
    setActiveTab(tab);
    setSearchParams({ tab });
  };

  const handleEdit = (asset) => {
    setEditAsset(asset);
    switchTab('add');
  };

  const handleSaved = () => {
    setEditAsset(null);
    setRefreshKey(k => k + 1);
    switchTab('list');
  };

  const TABS = [
    { key: 'add',  label: 'Add New Asset',       icon: Plus },
    { key: 'list', label: 'Asset Inventory List', icon: List },
  ];

  return (
    <div>
      {/* Page header */}
      <div className="mb-5">
        <h1 className="text-2xl font-bold text-gray-800">Asset List</h1>
        <p className="text-sm text-gray-500 mt-0.5">Add new assets and manage your asset inventory</p>
      </div>

      {/* Sub-tabs */}
      <div className="flex gap-1 bg-gray-100 p-1 rounded-xl mb-6 w-fit">
        {TABS.filter(t => t.key === 'list' ? canViewPage('asset-list-inventory') : canViewPage('asset-list-add')).map(({ key, label, icon: Icon }) => (
          <button key={key} onClick={() => switchTab(key)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              activeTab === key
                ? 'bg-white text-blue-800 shadow-sm'
                : 'text-gray-500 hover:text-gray-700'
            }`}>
            <Icon size={15} />
            {label}
          </button>
        ))}
      </div>

      {/* Tab content */}
      {activeTab === 'add' && (
        <AddAssetTab
          editAsset={editAsset}
          onSaved={handleSaved}
          onClearEdit={() => setEditAsset(null)}
        />
      )}
      {activeTab === 'list' && (
        <AssetListTab
          onEdit={handleEdit}
          refreshKey={refreshKey}
        />
      )}
    </div>
  );
}
