import axios from 'axios';

const api = axios.create({ baseURL: '/api', timeout: 30000 });

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

export const authAPI = {
  login: (d) => api.post('/auth/login', d),
  register: (d) => api.post('/auth/register', d),
  me: () => api.get('/auth/me'),
  updateProfile: (d) => api.put('/auth/profile', d),
  uploadAvatar: (file) => {
    const fd = new FormData(); fd.append('avatar', file);
    return api.post('/auth/profile/avatar', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
  },
  deleteAvatar: () => api.delete('/auth/profile/avatar'),
  changePassword: (d) => api.put('/auth/change-password', d),
};

export const dashboardAPI = {
  getStats: () => api.get('/dashboard/stats'),
};

export const assetsAPI = {
  getAll: (params) => api.get('/assets', { params }),
  getById: (id) => api.get(`/assets/${id}`),
  create: (d) => api.post('/assets', d),
  update: (id, d) => api.put(`/assets/${id}`, d),
  delete: (id) => api.delete(`/assets/${id}`),
  checkDuplicate: (params) => api.get('/assets/check-duplicate', { params }),
  exportCSV: (params) => api.get('/assets/export/csv', { params, responseType: 'blob' }),
  downloadTemplate: () => api.get('/assets/export/csv-template', { responseType: 'blob' }),
  importCSV: (file) => {
    const fd = new FormData(); fd.append('file', file);
    return api.post('/assets/import/csv', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
  },
};

export const dropdownsAPI = {
  getAll: () => api.get('/dropdowns/all'),
  addItem: (table, d) => api.post(`/dropdowns/${table}`, d),
  updateItem: (table, id, d) => api.put(`/dropdowns/${table}/${id}`, d),
  deleteItem: (table, id) => api.delete(`/dropdowns/${table}/${id}`),
  addOsVersion: (d) => api.post('/dropdowns/os_versions/add', d),
  updateOsVersion: (id, d) => api.put(`/dropdowns/os_versions/${id}`, d),
  deleteOsVersion: (id) => api.delete(`/dropdowns/os_versions/${id}`),
};

export const usersAPI = {
  getAll: () => api.get('/users'),
  create: (d) => api.post('/users/create', d),
  update: (id, d) => api.put(`/users/${id}`, d),
  delete: (id) => api.delete(`/users/${id}`),
  updatePagePerms: (id, d) => api.put(`/users/${id}/page-permissions`, d),
  updatePasswordVisibility: (id, d) => api.put(`/users/${id}/password-visibility`, d),
  resetPassword: (id, d) => api.put(`/users/${id}/reset-password`, d),
  getAllPermissions: () => api.get('/users/permissions/all'),
};

export const settingsAPI = {
  getBranding: () => api.get('/settings/branding'),
  updateBranding: (d) => api.put('/settings/branding', d),
  uploadLogo: (file) => {
    const fd = new FormData(); fd.append('logo', file);
    return api.post('/settings/branding/logo', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
  },
  deleteLogo: () => api.delete('/settings/branding/logo'),
  getCustomFields: () => api.get('/settings/custom-fields'),
  createCustomField: (d) => api.post('/settings/custom-fields', d),
  updateCustomField: (id, d) => api.put(`/settings/custom-fields/${id}`, d),
  deleteCustomField: (id) => api.delete(`/settings/custom-fields/${id}`),
  getOemOptions:            ()       => api.get('/settings/oem-options'),
  saveOemOptions:           (opts)   => api.put('/settings/oem-options', opts),
  getBuiltinFieldTypes:     (scope)  => api.get(`/settings/builtin-field-types/${scope}`),
  saveBuiltinFieldTypes:    (scope, d) => api.put(`/settings/builtin-field-types/${scope}`, d),
  getFieldLayout:           () => api.get('/settings/field-layout'),
  updateFieldLayout:        (layout) => api.put('/settings/field-layout', layout),
  getPhysicalFieldLayout:   () => api.get('/settings/physical-field-layout'),
  updatePhysicalFieldLayout:(layout) => api.put('/settings/physical-field-layout', layout),
  getExtFieldLayout:        () => api.get('/settings/ext-field-layout'),
  updateExtFieldLayout:     (layout) => api.put('/settings/ext-field-layout', layout),
  getDbCommands: () => api.get('/settings/db-commands'),
  getPageIcons:  () => api.get('/settings/page-icons'),
  savePageIcons: (icons) => api.put('/settings/page-icons', icons),
  getColumnConfig:  (scope) => api.get(`/settings/column-config/${scope}`),
  saveColumnConfig: (scope, cfg) => api.put(`/settings/column-config/${scope}`, cfg),
};

export default api;

export const physicalAssetsAPI = {
  getAll: () => api.get('/physical-assets'),
  getByIP: (ip) => api.get(`/physical-assets/by-ip/${encodeURIComponent(ip)}`),
  getById: (id) => api.get(`/physical-assets/${id}`),
  create: (d) => api.post('/physical-assets', d),
  update: (id, d) => api.put(`/physical-assets/${id}`, d),
  delete: (id) => api.delete(`/physical-assets/${id}`),
  getModels: () => api.get('/physical-assets/models/all'),
  addModel: (d) => api.post('/physical-assets/models/add', d),
  updateModel: (id, d) => api.put(`/physical-assets/models/${id}`, d),
  deleteModel: (id) => api.delete(`/physical-assets/models/${id}`),
  getCustomFields: () => api.get('/physical-assets/custom-fields/all'),
  createCustomField: (d) => api.post('/physical-assets/custom-fields/add', d),
  updateCustomField: (id, d) => api.put(`/physical-assets/custom-fields/${id}`, d),
  deleteCustomField: (id) => api.delete(`/physical-assets/custom-fields/${id}`),
  // Import / Export
  exportCSV:       (params) => api.get('/physical-assets/export/csv', { params, responseType: 'blob' }),
  downloadTemplate: ()      => api.get('/physical-assets/export/csv-template', { responseType: 'blob' }),
  importCSV: (file) => {
    const fd = new FormData(); fd.append('file', file);
    return api.post('/physical-assets/import/csv', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
  },
};

export const extendedInventoryAPI = {
  getAll:   (params) => api.get('/extended-inventory', { params }),
  getById:  (id)     => api.get(`/extended-inventory/${id}`),
  create: (d) => api.post('/extended-inventory', d),
  update: (id, d) => api.put(`/extended-inventory/${id}`, d),
  delete: (id) => api.delete(`/extended-inventory/${id}`),
  checkDuplicate: (params) => api.get('/extended-inventory/check-duplicate', { params }),
  exportCSV: (params) => api.get('/extended-inventory/export/csv', { params, responseType: 'blob' }),
  downloadTemplate: () => api.get('/extended-inventory/export/csv-template', { responseType: 'blob' }),
  importCSV: (file) => { const fd = new FormData(); fd.append('file', file); return api.post('/extended-inventory/import/csv', fd, { headers: { 'Content-Type': 'multipart/form-data' } }); },
  getCustomFields: () => api.get('/extended-inventory/custom-fields/all'),
  createCustomField: (d) => api.post('/extended-inventory/custom-fields/add', d),
  updateCustomField: (id, d) => api.put(`/extended-inventory/custom-fields/${id}`, d),
  deleteCustomField: (id) => api.delete(`/extended-inventory/custom-fields/${id}`),
};

export const assetTagsAPI = {
  getRanges:           ()       => api.get('/asset-tags/ranges'),
  getAvailable:        (dept)   => api.get(`/asset-tags/available/${encodeURIComponent(dept)}`),
  getDepartmentStats:  (params) => api.get('/asset-tags/department-stats', { params }),
  validate:            (params) => api.get('/asset-tags/validate', { params }),
};

// Transfer log and not-transferred list (additions to extendedInventoryAPI)
// These are appended to the existing extendedInventoryAPI object but since it's
// already declared, we export them separately for use in TransferPage
export const transferAPI = {
  getNotTransferred: () => api.get('/extended-inventory/not-transferred'),
  getTransferLog:    () => api.get('/extended-inventory/transfer-log'),
  transfer: (id, data) => api.post(`/extended-inventory/${id}/transfer`, data),
};

export const deptRangesAPI = {
  getAll:          ()         => api.get('/dept-ranges'),
  getDepartments:  ()         => api.get('/dept-ranges/departments'),
  getTagUsage:     (dept)     => api.get(`/dept-ranges/tag-usage/${encodeURIComponent(dept)}`),
  save:            (data)     => api.post('/dept-ranges', data),
  update:          (id, data) => api.put(`/dept-ranges/${id}`, data),
  delete:          (id, force)=> api.delete(`/dept-ranges/${id}${force ? '?force=1' : ''}`),
  validate:        (data)     => api.post('/dept-ranges/validate', data),
};

export const backupAPI = {
  getSchedule:  ()     => api.get('/backup/schedule'),
  saveSchedule: (d)    => api.put('/backup/schedule', d),
  getLog:       ()     => api.get('/backup/log'),
  pgDump:       ()     => api.post('/backup/pg-dump', {}, { responseType: 'blob' }),
  csvExport:    (opts) => api.post('/backup/csv-export', opts),
};

export const notificationsAPI = {
  getConfig:     ()    => api.get('/notifications/config'),
  saveSmtp:      (d)   => api.put('/notifications/smtp', d),
  saveTemplates: (d)   => api.put('/notifications/templates', d),
  saveTriggers:  (d)   => api.put('/notifications/triggers', d),
  testSend:      (d)   => api.post('/notifications/test', d),
};
