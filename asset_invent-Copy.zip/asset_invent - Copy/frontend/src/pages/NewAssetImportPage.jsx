import React, { useCallback, useEffect, useMemo, useState } from 'react';
import toast from 'react-hot-toast';
import { vmwareAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { Clock3, Download, DownloadCloud, Plus, RefreshCw, Save, Server, Trash2, Upload } from 'lucide-react';

const INIT_SOURCE = {
  name: '',
  source_type: 'vcenter',
  host: '',
  username: '',
  password: '',
  ignore_ssl: true,
  is_active: true,
};

export default function NewAssetImportPage() {
  const { isAdmin } = useAuth();
  const [sources, setSources] = useState([]);
  const [schedule, setSchedule] = useState({ enabled: false, interval_minutes: 60 });
  const [candidates, setCandidates] = useState([]);
  const [sourceForm, setSourceForm] = useState(INIT_SOURCE);
  const [selected, setSelected] = useState({});
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [savingSource, setSavingSource] = useState(false);
  const [savingSchedule, setSavingSchedule] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [importing, setImporting] = useState(false);
  const [csvFile, setCsvFile] = useState(null);
  const [csvImporting, setCsvImporting] = useState(false);

  const loadAll = useCallback(async () => {
    setLoading(true);
    try {
      const [s, sch, c] = await Promise.all([
        vmwareAPI.getSources(),
        vmwareAPI.getSchedule(),
        vmwareAPI.getCandidates('new'),
      ]);
      setSources(Array.isArray(s.data) ? s.data : []);
      setSchedule(sch.data || { enabled: false, interval_minutes: 60 });
      const rows = Array.isArray(c.data) ? c.data : [];
      setCandidates(rows);
      const defaults = {};
      rows.forEach((_, idx) => { defaults[idx] = false; });
      setSelected(defaults);
    } catch (e) {
      toast.error(e.response?.data?.error || 'Failed to load New Asset Import data');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { if (isAdmin) loadAll(); }, [isAdmin, loadAll]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return candidates;
    return candidates.filter((r) =>
      [r.vm_name, r.os_hostname, r.ip_address, r.source_name, r.power_state, r.guest_os]
        .map((x) => String(x || '').toLowerCase())
        .some((x) => x.includes(q))
    );
  }, [candidates, search]);

  const selectedCount = Object.values(selected).filter(Boolean).length;

  const setSourceField = (k, v) => setSourceForm((p) => ({ ...p, [k]: v }));

  const addSource = async (e) => {
    e.preventDefault();
    if (!sourceForm.name || !sourceForm.host || !sourceForm.username || !sourceForm.password) {
      toast.error('Source name, host, username and password are required');
      return;
    }
    setSavingSource(true);
    try {
      await vmwareAPI.createSource(sourceForm);
      toast.success('Source added');
      setSourceForm(INIT_SOURCE);
      await loadAll();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to add source');
    } finally {
      setSavingSource(false);
    }
  };

  const removeSource = async (id) => {
    if (!confirm('Delete this source?')) return;
    try {
      await vmwareAPI.deleteSource(id);
      toast.success('Source deleted');
      await loadAll();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Delete failed');
    }
  };

  const toggleSource = async (src) => {
    try {
      await vmwareAPI.updateSource(src.id, {
        ...src,
        is_active: !src.is_active,
      });
      await loadAll();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Update failed');
    }
  };

  const saveSchedule = async () => {
    setSavingSchedule(true);
    try {
      await vmwareAPI.saveSchedule(schedule);
      toast.success('Scheduler settings saved');
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to save scheduler');
    } finally {
      setSavingSchedule(false);
    }
  };

  const runScan = async (sourceId = null) => {
    setScanning(true);
    try {
      const r = await vmwareAPI.scan(sourceId);
      const runs = r.data?.runs || [];
      const success = runs.filter((x) => x.status === 'success').length;
      const failedRuns = runs.filter((x) => x.status === 'failed');
      const failed = failedRuns.length;
      if (failed > 0) {
        const first = failedRuns[0];
        const msg = first?.error || 'Unknown scan error';
        toast.error(`Scan completed with failures. Success: ${success}, Failed: ${failed}. ${msg}`);
      } else {
        toast.success(`Scan completed. Success: ${success}, Failed: ${failed}`);
      }
      await loadAll();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Scan failed');
    } finally {
      setScanning(false);
    }
  };

  const importSelected = async () => {
    const ids = candidates
      .map((r, idx) => (selected[idx] ? r.id : null))
      .filter(Boolean);
    if (!ids.length) {
      toast.error('Select at least one VM');
      return;
    }
    setImporting(true);
    try {
      const r = await vmwareAPI.importToExt(ids);
      const d = r.data || {};
      toast.success(`Imported: ${d.success || 0}, Skipped: ${d.skipped || 0}, Failed: ${d.failed || 0}`);
      await loadAll();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Import failed');
    } finally {
      setImporting(false);
    }
  };

  const downloadCsvTemplate = async () => {
    try {
      const r = await vmwareAPI.downloadCsvTemplate();
      const url = URL.createObjectURL(new Blob([r.data], { type: 'text/csv' }));
      const a = document.createElement('a');
      a.href = url;
      a.download = 'vmware_vm_import_template.csv';
      a.click();
      URL.revokeObjectURL(url);
      toast.success('Template downloaded');
    } catch (err) {
      toast.error(err.response?.data?.error || 'Template download failed');
    }
  };

  const uploadCsvCandidates = async () => {
    if (!csvFile) {
      toast.error('Select a CSV file');
      return;
    }
    setCsvImporting(true);
    try {
      const r = await vmwareAPI.importCsvCandidates(csvFile);
      const d = r.data || {};
      toast.success(`CSV processed. New: ${d.new_count || 0}, Exists: ${d.exists_count || 0}, Invalid: ${d.invalid || 0}`);
      setCsvFile(null);
      await loadAll();
    } catch (err) {
      toast.error(err.response?.data?.error || 'CSV import failed');
    } finally {
      setCsvImporting(false);
    }
  };

  const toggleAllFiltered = (checked) => {
    const next = { ...selected };
    filtered.forEach((row) => {
      const idx = candidates.indexOf(row);
      next[idx] = checked;
    });
    setSelected(next);
  };

  if (!isAdmin) {
    return <div className="card text-sm text-amber-700 bg-amber-50 border border-amber-200">Admin access required.</div>;
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center">
          <DownloadCloud size={18} />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-800">New Asset Import</h1>
          <p className="text-sm text-gray-500">
            Scan vCenter/ESXi using read-only accounts, detect VMs with new IPs, and transfer selected VMs to Ext. Asset Inventory.
          </p>
        </div>
      </div>

      <div className="card space-y-4">
        <div className="flex items-center gap-2">
          <Server size={16} className="text-gray-500" />
          <h2 className="text-sm font-semibold text-gray-700">Source Accounts</h2>
        </div>
        <form onSubmit={addSource} className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <input className="input-field" placeholder="Source Name (e.g. VC-Prod)" value={sourceForm.name} onChange={(e) => setSourceField('name', e.target.value)} />
          <select className="input-field" value={sourceForm.source_type} onChange={(e) => setSourceField('source_type', e.target.value)}>
            <option value="vcenter">vCenter (read-only)</option>
            <option value="esxi">Standalone ESXi (root)</option>
          </select>
          <input className="input-field" placeholder="Host (vcenter.local or 10.0.0.10)" value={sourceForm.host} onChange={(e) => setSourceField('host', e.target.value)} />
          <input className="input-field" placeholder="Username" value={sourceForm.username} onChange={(e) => setSourceField('username', e.target.value)} />
          <input className="input-field" type="password" placeholder="Password" value={sourceForm.password} onChange={(e) => setSourceField('password', e.target.value)} />
          <label className="flex items-center gap-2 text-sm text-gray-700 px-2">
            <input type="checkbox" checked={sourceForm.ignore_ssl} onChange={(e) => setSourceField('ignore_ssl', e.target.checked)} />
            Ignore SSL cert errors
          </label>
          <label className="flex items-center gap-2 text-sm text-gray-700 px-2">
            <input type="checkbox" checked={sourceForm.is_active} onChange={(e) => setSourceField('is_active', e.target.checked)} />
            Active for scheduler
          </label>
          <div className="md:col-span-3">
            <button className="btn-primary" disabled={savingSource}>
              <Plus size={14} /> {savingSource ? 'Adding…' : 'Add Source'}
            </button>
          </div>
        </form>

        <div className="overflow-x-auto border border-gray-200 rounded-lg">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-3 py-2 text-left">Name</th>
                <th className="px-3 py-2 text-left">Type</th>
                <th className="px-3 py-2 text-left">Host</th>
                <th className="px-3 py-2 text-left">Username</th>
                <th className="px-3 py-2 text-left">Last Scan</th>
                <th className="px-3 py-2 text-left">Status</th>
                <th className="px-3 py-2 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={7} className="px-3 py-6 text-center text-gray-400">Loading…</td></tr>
              ) : sources.length === 0 ? (
                <tr><td colSpan={7} className="px-3 py-6 text-center text-gray-400">No sources configured</td></tr>
              ) : sources.map((s) => (
                <tr key={s.id} className="border-b border-gray-100 last:border-b-0">
                  <td className="px-3 py-2 font-medium">{s.name}</td>
                  <td className="px-3 py-2">{s.source_type}</td>
                  <td className="px-3 py-2">{s.host}</td>
                  <td className="px-3 py-2">{s.username}</td>
                  <td className="px-3 py-2">{s.last_scan_at ? new Date(s.last_scan_at).toLocaleString() : '—'}</td>
                  <td className="px-3 py-2">
                    <span
                      className={`px-2 py-0.5 rounded text-xs ${s.last_scan_status === 'success' ? 'bg-green-100 text-green-700' : s.last_scan_status === 'failed' ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-600'}`}
                      title={s.last_error || ''}
                    >
                      {s.last_scan_status}
                    </span>
                    {s.last_scan_status === 'failed' && s.last_error ? (
                      <div className="text-[11px] text-red-600 mt-1 max-w-[260px] truncate" title={s.last_error}>
                        {s.last_error}
                      </div>
                    ) : null}
                  </td>
                  <td className="px-3 py-2">
                    <div className="flex items-center gap-2">
                      <button className="btn-secondary text-xs" onClick={() => runScan(s.id)} disabled={scanning}>
                        <RefreshCw size={12} className={scanning ? 'animate-spin' : ''} /> Scan
                      </button>
                      <button className="btn-secondary text-xs" onClick={() => toggleSource(s)}>
                        {s.is_active ? 'Deactivate' : 'Activate'}
                      </button>
                      <button className="p-1.5 text-red-600 hover:bg-red-50 rounded" onClick={() => removeSource(s.id)} title="Delete Source">
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="card">
        <div className="flex items-center gap-2 mb-3">
          <Clock3 size={16} className="text-gray-500" />
          <h2 className="text-sm font-semibold text-gray-700">Scheduler</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 items-end">
          <label className="flex items-center gap-2 text-sm text-gray-700">
            <input type="checkbox" checked={schedule.enabled} onChange={(e) => setSchedule((p) => ({ ...p, enabled: e.target.checked }))} />
            Enable automatic scan
          </label>
          <div>
            <label className="block text-xs text-gray-500 mb-1">Interval (minutes)</label>
            <input type="number" min={5} className="input-field" value={schedule.interval_minutes} onChange={(e) => setSchedule((p) => ({ ...p, interval_minutes: parseInt(e.target.value, 10) || 60 }))} />
          </div>
          <div className="flex gap-2">
            <button className="btn-primary" onClick={saveSchedule} disabled={savingSchedule}>
              <Save size={13} /> {savingSchedule ? 'Saving…' : 'Save Scheduler'}
            </button>
            <button className="btn-secondary" onClick={() => runScan(null)} disabled={scanning}>
              <RefreshCw size={13} className={scanning ? 'animate-spin' : ''} /> Scan All Now
            </button>
          </div>
        </div>
      </div>

      <div className="card space-y-3">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-semibold text-gray-700">New VM Candidates (IP not found in inventory)</h2>
            <span className="text-xs px-2 py-0.5 rounded bg-gray-100 text-gray-600">{candidates.length}</span>
          </div>
          <div className="flex gap-2">
            <input className="input-field text-sm py-1.5" placeholder="Search..." value={search} onChange={(e) => setSearch(e.target.value)} />
            <button className="btn-secondary text-sm" onClick={downloadCsvTemplate}>
              <Download size={13} /> Template
            </button>
            <label className="btn-secondary text-sm cursor-pointer">
              <Upload size={13} /> {csvFile ? `${csvFile.name.slice(0, 14)}...` : 'Select CSV'}
              <input type="file" accept=".csv" className="hidden" onChange={(e) => setCsvFile(e.target.files?.[0] || null)} />
            </label>
            {csvFile ? (
              <button className="btn-secondary text-sm" onClick={uploadCsvCandidates} disabled={csvImporting}>
                {csvImporting ? 'Uploading...' : 'Upload CSV'}
              </button>
            ) : null}
            <button className="btn-success text-sm" onClick={importSelected} disabled={importing || selectedCount === 0}>
              {importing ? 'Transferring…' : `Transfer to Ext. Inventory (${selectedCount})`}
            </button>
          </div>
        </div>

        <div className="overflow-x-auto border border-gray-200 rounded-lg">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-3 py-2 text-left w-10">
                  <input type="checkbox" checked={filtered.length > 0 && filtered.every((row) => selected[candidates.indexOf(row)])} onChange={(e) => toggleAllFiltered(e.target.checked)} />
                </th>
                <th className="px-3 py-2 text-left">Source</th>
                <th className="px-3 py-2 text-left">VM Name</th>
                <th className="px-3 py-2 text-left">Hostname</th>
                <th className="px-3 py-2 text-left">IP</th>
                <th className="px-3 py-2 text-left">Power</th>
                <th className="px-3 py-2 text-left">Guest OS</th>
                <th className="px-3 py-2 text-left">Reason</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr><td colSpan={8} className="px-3 py-8 text-center text-gray-400">No new VM candidates</td></tr>
              ) : filtered.map((r) => {
                const idx = candidates.indexOf(r);
                return (
                  <tr key={r.id} className="border-b border-gray-100 last:border-b-0">
                    <td className="px-3 py-2">
                      <input type="checkbox" checked={!!selected[idx]} onChange={(e) => setSelected((p) => ({ ...p, [idx]: e.target.checked }))} />
                    </td>
                    <td className="px-3 py-2">{r.source_name}</td>
                    <td className="px-3 py-2 font-medium">{r.vm_name || '—'}</td>
                    <td className="px-3 py-2">{r.os_hostname || '—'}</td>
                    <td className="px-3 py-2 font-mono text-xs text-blue-700">{r.ip_address || '—'}</td>
                    <td className="px-3 py-2">{r.power_state || '—'}</td>
                    <td className="px-3 py-2">{r.guest_os || '—'}</td>
                    <td className="px-3 py-2 text-gray-500">{r.reason || '—'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
