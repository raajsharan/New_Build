import React, { useEffect, useState, useCallback } from 'react';
import { dashboardAPI } from '../services/api';
import { useConfig } from '../context/ConfigContext';
import { Pie, Bar, Doughnut } from 'react-chartjs-2';
import {
  Chart as ChartJS, ArcElement, Tooltip, Legend,
  CategoryScale, LinearScale, BarElement, Title
} from 'chart.js';
import {
  Server, Monitor, ShieldCheck, Zap, Hand,
  CheckCircle, Power, AlertCircle, RefreshCw,
  TrendingUp, MapPin, Building2, Activity, Layers,
  Database, Globe, Cpu, HardDrive, Network, Shield, Lock,
  Cloud, Box, BarChart2, Wifi, Radio, Smartphone, Laptop,
  Package, Wrench, Settings, Tag, Users, Eye, Search,
  Star, Circle, Square, Heart, Home, Key,
  Archive, Flag, Bell, Clock, Calendar, Filter, Hash
} from 'lucide-react';

ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement, Title);

const ICON_MAP = {
  Server, Monitor, ShieldCheck, Zap, Hand, CheckCircle, Power, AlertCircle,
  Activity, Database, Layers, Globe, Cpu, HardDrive, Network, Shield, Lock,
  Cloud, Box, BarChart2, TrendingUp, Wifi, Radio, Smartphone, Laptop,
  Package, Wrench, Settings, Tag, MapPin, Building2, Users, Eye, Search,
  Star, Bolt: Zap, Circle, Square, Heart, Home, Key, Archive, Flag,
  Bell, Clock, Calendar, Filter, Hash
};

const DEFAULT_ICONS = {
  total_assets:            { icon: 'Server',       color: 'bg-blue-800' },
  vm_count:                { icon: 'Monitor',      color: 'bg-indigo-600' },
  physical_server_count:   { icon: 'Server',       color: 'bg-violet-600' },
  me_installed_count:      { icon: 'ShieldCheck',  color: 'bg-teal-600' },
  tenable_installed_count: { icon: 'ShieldCheck',  color: 'bg-cyan-600' },
  auto_patch_count:        { icon: 'Zap',          color: 'bg-green-600' },
  manual_patch_count:      { icon: 'Hand',         color: 'bg-blue-500' },
  exception_count:         { icon: 'AlertCircle',  color: 'bg-amber-500' },
  beijing_count:           { icon: 'Server',       color: 'bg-purple-600' },
  eol_no_patch_count:      { icon: 'AlertCircle',  color: 'bg-red-600' },
  onboard_pending_count:   { icon: 'Activity',     color: 'bg-sky-500' },
  on_hold_count:           { icon: 'Power',        color: 'bg-gray-500' },
  alive_servers:           { icon: 'CheckCircle',  color: 'bg-emerald-600' },
  powered_off_servers:     { icon: 'Power',        color: 'bg-orange-500' },
  not_alive_servers:       { icon: 'AlertCircle',  color: 'bg-red-700' },
  ext_total:               { icon: 'Layers',       color: 'bg-indigo-600' },
  ext_active:              { icon: 'CheckCircle',  color: 'bg-emerald-600' },
  ext_inactive:            { icon: 'Power',        color: 'bg-gray-500' },
  ext_me:                  { icon: 'ShieldCheck',  color: 'bg-teal-600' },
  ext_tenable:             { icon: 'ShieldCheck',  color: 'bg-cyan-600' },
};

function getIconCfg(key, saved) {
  const found = saved.find(c => c.key === key);
  if (found) return { icon: found.icon, color: found.color, customIconUrl: found.customIconUrl || '' };
  return { ...(DEFAULT_ICONS[key] || { icon: 'Server', color: 'bg-blue-800' }), customIconUrl: '' };
}

const StatCard = ({ label, value, statKey, iconConfig }) => {
  const cfg = getIconCfg(statKey, iconConfig);
  const Icon = ICON_MAP[cfg.icon] || Server;
  return (
    <div className="card flex items-center gap-3 p-4">
      <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 overflow-hidden ${cfg.customIconUrl ? 'bg-transparent' : cfg.color}`}>
        {cfg.customIconUrl
          ? <img src={cfg.customIconUrl} alt={label} className="w-full h-full object-contain rounded-xl" />
          : <Icon size={18} className="text-white" />}
      </div>
      <div>
        <p className="text-xl font-bold text-gray-800 leading-none">{parseInt(value) || 0}</p>
        <p className="text-xs text-gray-500 mt-0.5 leading-tight">{label}</p>
      </div>
    </div>
  );
};

const SectionHeader = ({ icon: Icon, title, subtitle }) => (
  <div className="flex items-center gap-3 mb-4">
    <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center text-blue-800">
      <Icon size={16} />
    </div>
    <div>
      <h2 className="text-base font-bold text-gray-800">{title}</h2>
      {subtitle && <p className="text-xs text-gray-400">{subtitle}</p>}
    </div>
  </div>
);

const B = ({ cls, val }) => (
  <span className={`px-1.5 py-0.5 rounded text-xs font-semibold ${cls}`}>{parseInt(val) || 0}</span>
);

const chartOpts = { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { font: { size: 10 }, padding: 10 } } } };
const barOpts   = { ...chartOpts, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } }, x: { grid: { display: false } } } };
const stackOpts = { ...barOpts, plugins: { legend: { display: true, position: 'bottom', labels: { font: { size: 10 }, padding: 8 } } }, scales: { x: { stacked: true }, y: { stacked: true, beginAtZero: true, ticks: { precision: 0 } } } };

// ── Main inventory sections ───────────────────────────────────────────────────
function DeptSection({ rows }) {
  if (!rows?.length) return null;
  const keys  = ['total','auto_count','manual_count','exception_count','beijing_count','eol_count','onboard_pending_count','on_hold_count'];
  const heads = ['Total','Auto','Manual','Exception','Beijing IT','EOL','Pending','On Hold'];
  const cls   = ['font-bold text-gray-800','bg-green-100 text-green-700','bg-blue-100 text-blue-700','bg-amber-100 text-amber-700','bg-purple-100 text-purple-700','bg-red-100 text-red-700','bg-cyan-100 text-cyan-700','bg-gray-100 text-gray-600'];
  const chartData = {
    labels: rows.map(r => r.department),
    datasets: [
      { label:'Auto',   data:rows.map(r=>parseInt(r.auto_count)||0),   backgroundColor:'#16a34a', borderRadius:4 },
      { label:'Manual', data:rows.map(r=>parseInt(r.manual_count)||0), backgroundColor:'#2563eb', borderRadius:4 },
      { label:'EOL',    data:rows.map(r=>parseInt(r.eol_count)||0),    backgroundColor:'#dc2626', borderRadius:4 },
    ]
  };
  return (
    <div className="card">
      <SectionHeader icon={Building2} title="Department-wise Endpoint Distribution" subtitle="Asset counts by department and patching type" />
      <div className="overflow-x-auto mb-5">
        <table className="w-full text-xs">
          <thead><tr className="border-b border-gray-100"><th className="text-left py-2 px-3 font-semibold text-gray-500">Department</th>{heads.map(h=><th key={h} className="text-center py-2 px-2 font-semibold text-gray-500">{h}</th>)}</tr></thead>
          <tbody>{rows.map(r=><tr key={r.department} className="border-b border-gray-50 hover:bg-gray-50"><td className="py-2 px-3 font-medium text-gray-700">{r.department}</td>{keys.map((k,i)=><td key={k} className="py-2 px-2 text-center"><B cls={cls[i]} val={r[k]}/></td>)}</tr>)}</tbody>
        </table>
      </div>
      <div className="h-52"><Bar data={chartData} options={stackOpts}/></div>
    </div>
  );
}

function ComplianceSection({ c }) {
  if (!c) return null;
  const pct = c.compliance_pct || 0;
  const ring = { labels:['Compliant','Non-Compliant'], datasets:[{data:[pct,100-pct],backgroundColor:['#16a34a','#e5e7eb'],borderWidth:0}] };
  const mini = [
    {label:'Auto (Alive)',     val:c.auto_alive,            cls:'bg-green-100 text-green-700'},
    {label:'Manual (Alive)',   val:c.manual_alive,          cls:'bg-blue-100 text-blue-700'},
    {label:'EOL - No Patches', val:c.eol_count,             cls:'bg-red-100 text-red-700'},
    {label:'Exception',        val:c.exception_count,       cls:'bg-amber-100 text-amber-700'},
    {label:'Beijing IT Team',  val:c.beijing_count,         cls:'bg-purple-100 text-purple-700'},
    {label:'Onboard Pending',  val:c.onboard_pending_count, cls:'bg-cyan-100 text-cyan-700'},
    {label:'On Hold',          val:c.on_hold_count,         cls:'bg-gray-100 text-gray-600'},
  ];
  return (
    <div className="card">
      <SectionHeader icon={TrendingUp} title="Patching Compliance" subtitle="(Auto + Manual) ÷ Alive servers" />
      <div className="flex flex-col md:flex-row gap-6">
        <div className="flex flex-col items-center w-48 flex-shrink-0">
          <div className="relative h-36 w-36">
            <Doughnut data={ring} options={{...chartOpts,cutout:'72%',plugins:{legend:{display:false}}}}/>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <p className="text-2xl font-black text-gray-800">{pct}%</p>
              <p className="text-xs text-gray-400">Compliant</p>
            </div>
          </div>
          <p className="text-xs text-gray-500 mt-1">{parseInt(c.total_alive)||0} alive servers</p>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 flex-1">
          {mini.map(m=><div key={m.label} className={`rounded-xl p-3 ${m.cls}`}><p className="text-lg font-bold leading-none">{parseInt(m.val)||0}</p><p className="text-xs mt-1 opacity-80">{m.label}</p></div>)}
        </div>
      </div>
    </div>
  );
}

function LocationSection({ rows }) {
  if (!rows?.length) return null;
  const keys  = ['total','auto_count','manual_count','eol_count','exception_count','beijing_count','onboard_pending_count','on_hold_count','alive_count'];
  const heads = ['Total','Auto','Manual','EOL','Excptn','Beijing IT','Pending','On Hold','Alive'];
  const cls   = ['font-bold text-gray-800','bg-green-100 text-green-700','bg-blue-100 text-blue-700','bg-red-100 text-red-700','bg-amber-100 text-amber-700','bg-purple-100 text-purple-700','bg-cyan-100 text-cyan-700','bg-gray-100 text-gray-600','bg-emerald-100 text-emerald-700'];
  const top5  = [...rows].sort((a,b)=>parseInt(b.total)-parseInt(a.total)).slice(0,6);
  const chartData = {
    labels: top5.map(r=>r.location),
    datasets: [
      {label:'Auto',   data:top5.map(r=>parseInt(r.auto_count)||0),   backgroundColor:'#16a34a',borderRadius:4},
      {label:'Manual', data:top5.map(r=>parseInt(r.manual_count)||0), backgroundColor:'#2563eb',borderRadius:4},
      {label:'EOL',    data:top5.map(r=>parseInt(r.eol_count)||0),    backgroundColor:'#dc2626',borderRadius:4},
      {label:'Other',  data:top5.map(r=>Math.max(0,parseInt(r.total)-(parseInt(r.auto_count)||0)-(parseInt(r.manual_count)||0)-(parseInt(r.eol_count)||0))),backgroundColor:'#9ca3af',borderRadius:4},
    ]
  };
  return (
    <div className="card">
      <SectionHeader icon={MapPin} title="Location-wise Patching Distribution" subtitle="Asset breakdown by location and patching type" />
      <div className="overflow-x-auto mb-5">
        <table className="w-full text-xs">
          <thead><tr className="border-b border-gray-100"><th className="text-left py-2 px-3 font-semibold text-gray-500">Location</th>{heads.map(h=><th key={h} className="text-center py-2 px-2 font-semibold text-gray-500">{h}</th>)}</tr></thead>
          <tbody>{rows.map(r=><tr key={r.location} className="border-b border-gray-50 hover:bg-gray-50"><td className="py-2 px-3 font-medium text-gray-700">{r.location}</td>{keys.map((k,i)=><td key={k} className="py-2 px-2 text-center"><B cls={cls[i]} val={r[k]}/></td>)}</tr>)}</tbody>
        </table>
      </div>
      <div className="h-52"><Bar data={chartData} options={stackOpts}/></div>
    </div>
  );
}

// ── Extended inventory sections ───────────────────────────────────────────────
function ExtDeptSection({ rows }) {
  if (!rows?.length) return null;
  const keys  = ['total','active_count','inactive_count','me_count','tenable_count'];
  const heads = ['Total','Active','Inactive','ME','Tenable'];
  const cls   = ['font-bold text-gray-800','bg-green-100 text-green-700','bg-gray-100 text-gray-600','bg-teal-100 text-teal-700','bg-cyan-100 text-cyan-700'];
  const chartData = {
    labels: rows.map(r=>r.department),
    datasets: [
      {label:'Active',   data:rows.map(r=>parseInt(r.active_count)||0),   backgroundColor:'#059669',borderRadius:4},
      {label:'Inactive', data:rows.map(r=>parseInt(r.inactive_count)||0), backgroundColor:'#9ca3af',borderRadius:4},
    ]
  };
  return (
    <div className="card">
      <SectionHeader icon={Building2} title="Ext. Dept-wise Endpoint Distribution" subtitle="Extended inventory assets by department" />
      <div className="overflow-x-auto mb-5">
        <table className="w-full text-xs">
          <thead><tr className="border-b border-gray-100"><th className="text-left py-2 px-3 font-semibold text-gray-500">Department</th>{heads.map(h=><th key={h} className="text-center py-2 px-2 font-semibold text-gray-500">{h}</th>)}</tr></thead>
          <tbody>{rows.map(r=><tr key={r.department} className="border-b border-gray-50 hover:bg-gray-50"><td className="py-2 px-3 font-medium text-gray-700">{r.department}</td>{keys.map((k,i)=><td key={k} className="py-2 px-2 text-center"><B cls={cls[i]} val={r[k]}/></td>)}</tr>)}</tbody>
        </table>
      </div>
      <div className="h-48"><Bar data={chartData} options={stackOpts}/></div>
    </div>
  );
}

function ExtComplianceSection({ extStats }) {
  if (!extStats) return null;
  const total  = parseInt(extStats.total) || 0;
  const active = parseInt(extStats.active) || 0;
  const pct    = total > 0 ? Math.round((active / total) * 100) : 0;
  const ring   = { labels:['Active','Other'], datasets:[{data:[active,Math.max(0,total-active)],backgroundColor:['#059669','#e5e7eb'],borderWidth:0}] };
  const mini   = [
    {label:'Active',         val:extStats.active,        cls:'bg-green-100 text-green-700'},
    {label:'Inactive',       val:extStats.inactive,      cls:'bg-gray-100 text-gray-600'},
    {label:'Decommissioned', val:extStats.decommissioned,cls:'bg-red-100 text-red-700'},
    {label:'Maintenance',    val:extStats.maintenance,   cls:'bg-amber-100 text-amber-700'},
    {label:'ME Installed',   val:extStats.me_count,      cls:'bg-teal-100 text-teal-700'},
    {label:'Tenable',        val:extStats.tenable_count, cls:'bg-cyan-100 text-cyan-700'},
  ];
  return (
    <div className="card">
      <SectionHeader icon={TrendingUp} title="Ext. Inventory Active Status" subtitle="Active vs non-active extended inventory records" />
      <div className="flex flex-col md:flex-row gap-6">
        <div className="flex flex-col items-center w-48 flex-shrink-0">
          <div className="relative h-36 w-36">
            <Doughnut data={ring} options={{...chartOpts,cutout:'72%',plugins:{legend:{display:false}}}}/>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <p className="text-2xl font-black text-gray-800">{pct}%</p>
              <p className="text-xs text-gray-400">Active</p>
            </div>
          </div>
          <p className="text-xs text-gray-500 mt-1">{total} total records</p>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 flex-1">
          {mini.map(m=><div key={m.label} className={`rounded-xl p-3 ${m.cls}`}><p className="text-lg font-bold leading-none">{parseInt(m.val)||0}</p><p className="text-xs mt-1 opacity-80">{m.label}</p></div>)}
        </div>
      </div>
    </div>
  );
}

function ExtLocationSection({ rows }) {
  if (!rows?.length) return null;
  const keys  = ['total','active_count','inactive_count','me_count','tenable_count'];
  const heads = ['Total','Active','Inactive','ME','Tenable'];
  const cls   = ['font-bold text-gray-800','bg-green-100 text-green-700','bg-gray-100 text-gray-600','bg-teal-100 text-teal-700','bg-cyan-100 text-cyan-700'];
  const top5  = [...rows].sort((a,b)=>parseInt(b.total)-parseInt(a.total)).slice(0,6);
  const chartData = {
    labels: top5.map(r=>r.location),
    datasets: [
      {label:'Active',   data:top5.map(r=>parseInt(r.active_count)||0),   backgroundColor:'#059669',borderRadius:4},
      {label:'Inactive', data:top5.map(r=>parseInt(r.inactive_count)||0), backgroundColor:'#9ca3af',borderRadius:4},
      {label:'ME',       data:top5.map(r=>parseInt(r.me_count)||0),       backgroundColor:'#0d9488',borderRadius:4},
    ]
  };
  return (
    <div className="card">
      <SectionHeader icon={MapPin} title="Ext. Location-wise Distribution" subtitle="Extended inventory assets by location" />
      <div className="overflow-x-auto mb-5">
        <table className="w-full text-xs">
          <thead><tr className="border-b border-gray-100"><th className="text-left py-2 px-3 font-semibold text-gray-500">Location</th>{heads.map(h=><th key={h} className="text-center py-2 px-2 font-semibold text-gray-500">{h}</th>)}</tr></thead>
          <tbody>{rows.map(r=><tr key={r.location} className="border-b border-gray-50 hover:bg-gray-50"><td className="py-2 px-3 font-medium text-gray-700">{r.location}</td>{keys.map((k,i)=><td key={k} className="py-2 px-2 text-center"><B cls={cls[i]} val={r[k]}/></td>)}</tr>)}</tbody>
        </table>
      </div>
      <div className="h-48"><Bar data={chartData} options={stackOpts}/></div>
    </div>
  );
}

// ── Main page ─────────────────────────────────────────────────────────────────
export default function DashboardPage() {
  const { configVersion } = useConfig();
  const [stats, setStats]           = useState(null);
  const [iconConfig, setIconConfig] = useState([]);
  const [loading, setLoading]       = useState(true);
  const [lastRefresh, setLastRefresh] = useState(new Date());

  const fetchStats = useCallback(async () => {
    setLoading(true);
    try { const r = await dashboardAPI.getStats(); setStats(r.data); setLastRefresh(new Date()); }
    catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => {
    fetch('/api/settings/dashboard-icons', { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } })
      .then(r => r.ok ? r.json() : []).then(d => setIconConfig(Array.isArray(d) ? d : [])).catch(() => {});
  }, []);

  useEffect(() => { fetchStats(); }, [fetchStats, configVersion]);
  useEffect(() => { const t = setInterval(fetchStats, 60000); return () => clearInterval(t); }, [fetchStats]);

  const ic = iconConfig;
  const mainCards = stats ? [
    {key:'total_assets',            label:'Total Assets',        value:stats.total_assets},
    {key:'vm_count',                label:'Virtual Machines',    value:stats.vm_count},
    {key:'physical_server_count',   label:'Physical Servers',    value:stats.physical_server_count},
    {key:'me_installed_count',      label:'ManageEngine',        value:stats.me_installed_count},
    {key:'tenable_installed_count', label:'Tenable',             value:stats.tenable_installed_count},
    {key:'auto_patch_count',        label:'Auto Patching',       value:stats.auto_patch_count},
    {key:'manual_patch_count',      label:'Manual Patching',     value:stats.manual_patch_count},
    {key:'exception_count',         label:'Exception',           value:stats.exception_count},
    {key:'beijing_count',           label:'Beijing IT Team',     value:stats.beijing_count},
    {key:'eol_no_patch_count',      label:'EOL - No Patches',    value:stats.eol_no_patch_count},
    {key:'onboard_pending_count',   label:'Onboard Pending',     value:stats.onboard_pending_count},
    {key:'on_hold_count',           label:'On Hold',             value:stats.on_hold_count},
    {key:'alive_servers',           label:'Alive',               value:stats.alive_servers},
    {key:'powered_off_servers',     label:'Powered Off',         value:stats.powered_off_servers},
    {key:'not_alive_servers',       label:'Not Alive',           value:stats.not_alive_servers},
  ] : [];

  const extCards = stats?.ext_stats ? [
    {key:'ext_total',   label:'Ext. Total',       value:stats.ext_stats.total},
    {key:'ext_active',  label:'Ext. Active',       value:stats.ext_stats.active},
    {key:'ext_inactive',label:'Ext. Inactive',     value:stats.ext_stats.inactive},
    {key:'ext_me',      label:'Ext. ME Installed', value:stats.ext_stats.me_count},
    {key:'ext_tenable', label:'Ext. Tenable',      value:stats.ext_stats.tenable_count},
  ] : [];

  const vmPie    = stats ? { labels:['Virtual Machines','Physical Servers'], datasets:[{data:[stats.vm_count,stats.physical_server_count],backgroundColor:['#1d4ed8','#7c3aed'],borderWidth:0}] } : null;
  const statusBar= stats ? { labels:['Alive','Powered Off','Not Alive'], datasets:[{label:'Servers',data:[stats.alive_servers,stats.powered_off_servers,stats.not_alive_servers],backgroundColor:['#059669','#f97316','#dc2626'],borderRadius:6}] } : null;
  const patchBar = stats ? { labels:['Auto','Manual','Exception','Beijing IT','EOL','Pending','On Hold'], datasets:[{label:'Count',data:[stats.auto_patch_count,stats.manual_patch_count,stats.exception_count,stats.beijing_count,stats.eol_no_patch_count,stats.onboard_pending_count,stats.on_hold_count],backgroundColor:['#16a34a','#2563eb','#d97706','#7c3aed','#dc2626','#0891b2','#9ca3af'],borderRadius:6}] } : null;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Dashboard</h1>
          <p className="text-sm text-gray-500 mt-0.5">Infrastructure inventory overview · auto-refreshes every 60 s</p>
        </div>
        <button onClick={fetchStats} disabled={loading} className="btn-secondary">
          <RefreshCw size={14} className={loading ? 'animate-spin' : ''} /> Refresh
        </button>
      </div>

      {loading && !stats ? (
        <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-5 gap-3 animate-pulse">
          {Array(20).fill(0).map((_,i)=><div key={i} className="card h-16 bg-gray-100" />)}
        </div>
      ) : (
        <>
          <div>
            <SectionHeader icon={Activity} title="Asset Inventory Summary" subtitle="Live counts across all inventory" />
            <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-3">
              {mainCards.map(c=><StatCard key={c.key} {...c} statKey={c.key} iconConfig={ic}/>)}
            </div>
          </div>

          {extCards.length > 0 && (
            <div>
              <SectionHeader icon={Layers} title="Extended Inventory Summary" subtitle="Live counts from extended inventory" />
              <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-3">
                {extCards.map(c=><StatCard key={c.key} {...c} statKey={c.key} iconConfig={ic}/>)}
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {vmPie    && <div className="card"><p className="text-sm font-semibold text-gray-700 mb-3">VM vs Physical</p><div className="h-44"><Pie data={vmPie} options={chartOpts}/></div></div>}
            {statusBar&& <div className="card"><p className="text-sm font-semibold text-gray-700 mb-3">Server Status</p><div className="h-44"><Bar data={statusBar} options={barOpts}/></div></div>}
            {patchBar && <div className="card"><p className="text-sm font-semibold text-gray-700 mb-3">Patching Categories</p><div className="h-44"><Bar data={patchBar} options={barOpts}/></div></div>}
          </div>

          <DeptSection rows={stats?.dept_stats}/>
          <ComplianceSection c={stats?.compliance}/>
          <LocationSection rows={stats?.location_stats}/>

          {stats?.ext_dept_stats?.length > 0 && (
            <>
              <div className="border-t border-indigo-100 pt-2">
                <h2 className="text-sm font-semibold text-indigo-700 uppercase tracking-wider flex items-center gap-2">
                  <Layers size={14}/> Extended Inventory Analytics
                </h2>
              </div>
              <ExtDeptSection rows={stats?.ext_dept_stats}/>
              <ExtComplianceSection extStats={stats?.ext_stats}/>
              <ExtLocationSection rows={stats?.ext_location_stats}/>
            </>
          )}

          <p className="text-xs text-gray-400 text-right pb-2">Last refreshed: {lastRefresh.toLocaleTimeString()}</p>
        </>
      )}
    </div>
  );
}
