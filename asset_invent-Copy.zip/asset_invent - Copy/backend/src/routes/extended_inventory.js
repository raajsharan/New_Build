const router  = require('express').Router();
const pool    = require('../config/database');
const extPool = require('../config/database').extPool;
const multer  = require('multer');
const { parse } = require('csv-parse/sync');
const { auth, requireWrite, requireAdmin } = require('../middleware/auth');
const { writeAuditLog } = require('../services/audit');

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });
const normalizeOemStatus = (v) => {
  const s = String(v || '').trim().toUpperCase();
  return ['YES', 'NO', 'NA'].includes(s) ? s : '';
};

// Resolve public-schema FK names into rows for enrichment
async function enrichRows(rows) {
  if (!rows.length) return rows;
  const deptIds   = [...new Set(rows.map(r => r.department_id).filter(Boolean))];
  const locIds    = [...new Set(rows.map(r => r.location_id).filter(Boolean))];
  const atIds     = [...new Set(rows.map(r => r.asset_type_id).filter(Boolean))];
  const otIds     = [...new Set(rows.map(r => r.os_type_id).filter(Boolean))];
  const ovIds     = [...new Set(rows.map(r => r.os_version_id).filter(Boolean))];
  const ssIds     = [...new Set(rows.map(r => r.server_status_id).filter(Boolean))];
  const ptIds     = [...new Set(rows.map(r => r.patching_type_id).filter(Boolean))];
  const psIds     = [...new Set(rows.map(r => r.patching_schedule_id).filter(Boolean))];
  const sptIds    = [...new Set(rows.map(r => r.server_patch_type_id).filter(Boolean))];

  const q = (t, ids) => ids.length ? pool.query(`SELECT id,name FROM ${t} WHERE id=ANY($1)`, [ids]) : { rows: [] };
  const [depts,locs,ats,ots,ovs,ss,pts,pss,spts] = await Promise.all([
    q('departments',deptIds), q('locations',locIds), q('asset_types',atIds),
    q('os_types',otIds), q('os_versions',ovIds), q('server_status',ssIds),
    q('patching_types',ptIds), q('patching_schedules',psIds), q('server_patch_types',sptIds),
  ]);
  const mk = (arr) => Object.fromEntries(arr.rows.map(r=>[r.id,r.name]));
  const dM=mk(depts),lM=mk(locs),atM=mk(ats),otM=mk(ots),ovM=mk(ovs),
        ssM=mk(ss),ptM=mk(pts),psM=mk(pss),sptM=mk(spts);

  return rows.map(r => ({
    ...r,
    department:      r.department_id    ? dM[r.department_id]    : null,
    location:        r.location_id      ? lM[r.location_id]      : null,
    asset_type:      r.asset_type_id    ? atM[r.asset_type_id]   : null,
    os_type:         r.os_type_id       ? otM[r.os_type_id]      : null,
    os_version:      r.os_version_id    ? ovM[r.os_version_id]   : null,
    server_status:   r.server_status_id ? ssM[r.server_status_id]: null,
    patching_type:   r.patching_type_id ? ptM[r.patching_type_id]: null,
    patching_schedule: r.patching_schedule_id ? psM[r.patching_schedule_id] : null,
    server_patch_type: r.server_patch_type_id ? sptM[r.server_patch_type_id]: null,
  }));
}

// GET /api/extended-inventory
router.get('/', auth, async (req, res) => {
  try {
    const { search, department, location, status, asset_type, server_status, page=1, limit=20 } = req.query;
    const conds = [], params = [];
    let i = 1;
    if (search) {
      conds.push(`(asset_name ILIKE $${i} OR ip_address ILIKE $${i} OR os_hostname ILIKE $${i} OR assigned_user ILIKE $${i})`);
      params.push(`%${search}%`); i++;
    }
    if (status) { conds.push(`status=$${i++}`); params.push(status); }
    if (department) {
      const dr = await pool.query('SELECT id FROM departments WHERE name ILIKE $1',[department]);
      if (dr.rows.length) { conds.push(`department_id=$${i++}`); params.push(dr.rows[0].id); }
    }
    if (location) {
      const lr = await pool.query('SELECT id FROM locations WHERE name ILIKE $1',[location]);
      if (lr.rows.length) { conds.push(`location_id=$${i++}`); params.push(lr.rows[0].id); }
    }
    if (asset_type) {
      const ar = await pool.query('SELECT id FROM asset_types WHERE name ILIKE $1',[asset_type]);
      if (ar.rows.length) { conds.push(`asset_type_id=$${i++}`); params.push(ar.rows[0].id); }
    }
    if (server_status) {
      const sr = await pool.query('SELECT id FROM server_status WHERE name ILIKE $1',[server_status]);
      if (sr.rows.length) { conds.push(`server_status_id=$${i++}`); params.push(sr.rows[0].id); }
    }

    const where  = conds.length ? 'WHERE '+conds.join(' AND ') : '';
    const offset = (page-1)*limit;
    const countR = await extPool.query(`SELECT COUNT(*) FROM items ${where}`, params);
    const dataR  = await extPool.query(`SELECT * FROM items ${where} ORDER BY created_at DESC LIMIT $${i} OFFSET $${i+1}`, [...params,parseInt(limit),parseInt(offset)]);
    const enriched = await enrichRows(dataR.rows);

    // Mask passwords
    const canView = req.user.role==='admin' ||
      (await pool.query('SELECT can_view_passwords FROM password_visibility_settings WHERE user_id=$1',[req.user.id])).rows[0]?.can_view_passwords;
    if (!canView) enriched.forEach(r=>{ if(r.asset_password) r.asset_password='••••••••'; });

    res.json({ items:enriched, total:parseInt(countR.rows[0].count), page:parseInt(page), limit:parseInt(limit) });
  } catch(e) { console.error(e); res.status(500).json({ error:'Server error' }); }
});

router.get('/check-duplicate', auth, async (req,res) => {
  try {
    const { ip_address, exclude_id } = req.query;
    if (!ip_address?.trim()) return res.json({ duplicate:false, errors:[] });
    const q = exclude_id
      ? await extPool.query('SELECT id,asset_name FROM items WHERE LOWER(ip_address)=LOWER($1) AND id!=$2',[ip_address.trim(),exclude_id])
      : await extPool.query('SELECT id,asset_name FROM items WHERE LOWER(ip_address)=LOWER($1)',[ip_address.trim()]);
    const errors = q.rows.length?[`IP "${ip_address}" already used by "${q.rows[0].asset_name||'ID:'+q.rows[0].id}"`]:[];
    res.json({ duplicate:errors.length>0, errors });
  } catch { res.status(500).json({ error:'Server error' }); }
});

router.get('/not-transferred', auth, async (req,res) => {
  try {
    const r = await extPool.query('SELECT * FROM items ORDER BY created_at DESC');
    res.json(await enrichRows(r.rows));
  } catch(e) { console.error(e); res.status(500).json({ error:'Server error' }); }
});

router.get('/transfer-log', auth, requireAdmin, async (req,res) => {
  try { res.json((await extPool.query('SELECT * FROM transfer_log ORDER BY transferred_at DESC LIMIT 200')).rows); }
  catch { res.status(500).json({ error:'Server error' }); }
});

// Helper to build the payload for INSERT / UPDATE
function buildPayload(body, username) {
  return [
    body.vm_name||'', body.asset_name||'', body.os_hostname||'',
    body.ip_address||null, body.asset_type||'',
    body.asset_type_id||null, body.os_type_id||null, body.os_version_id||null,
    body.department_id||null, body.assigned_user||'', body.location_id||null,
    body.business_purpose||'', body.server_status_id||null,
    body.me_installed_status||false, body.tenable_installed_status||false,
    body.patching_schedule_id||null, body.patching_type_id||null, body.server_patch_type_id||null,
    body.serial_number||'', body.idrac_enabled||false, body.idrac_ip||'',
    normalizeOemStatus(body.oem_status), body.eol_status||'InSupport', body.asset_username||'', body.asset_password||'',
    body.hosted_ip||'', body.asset_tag||'',
    body.status||'Active', body.description||'', body.additional_remarks||'',
    username, JSON.stringify(body.custom_field_values||{})
  ];
}

const INSERT_SQL = `
  INSERT INTO items (
    vm_name,asset_name,os_hostname,ip_address,asset_type,
    asset_type_id,os_type_id,os_version_id,department_id,assigned_user,location_id,
    business_purpose,server_status_id,me_installed_status,tenable_installed_status,
    patching_schedule_id,patching_type_id,server_patch_type_id,
    serial_number,idrac_enabled,idrac_ip,oem_status,eol_status,asset_username,asset_password,
    hosted_ip,asset_tag,status,description,additional_remarks,submitted_by,custom_field_values
  ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32)
  RETURNING id`;

const UPDATE_SQL = `
  UPDATE items SET
    vm_name=$1,asset_name=$2,os_hostname=$3,ip_address=$4,asset_type=$5,
    asset_type_id=$6,os_type_id=$7,os_version_id=$8,department_id=$9,assigned_user=$10,location_id=$11,
    business_purpose=$12,server_status_id=$13,me_installed_status=$14,tenable_installed_status=$15,
    patching_schedule_id=$16,patching_type_id=$17,server_patch_type_id=$18,
    serial_number=$19,idrac_enabled=$20,idrac_ip=$21,oem_status=$22,eol_status=$23,asset_username=$24,asset_password=$25,
    hosted_ip=$26,asset_tag=$27,status=$28,description=$29,additional_remarks=$30,
    submitted_by=$31,custom_field_values=$32,updated_at=NOW()
  WHERE id=$33`;

router.post('/', auth, requireWrite, async (req,res) => {
  try {
    if (req.body.ip_address?.trim()) {
      const dup = await extPool.query('SELECT id FROM items WHERE LOWER(ip_address)=LOWER($1)',[req.body.ip_address.trim()]);
      if (dup.rows.length) return res.status(409).json({ error:`IP "${req.body.ip_address}" already exists`, duplicate:true });
    }
    const r = await extPool.query(INSERT_SQL, buildPayload(req.body, req.user.username));
    const rows = await extPool.query('SELECT * FROM items WHERE id=$1',[r.rows[0].id]);
    res.status(201).json((await enrichRows(rows.rows))[0]);
  } catch(e) {
    if (e.code==='23505') return res.status(409).json({ error:'Duplicate IP', duplicate:true });
    console.error(e); res.status(500).json({ error:'Server error' });
  }
});

// GET /api/extended-inventory/report - all items for reporting
router.get('/report', auth, async (req, res) => {
  try {
    const r = await extPool.query('SELECT * FROM items ORDER BY created_at DESC');
    const enriched = await enrichRows(r.rows);
    res.json(enriched);
  } catch (e) { console.error(e); res.status(500).json({ error: 'Server error' }); }
});

// GET /api/extended-inventory/:id - single item
router.get('/:id', auth, async (req, res) => {
  try {
    const rows = await extPool.query('SELECT * FROM items WHERE id=$1', [req.params.id]);
    if (!rows.rows.length) return res.status(404).json({ error: 'Not found' });
    const enriched = await enrichRows(rows.rows);
    res.json(enriched[0]);
  } catch (e) { console.error(e); res.status(500).json({ error: 'Server error' }); }
});

router.put('/:id', auth, requireWrite, async (req,res) => {
  try {
    if (req.body.ip_address?.trim()) {
      const dup = await extPool.query('SELECT id FROM items WHERE LOWER(ip_address)=LOWER($1) AND id!=$2',[req.body.ip_address.trim(),req.params.id]);
      if (dup.rows.length) return res.status(409).json({ error:`IP "${req.body.ip_address}" already exists`, duplicate:true });
    }
    await extPool.query(UPDATE_SQL, [...buildPayload(req.body, req.user.username), req.params.id]);
    const rows = await extPool.query('SELECT * FROM items WHERE id=$1',[req.params.id]);
    res.json((await enrichRows(rows.rows))[0]);
  } catch(e) {
    if (e.code==='23505') return res.status(409).json({ error:'Duplicate IP', duplicate:true });
    res.status(500).json({ error:'Server error' });
  }
});

router.delete('/:id', auth, requireWrite, async (req,res) => {
  try { await extPool.query('DELETE FROM items WHERE id=$1',[req.params.id]); res.json({ message:'Deleted' }); }
  catch { res.status(500).json({ error:'Server error' }); }
});

// POST /:id/transfer
router.post('/:id/transfer', auth, requireAdmin, async (req,res) => {
  const client=await pool.connect(), extClient=await extPool.connect();
  try {
    const extRow = await extClient.query('SELECT * FROM items WHERE id=$1',[req.params.id]);
    if (!extRow.rows.length) return res.status(404).json({ error:'Not found' });
    const item = extRow.rows[0];
    if (item.transferred) return res.status(409).json({ error:'Already transferred' });

    const ipCheck = await client.query('SELECT id FROM assets WHERE LOWER(ip_address)=LOWER($1)',[item.ip_address]);
    if (ipCheck.rows.length) return res.status(409).json({ error:`IP "${item.ip_address}" already in main inventory` });

    await client.query('BEGIN');
    const { map_location_id, transfer_notes, map_eol_status, additional_remarks } = req.body;

    // Build the additional_remarks for the new asset: combine source item's remarks + transfer comment
    const sourceRemarks = item.additional_remarks || '';
    const transferComment = additional_remarks?.trim() || '';
    const finalRemarks = [
      sourceRemarks,
      transferComment ? `[Transfer Comment] ${transferComment}` : '',
    ].filter(Boolean).join('\n\n');

    const newAsset = await client.query(`
      INSERT INTO assets (
        vm_name,os_hostname,ip_address,asset_type_id,os_type_id,os_version_id,
        assigned_user,department_id,business_purpose,server_status_id,
        me_installed_status,tenable_installed_status,patching_schedule_id,
        patching_type_id,server_patch_type_id,location_id,additional_remarks,
        serial_number,idrac_enabled,idrac_ip,eol_status,
        asset_username,asset_password,hosted_ip,asset_tag,oem_status,
        submitted_by,created_at
      ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,NOW())
      RETURNING id`,
      [
        item.vm_name||item.asset_name, item.os_hostname||item.asset_name, item.ip_address,
        item.asset_type_id, item.os_type_id, item.os_version_id,
        item.assigned_user, item.department_id, item.business_purpose||item.description,
        item.server_status_id, item.me_installed_status, item.tenable_installed_status,
        item.patching_schedule_id, item.patching_type_id, item.server_patch_type_id,
        map_location_id||item.location_id, finalRemarks,
        item.serial_number, item.idrac_enabled, item.idrac_ip,
        map_eol_status||item.eol_status||'InSupport',
        item.asset_username, item.asset_password, item.hosted_ip, item.asset_tag, item.oem_status||'',
        req.user.username,
      ]
    );
    const mainAssetId = newAsset.rows[0].id;
    await extClient.query(
      `UPDATE items SET transferred=TRUE,transferred_at=NOW(),transferred_by=$1,main_asset_id=$2,transfer_notes=$3,updated_at=NOW() WHERE id=$4`,
      [req.user.username, mainAssetId, transfer_notes||'', req.params.id]
    );
    await extClient.query(
      `INSERT INTO transfer_log (ext_item_id,ext_asset_name,ext_ip_address,main_asset_id,transferred_by,transfer_notes) VALUES ($1,$2,$3,$4,$5,$6)`,
      [item.id,item.asset_name||item.vm_name,item.ip_address,mainAssetId,req.user.username,transfer_notes||'']
    );
    // PERMANENTLY REMOVE from extended inventory after successful transfer
    await extClient.query('DELETE FROM items WHERE id=$1', [req.params.id]);
    await client.query('COMMIT');

    try {
      await writeAuditLog({
        entityType: 'transfer',
        entityId: item.id,
        action: 'transfer',
        beforeState: item,
        afterState: {
          ext_item_id: item.id,
          main_asset_id: mainAssetId,
          transfer_notes: transfer_notes || '',
          transferred_by: req.user.username,
        },
        user: req.user,
        req,
      });

      await writeAuditLog({
        entityType: 'asset',
        entityId: mainAssetId,
        action: 'create-from-transfer',
        beforeState: null,
        afterState: {
          id: mainAssetId,
          source_ext_item_id: item.id,
          ip_address: item.ip_address,
          vm_name: item.vm_name || item.asset_name,
          submitted_by: req.user.username,
        },
        user: req.user,
        req,
      });
    } catch (auditErr) {
      console.warn('Audit log write failed (transfer):', auditErr.message);
    }

    res.json({ message:'Transferred and removed from extended inventory', main_asset_id:mainAssetId });
  } catch(e) {
    await client.query('ROLLBACK').catch(()=>{});
    console.error(e); res.status(500).json({ error:e.message||'Transfer failed' });
  } finally { client.release(); extClient.release(); }
});

// Export CSV
router.get('/export/csv', auth, async (req,res) => {
  try {
    const r = await extPool.query('SELECT * FROM items ORDER BY created_at DESC');
    const enriched = await enrichRows(r.rows);
    const esc = v => { if(!v&&v!==0)return''; const s=String(v).replace(/"/g,'""'); return s.includes(',')||s.includes('"')?`"${s}"`:s; };
    const headers = ['ID','VM Name','Asset Name','Hostname','IP','Asset Type','OS Type','OS Version',
      'User','Dept','Location','Status','Patch Type','Schedule','EOL','ME','Tenable',
      'Serial','iDRAC','iDRAC IP','Hosted IP','Asset Tag','Submitted By','Transferred','Created'];
    const rows = enriched.map(a=>[
      a.id,a.vm_name,a.asset_name,a.os_hostname,a.ip_address,
      a.asset_type,a.os_type,a.os_version,a.assigned_user,a.department,a.location,
      a.server_status,a.patching_type,a.patching_schedule,a.eol_status,
      a.me_installed_status?'Yes':'No',a.tenable_installed_status?'Yes':'No',
      a.serial_number,a.idrac_enabled?'Yes':'No',a.idrac_ip,a.hosted_ip,a.asset_tag,
      a.submitted_by,a.transferred?'Yes':'No',
      new Date(a.created_at).toISOString().split('T')[0]
    ].map(esc).join(','));
    res.setHeader('Content-Type','text/csv');
    res.setHeader('Content-Disposition',`attachment; filename="extended-inventory-${new Date().toISOString().split('T')[0]}.csv"`);
    res.send([headers.join(','),...rows].join('\n'));
  } catch { res.status(500).json({ error:'Export failed' }); }
});

router.get('/export/csv-template', auth, (req,res) => {
  const h = ['vm_name','os_hostname','ip_address','asset_type',
    'os_type','os_version',
    'assigned_user','department','business_purpose','server_status','me_installed_status',
    'tenable_installed_status','patching_schedule','patching_type','server_patch_type',
    'location','serial_number','idrac_enabled','idrac_ip','eol_status',
    'ome_status','asset_username','asset_password','hosted_ip','asset_tag','status','description','additional_remarks'];
  const ex = ['VM-01','switch-01.local','10.0.0.1','Switch',
    'Linux','Ubuntu 22.04 LTS',
    'john.doe','IT','Core switch','Alive','false','false','Monthly','Manual','Non-Critical',
    'DC1','SN123','false','','InSupport','YES','admin','pass123','','','Active','Core switch notes','Imported from CMDB'];
  res.setHeader('Content-Type','text/csv');
  res.setHeader('Content-Disposition','attachment; filename="extended_inventory_template.csv"');
  res.send(h.join(',')+'\n'+ex.join(','));
});

// CSV Import
router.post('/import/csv', auth, requireWrite, upload.single('file'), async (req,res) => {
  try {
    if (!req.file) return res.status(400).json({ error:'No file uploaded' });
    const records = parse(req.file.buffer.toString(),{columns:true,skip_empty_lines:true,trim:true});
    const results = {success:0,failed:0,skipped:0,errors:[]};
    for (let idx=0; idx<records.length; idx++) {
      const r = records[idx];
      try {
        if (r.ip_address?.trim()) {
          const dup = await extPool.query('SELECT id FROM items WHERE LOWER(ip_address)=LOWER($1)',[r.ip_address.trim()]);
          if (dup.rows.length) { results.skipped++; results.errors.push(`Row ${idx+2}: IP duplicate`); continue; }
        }
        const fk = async(t,v)=>v?(await pool.query(`SELECT id FROM ${t} WHERE name ILIKE $1`,[v])).rows[0]?.id||null:null;
        const ot = await fk('os_types',r.os_type);
        const ov = ot&&r.os_version?(await pool.query('SELECT id FROM os_versions WHERE name ILIKE $1 AND os_type_id=$2',[r.os_version,ot])).rows[0]?.id:null;
        const body = {
          vm_name:r.vm_name, asset_name:r.vm_name, os_hostname:r.os_hostname,
          ip_address:r.ip_address, asset_type:r.asset_type,
          asset_type_id:await fk('asset_types',r.asset_type), os_type_id:ot, os_version_id:ov,
          department_id:await fk('departments',r.department), assigned_user:r.assigned_user,
          location_id:await fk('locations',r.location), business_purpose:r.business_purpose,
          server_status_id:await fk('server_status',r.server_status),
          me_installed_status:r.me_installed_status==='true',
          tenable_installed_status:r.tenable_installed_status==='true',
          patching_schedule_id:await fk('patching_schedules',r.patching_schedule),
          patching_type_id:await fk('patching_types',r.patching_type),
          server_patch_type_id:await fk('server_patch_types',r.server_patch_type),
          serial_number:r.serial_number, idrac_enabled:r.idrac_enabled==='true', idrac_ip:r.idrac_ip,
          oem_status:r.ome_status ?? r.oem_status, eol_status:r.eol_status||'InSupport', asset_username:r.asset_username, asset_password:r.asset_password,
          hosted_ip:r.hosted_ip, asset_tag:r.asset_tag,
          status:r.status||'Active', description:r.description, additional_remarks:r.additional_remarks,
        };
        await extPool.query(INSERT_SQL, buildPayload(body, req.user.username));
        results.success++;
      } catch(err) { results.failed++; results.errors.push(`Row ${idx+2}: ${err.message}`); }
    }
    res.json(results);
  } catch(e) { res.status(500).json({ error:'Import failed: '+e.message }); }
});

// Custom fields CRUD (ext_inv schema)
router.get('/custom-fields/all', auth, async (req,res) => {
  try { res.json((await extPool.query('SELECT * FROM custom_fields ORDER BY field_group,sort_order,id')).rows); }
  catch { res.status(500).json({ error:'Server error' }); }
});

router.post('/custom-fields/add', auth, requireAdmin, async (req,res) => {
  try {
    const { field_label,field_key,field_type,field_options,field_group,is_active,sort_order } = req.body;
    if (!field_label||!field_key||!field_type) return res.status(400).json({ error:'label,key,type required' });
    const r = await extPool.query(
      `INSERT INTO custom_fields (field_label,field_key,field_type,field_options,field_group,is_active,sort_order) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [field_label,field_key,field_type,field_options?JSON.stringify(field_options):null,field_group||'General',is_active!==false,sort_order||0]
    );
    res.status(201).json(r.rows[0]);
  } catch(e) {
    if (e.code==='23505') return res.status(409).json({ error:'Field key exists' });
    res.status(500).json({ error:'Server error' });
  }
});

router.put('/custom-fields/:id', auth, requireAdmin, async (req,res) => {
  try {
    const { field_label,field_type,field_options,field_group,is_active,sort_order } = req.body;
    const r = await extPool.query(
      `UPDATE custom_fields SET field_label=$1,field_type=$2,field_options=$3,field_group=$4,is_active=$5,sort_order=$6,updated_at=NOW() WHERE id=$7 RETURNING *`,
      [field_label,field_type,field_options?JSON.stringify(field_options):null,field_group||'General',is_active,sort_order,req.params.id]
    );
    res.json(r.rows[0]);
  } catch { res.status(500).json({ error:'Server error' }); }
});

router.delete('/custom-fields/:id', auth, requireAdmin, async (req,res) => {
  try { await extPool.query('DELETE FROM custom_fields WHERE id=$1',[req.params.id]); res.json({ message:'Deleted' }); }
  catch { res.status(500).json({ error:'Server error' }); }
});


module.exports = router;
