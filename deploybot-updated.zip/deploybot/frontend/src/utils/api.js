// src/utils/api.js — Axios instance with JWT interceptors + error helpers

import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  headers: { 'Content-Type': 'application/json' },
  timeout: 60000,
})

// Attach JWT token to every request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('deploybot_token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

// On 401 → clear token and redirect to login
api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem('deploybot_token')
      window.location.href = '/login'
    }
    return Promise.reject(err)
  }
)

// ── Auth ──────────────────────────────────────────────────────────────────────
export const authAPI = {
  login: (username, password) =>
    api.post('/auth/login/json', { username, password }),
  me: () => api.get('/auth/me'),
  register: (data) => api.post('/auth/register', data),
}

// ── Packages ──────────────────────────────────────────────────────────────────
export const packagesAPI = {
  list: (params) => api.get('/packages', { params }),
  get: (id) => api.get(`/packages/${id}`),
  create: (data) => api.post('/packages', data),
  update: (id, data) => api.put(`/packages/${id}`, data),
  delete: (id) => api.delete(`/packages/${id}`),
}

// ── Deployments ───────────────────────────────────────────────────────────────
export const deploymentsAPI = {
  list: (limit = 50) => api.get('/deployments', { params: { limit } }),
  get: (id) => api.get(`/deployments/${id}`),
  getLogs: (id) => api.get(`/deployments/${id}/logs`),
  deployWindows: (data) => api.post('/deployments/windows', data),
  deployLinux: (data) => api.post('/deployments/linux', data),
  cancel: (id) => api.delete(`/deployments/${id}/cancel`),
}

// ── Services ──────────────────────────────────────────────────────────────────
export const servicesAPI = {
  list: (data) => api.post('/services/list', data),
  control: (data) => api.post('/services/control', data),
}

export default api

// Extract a human-readable error message from an Axios error
export const apiError = (err) =>
  err?.response?.data?.detail ||
  err?.response?.data?.message ||
  err?.message ||
  'An unexpected error occurred'
