import React, { useEffect } from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { useAuthStore } from './hooks/useAuth'
import Layout from './components/Layout'
import Login from './pages/Login'
import AddPackage from './pages/AddPackage'
import ManagePackages from './pages/ManagePackages'
import WindowsDeploy from './pages/WindowsDeploy'
import LinuxDeploy from './pages/LinuxDeploy'
import ServiceMonitor from './pages/ServiceMonitor'
import DeploymentHistory from './pages/DeploymentHistory'

function RequireAuth({ children }) {
  const { token } = useAuthStore()
  if (!token) return <Navigate to="/login" replace />
  return children
}

export default function App() {
  const { token, fetchMe } = useAuthStore()

  useEffect(() => {
    if (token) fetchMe()
  }, [])

  return (
    <BrowserRouter>
      <Toaster
        position="top-right"
        toastOptions={{
          style: {
            background: '#1a1d24',
            color: '#e2e8f0',
            border: '1px solid #252830',
            fontFamily: 'IBM Plex Sans, sans-serif',
            fontSize: '13px',
          },
          success: { iconTheme: { primary: '#10b981', secondary: '#1a1d24' } },
          error:   { iconTheme: { primary: '#ef4444', secondary: '#1a1d24' } },
        }}
      />
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/" element={<RequireAuth><Layout /></RequireAuth>}>
          <Route index element={<Navigate to="/packages/add" replace />} />
          <Route path="packages/add"    element={<AddPackage />} />
          <Route path="packages"        element={<ManagePackages />} />
          <Route path="deploy/windows"  element={<WindowsDeploy />} />
          <Route path="deploy/linux"    element={<LinuxDeploy />} />
          <Route path="services"        element={<ServiceMonitor />} />
          <Route path="history"         element={<DeploymentHistory />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  )
}
