// src/pages/WindowsDeploy.jsx

import { useState, useEffect, useRef } from 'react'
import { packagesAPI, deploymentsAPI } from '../utils/api'
import { PageHeader, Card, Input, Select, Button, Alert, Badge, LogTerminal, SectionLabel } from '../components/UI'

const C = { text: '#e8eaf0', muted: '#6b7394', border: '#1e2640', accent: '#00d4ff' }

export default function WindowsDeploy() {
  const [packages, setPackages]     = useState([])
  const [form, setForm]             = useState({ package_id: '', target_ip: '', username: '', password: '', extra_args: '' })
  const [deployment, setDeployment] = useState(null)
  const [logs, setLogs]             = useState([])
  const [loading, setLoading]       = useState(false)
  const [error, setError]           = useState(null)
  const pollRef                     = useRef(null)

  // Fetch Windows packages
  useEffect(() => {
    packagesAPI.list({ os_type: 'windows', page_size: 100 })
      .then(res => setPackages(res.data.items))
      .catch(() => {})
  }, [])

  // Poll deployment status
  const startPolling = (id) => {
    pollRef.current = setInterval(async () => {
      try {
        const [depRes, logRes] = await Promise.all([
          deploymentsAPI.get(id),
          deploymentsAPI.getLogs(id),
        ])
        setDeployment(depRes.data)
        setLogs(logRes.data)
        if (['success', 'failed', 'cancelled'].includes(depRes.data.status)) {
          clearInterval(pollRef.current)
        }
      } catch {}
    }, 2000)
  }

  useEffect(() => () => clearInterval(pollRef.current), [])

  const set = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }))

  const handleDeploy = async (e) => {
    e.preventDefault()
    if (!form.package_id) return setError('Select a package')
    if (!form.target_ip || !form.username || !form.password) return setError('All fields required')

    setLoading(true); setError(null); setDeployment(null); setLogs([])
    try {
      const res = await deploymentsAPI.deployWindows({
        package_id: Number(form.package_id),
        target_ip:  form.target_ip,
        username:   form.username,
        password:   form.password,
        extra_args: form.extra_args || undefined,
      })
      setDeployment(res.data)
      startPolling(res.data.id)
    } catch (err) {
      setError(err.response?.data?.detail || 'Deployment failed to start')
    } finally {
      setLoading(false)
    }
  }

  const selectedPkg = packages.find(p => String(p.id) === String(form.package_id))

  return (
    <div style={{ padding: 32 }}>
      <PageHeader
        icon="🪟"
        title="Windows Deployment"
        subtitle="Deploy software to Windows servers via WinRM / PowerShell"
      />

      <div style={{ display: 'grid', gridTemplateColumns: '420px 1fr', gap: 24, alignItems: 'start' }}>
        {/* ── Form ─────────────────────────────────────────────────────── */}
        <Card>
          <form onSubmit={handleDeploy} style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
            <div>
              <SectionLabel>Target Server</SectionLabel>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                <Input
                  label="Server IP / Hostname"
                  placeholder="192.168.1.100 or server.domain.com"
                  value={form.target_ip}
                  onChange={set('target_ip')}
                  required
                />
                <Input
                  label="Username"
                  placeholder="DOMAIN\Administrator or Administrator"
                  value={form.username}
                  onChange={set('username')}
                  required
                />
                <Input
                  label="Password"
                  type="password"
                  placeholder="••••••••"
                  value={form.password}
                  onChange={set('password')}
                  required
                />
              </div>
            </div>

            <div style={{ borderTop: `1px solid ${C.border}`, paddingTop: 18 }}>
              <SectionLabel>Package</SectionLabel>
              <Select
                label="Select Package"
                value={form.package_id}
                onChange={set('package_id')}
              >
                <option value="">— Choose a Windows package —</option>
                {packages.map(p => (
                  <option key={p.id} value={p.id}>{p.name}  v{p.version}</option>
                ))}
              </Select>

              {selectedPkg && (
                <div style={s.pkgPreview}>
                  <div style={{ fontSize: 12, color: C.muted, marginBottom: 4 }}>File Path</div>
                  <div style={{ fontSize: 11, fontFamily: 'Space Mono, monospace', color: C.accent, wordBreak: 'break-all' }}>
                    {selectedPkg.file_path}
                  </div>
                  {selectedPkg.description && (
                    <div style={{ fontSize: 12, color: C.muted, marginTop: 6 }}>{selectedPkg.description}</div>
                  )}
                </div>
              )}

              <div style={{ marginTop: 14 }}>
                <Input
                  label="Extra Installer Args (optional)"
                  placeholder="e.g. /LANG=en TARGETDIR=C:\App"
                  value={form.extra_args}
                  onChange={set('extra_args')}
                />
              </div>
            </div>

            {error && <Alert type="error">{error}</Alert>}

            <div style={s.infoBox}>
              <div style={{ fontSize: 11, fontWeight: 600, color: C.muted, marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Requirements</div>
              <div style={{ fontSize: 12, color: C.muted, lineHeight: 1.7 }}>
                • WinRM enabled on target (port 5985)<br />
                • NTLM authentication supported<br />
                • Target must reach file server<br />
                • Installer will run with silent flags
              </div>
            </div>

            <Button type="submit" loading={loading}>
              🚀 Deploy to Windows Server
            </Button>
          </form>
        </Card>

        {/* ── Status & Logs ─────────────────────────────────────────────── */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {deployment ? (
            <>
              <Card>
                <div style={s.statusHeader}>
                  <div>
                    <div style={{ fontSize: 13, color: C.muted, marginBottom: 4 }}>Deployment #{deployment.id}</div>
                    <div style={{ fontSize: 18, fontWeight: 700, color: C.text }}>{deployment.target_ip}</div>
                    <div style={{ fontSize: 12, color: C.muted, marginTop: 2 }}>
                      User: {deployment.target_username}
                    </div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <Badge status={deployment.status} />
                    {deployment.status === 'running' && (
                      <div style={{ fontSize: 11, color: C.accent, marginTop: 6, animation: 'pulse 1.5s infinite' }}>
                        ● Running...
                      </div>
                    )}
                  </div>
                </div>

                <div style={s.statRow}>
                  <StatItem label="Package"   value={selectedPkg?.name || `#${deployment.package_id}`} />
                  <StatItem label="Started"   value={deployment.started_at ? new Date(deployment.started_at).toLocaleTimeString() : '—'} />
                  <StatItem label="Completed" value={deployment.completed_at ? new Date(deployment.completed_at).toLocaleTimeString() : '—'} />
                </div>
              </Card>

              <Card>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: C.text }}>Deployment Logs</div>
                  <div style={{ fontSize: 11, color: C.muted }}>{logs.length} entries</div>
                </div>
                <LogTerminal logs={logs} height={360} />
              </Card>
            </>
          ) : (
            <Card style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: 200 }}>
              <div style={{ textAlign: 'center', color: C.muted }}>
                <div style={{ fontSize: 40, marginBottom: 12 }}>🪟</div>
                <div style={{ fontSize: 14 }}>Fill the form and click Deploy</div>
                <div style={{ fontSize: 12, marginTop: 4 }}>Deployment status and logs will appear here</div>
              </div>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}

function StatItem({ label, value }) {
  return (
    <div>
      <div style={{ fontSize: 11, color: '#6b7394', marginBottom: 2, textTransform: 'uppercase', letterSpacing: '0.06em' }}>{label}</div>
      <div style={{ fontSize: 13, fontFamily: 'Space Mono, monospace', color: '#e8eaf0' }}>{value}</div>
    </div>
  )
}

const s = {
  pkgPreview: {
    marginTop: 10, padding: 12,
    background: '#0a0e1a', borderRadius: 8,
    border: `1px solid #1e2640`,
  },
  infoBox: {
    background: '#0a0e1a', borderRadius: 8,
    border: `1px solid #1e2640`,
    padding: '12px 14px',
  },
  statusHeader: {
    display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start',
    marginBottom: 20,
  },
  statRow: {
    display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)',
    gap: 16, paddingTop: 16,
    borderTop: `1px solid #1e2640`,
  },
}
