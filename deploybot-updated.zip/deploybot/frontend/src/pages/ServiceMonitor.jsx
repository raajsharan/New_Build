// src/pages/ServiceMonitor.jsx

import { useState } from 'react'
import { servicesAPI } from '../utils/api'
import { PageHeader, Card, Input, Select, Button, Badge, Alert, Spinner, SectionLabel, Textarea } from '../components/UI'

const C = { text: '#e8eaf0', muted: '#6b7394', border: '#1e2640', accent: '#00d4ff', danger: '#ff4c6a', success: '#00c48c', warning: '#f59e0b' }

export default function ServiceMonitor() {
  const [authMode, setAuthMode] = useState('password')
  const [form, setForm] = useState({ server_ip: '', os_type: 'windows', username: '', password: '', ssh_key: '' })
  const [services, setServices] = useState([])
  const [meta, setMeta]         = useState(null)
  const [loading, setLoading]   = useState(false)
  const [error, setError]       = useState(null)
  const [search, setSearch]     = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [actionMsg, setActionMsg] = useState(null)
  const [actionErr, setActionErr] = useState(null)
  const [controlling, setControlling] = useState(null) // service name being controlled

  const set = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }))

  const buildPayload = () => ({
    server_ip: form.server_ip,
    os_type: form.os_type,
    username: form.username,
    ...(authMode === 'password' ? { password: form.password } : { ssh_key: form.ssh_key }),
  })

  const fetchServices = async (e) => {
    if (e) e.preventDefault()
    if (!form.server_ip || !form.username) return setError('Server IP and username are required')
    if (authMode === 'password' && !form.password) return setError('Password required')
    if (authMode === 'key' && !form.ssh_key) return setError('SSH key required')

    setLoading(true); setError(null); setActionMsg(null); setActionErr(null)
    try {
      const res = await servicesAPI.list(buildPayload())
      setServices(res.data.services)
      setMeta(res.data)
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to connect to server')
    } finally {
      setLoading(false)
    }
  }

  const controlService = async (serviceName, action) => {
    setControlling(`${serviceName}:${action}`)
    setActionMsg(null); setActionErr(null)
    try {
      const res = await servicesAPI.control({ ...buildPayload(), service_name: serviceName, action })
      setActionMsg(`✅ ${action} "${serviceName}" → ${res.data.new_status}`)
      // Refresh list
      await fetchServices()
    } catch (err) {
      setActionErr(`❌ Failed to ${action} "${serviceName}": ${err.response?.data?.detail || err.message}`)
    } finally {
      setControlling(null)
    }
  }

  // Filter services
  const filtered = services.filter(svc => {
    const matchSearch = !search ||
      svc.name.toLowerCase().includes(search.toLowerCase()) ||
      (svc.display_name || '').toLowerCase().includes(search.toLowerCase())
    const matchStatus = !statusFilter || svc.status === statusFilter
    return matchSearch && matchStatus
  })

  const running = services.filter(s => s.status === 'running').length
  const stopped = services.filter(s => s.status === 'stopped').length

  return (
    <div style={{ padding: 32 }}>
      <PageHeader
        icon="📡"
        title="Service Monitor"
        subtitle="View and control services on Windows and Linux servers"
      />

      <div style={{ display: 'grid', gridTemplateColumns: '360px 1fr', gap: 24, alignItems: 'start' }}>
        {/* ── Connection Form ───────────────────────────────────────────── */}
        <Card>
          <form onSubmit={fetchServices} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <Input label="Server IP / Hostname" placeholder="192.168.1.100" value={form.server_ip} onChange={set('server_ip')} required />

            <Select label="OS Type" value={form.os_type} onChange={set('os_type')}>
              <option value="windows">🪟 Windows</option>
              <option value="linux">🐧 Linux</option>
            </Select>

            <Input label="Username" placeholder="Administrator or root" value={form.username} onChange={set('username')} required />

            {/* Auth Toggle */}
            {form.os_type === 'linux' && (
              <div>
                <SectionLabel>Authentication</SectionLabel>
                <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
                  {['password', 'key'].map(m => (
                    <button key={m} type="button"
                      style={{ ...s.toggleBtn, ...(authMode === m ? s.toggleActive : {}) }}
                      onClick={() => setAuthMode(m)}
                    >
                      {m === 'password' ? '🔑 Password' : '🗝️ SSH Key'}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {(form.os_type === 'windows' || authMode === 'password') ? (
              <Input label="Password" type="password" placeholder="••••••••" value={form.password} onChange={set('password')} />
            ) : (
              <Textarea label="SSH Private Key (PEM)" placeholder="-----BEGIN RSA PRIVATE KEY-----" value={form.ssh_key} onChange={set('ssh_key')} style={{ minHeight: 100, fontSize: 11 }} />
            )}

            {error && <Alert type="error">{error}</Alert>}

            <Button type="submit" loading={loading}>
              {loading ? 'Connecting...' : '🔍 Fetch Services'}
            </Button>

            {meta && (
              <Button variant="ghost" type="button" onClick={fetchServices} disabled={loading}>
                🔄 Refresh
              </Button>
            )}
          </form>
        </Card>

        {/* ── Service Table ─────────────────────────────────────────────── */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {actionMsg && <Alert type="success">{actionMsg}</Alert>}
          {actionErr && <Alert type="error">{actionErr}</Alert>}

          {meta && (
            <div style={s.statsRow}>
              <StatBox value={services.length} label="Total" color={C.accent} />
              <StatBox value={running}          label="Running" color={C.success} />
              <StatBox value={stopped}          label="Stopped" color={C.muted} />
              <StatBox value={services.length - running - stopped} label="Other" color={C.warning} />
            </div>
          )}

          {services.length > 0 && (
            <div style={{ display: 'flex', gap: 10, alignItems: 'flex-end' }}>
              <Input
                label="Filter services"
                placeholder="Search by name..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                style={{ width: 260 }}
              />
              <Select label="Status" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
                <option value="">All</option>
                <option value="running">Running</option>
                <option value="stopped">Stopped</option>
                <option value="failed">Failed</option>
              </Select>
              <div style={{ fontSize: 12, color: C.muted, paddingBottom: 8 }}>
                {filtered.length} / {services.length}
              </div>
            </div>
          )}

          {loading && services.length === 0 ? (
            <Card style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: 200 }}>
              <Spinner size={36} />
            </Card>
          ) : services.length > 0 ? (
            <div style={s.tableWrap}>
              <table style={s.table}>
                <thead>
                  <tr style={s.thead}>
                    <th style={s.th}>Service Name</th>
                    <th style={s.th}>Display Name</th>
                    <th style={s.th}>Status</th>
                    <th style={s.th}>Startup</th>
                    <th style={s.th}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((svc) => {
                    const isCtrl = controlling?.startsWith(svc.name + ':')
                    return (
                      <tr key={svc.name} style={s.tr}>
                        <td style={{ ...s.td, fontFamily: 'Space Mono, monospace', fontSize: 12, color: C.accent }}>
                          {svc.name}
                        </td>
                        <td style={{ ...s.td, fontSize: 13, color: C.text }}>
                          {svc.display_name || svc.name}
                        </td>
                        <td style={s.td}>
                          <Badge status={svc.status} />
                        </td>
                        <td style={s.td}>
                          <Badge status={svc.startup_type || 'unknown'} />
                        </td>
                        <td style={s.td}>
                          <div style={{ display: 'flex', gap: 4 }}>
                            <ActionBtn
                              label="▶" title="Start"
                              color={C.success}
                              disabled={svc.status === 'running' || isCtrl}
                              loading={controlling === `${svc.name}:start`}
                              onClick={() => controlService(svc.name, 'start')}
                            />
                            <ActionBtn
                              label="■" title="Stop"
                              color={C.danger}
                              disabled={svc.status === 'stopped' || isCtrl}
                              loading={controlling === `${svc.name}:stop`}
                              onClick={() => controlService(svc.name, 'stop')}
                            />
                            <ActionBtn
                              label="↺" title="Restart"
                              color={C.warning}
                              disabled={isCtrl}
                              loading={controlling === `${svc.name}:restart`}
                              onClick={() => controlService(svc.name, 'restart')}
                            />
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          ) : !loading ? (
            <Card style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: 200 }}>
              <div style={{ textAlign: 'center', color: C.muted }}>
                <div style={{ fontSize: 40, marginBottom: 12 }}>📡</div>
                <div style={{ fontSize: 14 }}>Connect to a server to view services</div>
              </div>
            </Card>
          ) : null}
        </div>
      </div>
    </div>
  )
}

function StatBox({ value, label, color }) {
  return (
    <div style={{ background: '#111827', border: `1px solid #1e2640`, borderRadius: 10, padding: '14px 20px', textAlign: 'center', flex: 1 }}>
      <div style={{ fontSize: 24, fontWeight: 700, color, fontFamily: 'Space Mono, monospace' }}>{value}</div>
      <div style={{ fontSize: 11, color: '#6b7394', textTransform: 'uppercase', letterSpacing: '0.08em', marginTop: 2 }}>{label}</div>
    </div>
  )
}

function ActionBtn({ label, title, color, disabled, loading, onClick }) {
  return (
    <button
      title={title}
      disabled={disabled || loading}
      onClick={onClick}
      style={{
        width: 30, height: 28, borderRadius: 6,
        border: `1px solid ${disabled ? '#1e2640' : color}40`,
        background: disabled ? 'transparent' : `${color}10`,
        color: disabled ? '#3a4060' : color,
        cursor: disabled ? 'not-allowed' : 'pointer',
        fontSize: 14, fontWeight: 700,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        transition: 'all 0.15s',
      }}
    >
      {loading ? '…' : label}
    </button>
  )
}

const s = {
  toggleBtn: { flex: 1, padding: '7px 10px', borderRadius: 7, border: `1px solid #1e2640`, background: 'transparent', color: '#6b7394', cursor: 'pointer', fontSize: 12, fontFamily: "'DM Sans', sans-serif" },
  toggleActive: { background: `#00d4ff18`, borderColor: '#00d4ff', color: '#00d4ff' },
  statsRow: { display: 'flex', gap: 12 },
  tableWrap: { background: '#111827', border: `1px solid #1e2640`, borderRadius: 12, overflow: 'auto', maxHeight: 600 },
  table: { width: '100%', borderCollapse: 'collapse' },
  thead: { background: '#0d1220', position: 'sticky', top: 0 },
  th: { padding: '11px 14px', textAlign: 'left', fontSize: 11, fontWeight: 600, color: '#6b7394', textTransform: 'uppercase', letterSpacing: '0.08em', borderBottom: `1px solid #1e2640` },
  td: { padding: '10px 14px', verticalAlign: 'middle', borderBottom: `1px solid #1a2035` },
  tr: { transition: 'background 0.1s' },
}
