import React, { useState } from 'react'
import { packagesAPI, apiError } from '../utils/api'
import { Card, PageHeader, FormField, Input, Textarea, Select, Button } from '../components/UI'
import { Package, CheckCircle } from 'lucide-react'
import toast from 'react-hot-toast'

const INITIAL = { name: '', version: '', file_path: '', os_type: 'windows', description: '' }

export default function AddPackage() {
  const [form, setForm] = useState(INITIAL)
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)

  const set = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }))

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    try {
      await packagesAPI.create(form)
      toast.success(`Package "${form.name}" registered!`)
      setSuccess(true)
      setTimeout(() => { setForm(INITIAL); setSuccess(false) }, 2000)
    } catch (err) {
      toast.error(apiError(err))
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={{ maxWidth: 600 }}>
      <PageHeader title="Add Package" subtitle="Register a software package from your file server" />

      <Card>
        {success ? (
          <div style={{ textAlign: 'center', padding: '40px 0' }}>
            <CheckCircle size={48} color="var(--success)" style={{ marginBottom: 16 }} />
            <div style={{ fontSize: 16, fontWeight: 600, color: 'var(--text)' }}>Package Registered!</div>
            <div style={{ fontSize: 13, color: 'var(--muted)', marginTop: 6 }}>Redirecting...</div>
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
              <FormField label="Package Name" required>
                <Input placeholder="e.g. nginx, NodeJS, MyApp" value={form.name} onChange={set('name')} required />
              </FormField>
              <FormField label="Version" required>
                <Input placeholder="e.g. 1.24.0" value={form.version} onChange={set('version')} required />
              </FormField>
            </div>

            <FormField label="File Path on Shared Server" required hint="Full path as it appears on the file server, e.g. \\\\server\\packages\\nginx-1.24.msi or /packages/nginx.deb">
              <Input
                placeholder="\\\\192.168.1.50\\packages\\app-1.0.msi"
                value={form.file_path}
                onChange={set('file_path')}
                style={{ fontFamily: 'var(--mono)', fontSize: 12 }}
                required
              />
            </FormField>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
              <FormField label="Target OS" required>
                <Select value={form.os_type} onChange={set('os_type')}>
                  <option value="windows">🪟 Windows</option>
                  <option value="linux">🐧 Linux</option>
                </Select>
              </FormField>
            </div>

            <FormField label="Description">
              <Textarea
                placeholder="Brief description of this package and its purpose..."
                value={form.description}
                onChange={set('description')}
                rows={3}
              />
            </FormField>

            {/* Preview */}
            {form.name && (
              <div style={{
                background: 'var(--bg)', border: '1px solid var(--border)',
                borderRadius: 8, padding: 14, marginBottom: 20,
              }}>
                <div style={{ fontSize: 11, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '.08em', marginBottom: 8 }}>Preview</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <Package size={18} color={form.os_type === 'windows' ? '#60a5fa' : '#f97316'} />
                  <div>
                    <span style={{ fontWeight: 600 }}>{form.name}</span>
                    <span style={{ color: 'var(--muted)', marginLeft: 8, fontFamily: 'var(--mono)', fontSize: 12 }}>v{form.version || '?.?.?'}</span>
                    <span style={{ marginLeft: 8, fontSize: 11, color: form.os_type === 'windows' ? '#60a5fa' : '#f97316' }}>
                      [{form.os_type}]
                    </span>
                  </div>
                </div>
                {form.file_path && (
                  <div style={{ fontSize: 11, color: 'var(--muted)', marginTop: 6, fontFamily: 'var(--mono)' }}>{form.file_path}</div>
                )}
              </div>
            )}

            <div style={{ display: 'flex', gap: 10 }}>
              <Button type="submit" loading={loading} icon={Package}>Register Package</Button>
              <Button type="button" variant="secondary" onClick={() => setForm(INITIAL)}>Reset</Button>
            </div>
          </form>
        )}
      </Card>
    </div>
  )
}
