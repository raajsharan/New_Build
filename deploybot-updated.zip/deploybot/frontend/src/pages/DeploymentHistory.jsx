// src/pages/DeploymentHistory.jsx

import { useState, useEffect } from 'react'
import { deploymentsAPI } from '../utils/api'
import { PageHeader, Card, Button, Badge, Alert, Spinner, LogTerminal } from '../components/UI'

const C = { text: '#e8eaf0', muted: '#6b7394', border: '#1e2640', accent: '#00d4ff' }

export default function DeploymentHistory() {
  const [deployments, setDeployments] = useState([])
  const [loading, setLoading]         = useState(true)
  const [error, setError]             = useState(null)
  const [selectedId, setSelectedId]   = useState(null)
  const [logs, setLogs]               = useState([])
  const [logsLoading, setLogsLoading] = useState(false)

  const fetchDeployments = async () => {
    setLoading(true)
    try {
      const res = await deploymentsAPI.list(100)
      setDeployments(res.data)
    } catch {
      setError('Failed to load deployment history')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchDeployments() }, [])

  const viewLogs = async (id) => {
    if (selectedId === id) { setSelectedId(null); setLogs([]); return }
    setSelectedId(id); setLogsLoading(true)
    try {
      const res = await deploymentsAPI.getLogs(id)
      setLogs(res.data)
    } catch {
      setLogs([])
    } finally {
      setLogsLoading(false)
    }
  }

  // Stats
  const stats = {
    total:   deployments.length,
    success: deployments.filter(d => d.status === 'success').length,
    failed:  deployments.filter(d => d.status === 'failed').length,
    running: deployments.filter(d => d.status === 'running').length,
  }

  return (
    <div style={{ padding: 32 }}>
      <PageHeader
        icon="📋"
        title="Deployment History"
        subtitle="All past and active deployments"
        actions={
          <Button variant="ghost" onClick={fetchDeployments} loading={loading}>🔄 Refresh</Button>
        }
      />

      {/* Stats */}
      <div style={{ display: 'flex', gap: 12, marginBottom: 24 }}>
        {[
          { v: stats.total,   l: 'Total',   c: C.accent },
          { v: stats.success, l: 'Success',  c: '#00c48c' },
          { v: stats.failed,  l: 'Failed',   c: '#ff4c6a' },
          { v: stats.running, l: 'Active',   c: '#f59e0b' },
        ].map(({ v, l, c }) => (
          <div key={l} style={{ ...s.statCard }}>
            <div style={{ fontSize: 26, fontWeight: 700, color: c, fontFamily: 'Space Mono, monospace' }}>{v}</div>
            <div style={{ fontSize: 11, color: C.muted, textTransform: 'uppercase', letterSpacing: '0.08em' }}>{l}</div>
          </div>
        ))}
      </div>

      {error   && <Alert type="error">{error}</Alert>}
      {loading && <div style={{ display: 'flex', justifyContent: 'center', padding: 40 }}><Spinner size={36} /></div>}

      {!loading && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: 12 }}>
          {deployments.length === 0 ? (
            <Card style={{ textAlign: 'center', color: C.muted, padding: 48 }}>
              <div style={{ fontSize: 36, marginBottom: 12 }}>📋</div>
              <div>No deployments yet</div>
            </Card>
          ) : (
            deployments.map((dep) => (
              <div key={dep.id}>
                <Card style={{ cursor: 'pointer' }} onClick={() => viewLogs(dep.id)}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                    {/* OS Icon */}
                    <div style={s.osIcon}>{dep.os_type === 'windows' ? '🪟' : '🐧'}</div>

                    {/* Main Info */}
                    <div style={{ flex: 1 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
                        <span style={{ fontWeight: 600, color: C.text }}>{dep.target_ip}</span>
                        <span style={{ fontSize: 12, color: C.muted }}>as {dep.target_username}</span>
                        <Badge status={dep.os_type} />
                      </div>
                      <div style={{ fontSize: 12, color: C.muted }}>
                        Package #{dep.package_id} &nbsp;·&nbsp;
                        {dep.started_at
                          ? `Started ${new Date(dep.started_at).toLocaleString()}`
                          : `Created ${new Date(dep.created_at).toLocaleString()}`}
                        {dep.completed_at && (
                          <> &nbsp;·&nbsp; Finished {new Date(dep.completed_at).toLocaleString()}</>
                        )}
                      </div>
                    </div>

                    {/* Status + Expand */}
                    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                      <Badge status={dep.status} />
                      <span style={{ fontSize: 11, color: C.muted }}>#{dep.id}</span>
                      <span style={{ color: C.muted, fontSize: 14, transition: 'transform 0.15s', transform: selectedId === dep.id ? 'rotate(90deg)' : 'none' }}>▶</span>
                    </div>
                  </div>
                </Card>

                {/* Expanded Logs */}
                {selectedId === dep.id && (
                  <div style={{ ...s.logsPanel }}>
                    {logsLoading
                      ? <div style={{ display: 'flex', justifyContent: 'center', padding: 20 }}><Spinner /></div>
                      : <LogTerminal logs={logs} height={260} />
                    }
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      )}
    </div>
  )
}

const s = {
  statCard: {
    background: '#111827', border: `1px solid #1e2640`,
    borderRadius: 10, padding: '16px 22px',
    minWidth: 100,
  },
  osIcon: {
    width: 42, height: 42, borderRadius: 10,
    background: '#0d1220', border: `1px solid #1e2640`,
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontSize: 20, flexShrink: 0,
  },
  logsPanel: {
    background: '#050810',
    border: `1px solid #1e2640`,
    borderTop: 'none',
    borderRadius: '0 0 12px 12px',
    padding: 16,
    marginTop: -8,
  },
}
