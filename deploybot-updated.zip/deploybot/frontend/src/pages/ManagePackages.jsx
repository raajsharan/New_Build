import React, { useEffect, useState, useCallback } from 'react'
import { packagesAPI, apiError } from '../utils/api'
import { PageHeader, Badge, Button, Input, Select, EmptyState } from '../components/UI'
import { PackageOpen, Search, Edit2, Trash2, RefreshCw, Plus, X, Check } from 'lucide-react'
import toast from 'react-hot-toast'
import { useNavigate } from 'react-router-dom'

export default function ManagePackages() {
  const [packages, setPackages] = useState([])
  const [total, setTotal]       = useState(0)
  const [loading, setLoading]   = useState(true)
  const [search, setSearch]     = useState('')
  const [osFilter, setOsFilter] = useState('')
  const [page, setPage]         = useState(1)
  const [editId, setEditId]     = useState(null)
  const [editForm, setEditForm] = useState({})
  const navigate = useNavigate()
  const PAGE_SIZE = 15

  const fetchPackages = useCallback(async () => {
    setLoading(true)
    try {
      const res = await packagesAPI.list({ search, os_type: osFilter, page, page_size: PAGE_SIZE })
      setPackages(res.data.items)
      setTotal(res.data.total)
    } catch (err) {
      toast.error(apiError(err))
    } finally { setLoading(false) }
  }, [search, osFilter, page])

  useEffect(() => { fetchPackages() }, [fetchPackages])
  useEffect(() => { setPage(1) }, [search, osFilter])

  const handleDelete = async (pkg) => {
    if (!confirm(`Delete "${pkg.name} v${pkg.version}"?`)) return
    try {
      await packagesAPI.delete(pkg.id)
      toast.success('Package deleted')
      fetchPackages()
    } catch (err) { toast.error(apiError(err)) }
  }

  const startEdit = (pkg) => {
    setEditId(pkg.id)
    setEditForm({ name: pkg.name, version: pkg.version, file_path: pkg.file_path, os_type: pkg.os_type, description: pkg.description || '' })
  }

  const saveEdit = async () => {
    try {
      await packagesAPI.update(editId, editForm)
      toast.success('Package updated')
      setEditId(null)
      fetchPackages()
    } catch (err) { toast.error(apiError(err)) }
  }

  const totalPages = Math.ceil(total / PAGE_SIZE)

  return (
    <div>
      <PageHeader
        title="Package Registry"
        subtitle={`${total} package${total !== 1 ? 's' : ''} registered`}
        action={
          <div style={{ display: 'flex', gap: 8 }}>
            <Button variant="secondary" icon={RefreshCw} onClick={fetchPackages}>Refresh</Button>
            <Button icon={Plus} onClick={() => navigate('/packages/add')}>Add Package</Button>
          </div>
        }
      />

      {/* Filters */}
      <div style={{ display: 'flex', gap: 10, marginBottom: 16 }}>
        <div style={{ position: 'relative', flex: 1, maxWidth: 340 }}>
          <Search size={13} color="var(--muted)" style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)' }} />
          <Input
            placeholder="Search packages..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            style={{ paddingLeft: 30 }}
          />
        </div>
        <div style={{ width: 160 }}>
          <Select value={osFilter} onChange={e => setOsFilter(e.target.value)}>
            <option value="">All OS Types</option>
            <option value="windows">🪟 Windows</option>
            <option value="linux">🐧 Linux</option>
          </Select>
        </div>
        {(search || osFilter) && (
          <Button variant="ghost" icon={X} onClick={() => { setSearch(''); setOsFilter('') }}>Clear</Button>
        )}
      </div>

      {/* Table */}
      <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 12, overflow: 'hidden' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ borderBottom: '1px solid var(--border)' }}>
              {['Package', 'Version', 'OS', 'File Path', 'Added', 'Actions'].map(h => (
                <th key={h} style={{ padding: '10px 16px', textAlign: 'left', fontSize: 11, fontWeight: 600, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '.06em', whiteSpace: 'nowrap' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {loading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <tr key={i}><td colSpan={6} style={{ padding: '12px 16px' }}><div className="skeleton" style={{ height: 20, width: '100%' }} /></td></tr>
              ))
            ) : packages.length === 0 ? (
              <tr><td colSpan={6}><EmptyState icon={PackageOpen} title="No packages found" subtitle="Add your first package to get started" /></td></tr>
            ) : packages.map(pkg => (
              <tr key={pkg.id} style={{ borderBottom: '1px solid var(--border)', transition: 'background .1s' }}
                  onMouseEnter={e => e.currentTarget.style.background = 'var(--surface2)'}
                  onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
                <td style={{ padding: '10px 16px' }}>
                  {editId === pkg.id ? (
                    <Input value={editForm.name} onChange={e => setEditForm(f => ({ ...f, name: e.target.value }))} style={{ width: 140 }} />
                  ) : (
                    <span style={{ fontWeight: 600, color: 'var(--text)' }}>{pkg.name}</span>
                  )}
                </td>
                <td style={{ padding: '10px 16px', fontFamily: 'var(--mono)', fontSize: 12, color: 'var(--muted)' }}>
                  {editId === pkg.id ? (
                    <Input value={editForm.version} onChange={e => setEditForm(f => ({ ...f, version: e.target.value }))} style={{ width: 90 }} />
                  ) : `v${pkg.version}`}
                </td>
                <td style={{ padding: '10px 16px' }}>
                  <Badge status={pkg.os_type}>{pkg.os_type}</Badge>
                </td>
                <td style={{ padding: '10px 16px', maxWidth: 240 }}>
                  {editId === pkg.id ? (
                    <Input value={editForm.file_path} onChange={e => setEditForm(f => ({ ...f, file_path: e.target.value }))} style={{ fontFamily: 'var(--mono)', fontSize: 11, width: '100%' }} />
                  ) : (
                    <span style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', display: 'block' }} title={pkg.file_path}>{pkg.file_path}</span>
                  )}
                </td>
                <td style={{ padding: '10px 16px', fontSize: 12, color: 'var(--muted)', whiteSpace: 'nowrap' }}>
                  {new Date(pkg.created_at).toLocaleDateString()}
                </td>
                <td style={{ padding: '10px 16px' }}>
                  {editId === pkg.id ? (
                    <div style={{ display: 'flex', gap: 6 }}>
                      <Button variant="success" style={{ padding: '5px 10px' }} onClick={saveEdit} icon={Check}>Save</Button>
                      <Button variant="secondary" style={{ padding: '5px 10px' }} onClick={() => setEditId(null)} icon={X}>Cancel</Button>
                    </div>
                  ) : (
                    <div style={{ display: 'flex', gap: 6 }}>
                      <Button variant="ghost" style={{ padding: '5px 8px' }} onClick={() => startEdit(pkg)} icon={Edit2} />
                      <Button variant="danger" style={{ padding: '5px 8px' }} onClick={() => handleDelete(pkg)} icon={Trash2} />
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div style={{ display: 'flex', justifyContent: 'center', gap: 6, marginTop: 16 }}>
          {Array.from({ length: totalPages }, (_, i) => i + 1).map(p => (
            <button key={p} onClick={() => setPage(p)} style={{
              width: 32, height: 32, borderRadius: 6, border: '1px solid var(--border)',
              background: p === page ? 'var(--accent)' : 'var(--surface)',
              color: p === page ? '#000' : 'var(--muted)',
              fontWeight: p === page ? 700 : 400,
              cursor: 'pointer', fontSize: 12,
            }}>{p}</button>
          ))}
        </div>
      )}
    </div>
  )
}
