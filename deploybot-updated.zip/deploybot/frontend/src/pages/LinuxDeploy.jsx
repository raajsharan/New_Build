// src/pages/LinuxDeploy.jsx

import { useState, useEffect, useRef } from 'react'
import { packagesAPI, deploymentsAPI } from '../utils/api'
import { PageHeader, Card, Input, Select, Button, Alert, Badge, LogTerminal, SectionLabel, Textarea } from '../components/UI'

const C = { text: '#e8eaf0', muted: '#6b7394', border: '#1e2640', accent: '#00d4ff' }

export default function LinuxDeploy() {
  const [packages,   setPackages]   = useState([])
  const [authMode,   setAuthMode]   = useState('password') // 'password' | 'key'
  const [form, setForm]             = useState({
    package_id: '', target_ip: '', username: 'root',
    password: '', ssh_key: '',
    package_manager: '', use_sudo: true,
  })
  const [deployment, setDeployment] = useState(null)
  const [logs, setLogs]             = useState([])
  const [loading, setLoading]       = useState(false)
  const [error, setError]           = useState(null)
  const pollRef                     = useRef(null)

  useEffect(() => {
    packagesAPI.list({ os_type: 'linux', page_size: 100 })
      .then(res => setPackages(res.data.items))
      .catch(() => {})
  }, [])

  const startPolling = (id) => {
    pollRef.current = setInterval(async () => {
      try {
        const [depRes, logRes] = await Promise.all([
          deploymentsAPI.get(id),
          deploymentsAPI.getLogs(id),
        ])
        setDeployment(depRes.data)
        setLogs(logRes.data)
        if (['success', 'failed', 'cancelled'].includes(depRes.data.status)) {
          clearInterval(pollRef.current)
        }
      } catch {}
    }, 2000)
  }

  useEffect(() => () => clearInterval(pollRef.current), [])

  const set = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }))

  const handleDeploy = async (e) => {
    e.preventDefault()
    if (!form.package_id) return setError('Select a package')
    if (!form.target_ip || !form.username) return setError('Server IP and username are required')
    if (authMode === 'password' && !form.password) return setError('Password is required')
    if (authMode === 'key' && !form.ssh_key) return setError('SSH private key is required')

    setLoading(true); setError(null); setDeployment(null); setLogs([])
    try {
      const payload = {
        package_id: Number(form.package_id),
        target_ip:  form.target_ip,
        username:   form.username,
        use_sudo:   form.use_sudo,
        package_manager: form.package_manager || undefined,
        ...(authMode === 'password' ? { password: form.password } : { ssh_key: form.ssh_key }),
      }
      const res = await deploymentsAPI.deployLinux(payload)
      setDeployment(res.data)
      startPolling(res.data.id)
    } catch (err) {
      setError(err.response?.data?.detail || 'Deployment failed to start')
    } finally {
      setLoading(false)
    }
  }

  const selectedPkg = packages.find(p => String(p.id) === String(form.package_id))

  return (
    <div style={{ padding: 32 }}>
      <PageHeader
        icon="🐧"
        title="Linux Deployment"
        subtitle="Deploy packages to Linux servers via SSH / SCP"
      />

      <div style={{ display: 'grid', gridTemplateColumns: '440px 1fr', gap: 24, alignItems: 'start' }}>
        {/* ── Form ─────────────────────────────────────────────────────── */}
        <Card>
          <form onSubmit={handleDeploy} style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
            {/* Target */}
            <div>
              <SectionLabel>Target Server</SectionLabel>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                <Input label="Server IP / Hostname" placeholder="192.168.1.50" value={form.target_ip} onChange={set('target_ip')} required />
                <Input label="Username" placeholder="root or deploy_user" value={form.username} onChange={set('username')} required />
              </div>
            </div>

            {/* Auth Mode Toggle */}
            <div style={{ borderTop: `1px solid ${C.border}`, paddingTop: 18 }}>
              <SectionLabel>Authentication</SectionLabel>
              <div style={s.toggle}>
                {['password', 'key'].map(m => (
                  <button
                    key={m} type="button"
                    style={{ ...s.toggleBtn, ...(authMode === m ? s.toggleActive : {}) }}
                    onClick={() => setAuthMode(m)}
                  >
                    {m === 'password' ? '🔑 Password' : '🗝️ SSH Key'}
                  </button>
                ))}
              </div>

              {authMode === 'password' ? (
                <Input label="Password" type="password" placeholder="••••••••" value={form.password} onChange={set('password')} />
              ) : (
                <Textarea
                  label="SSH Private Key (PEM)"
                  placeholder="-----BEGIN RSA PRIVATE KEY-----&#10;...&#10;-----END RSA PRIVATE KEY-----"
                  value={form.ssh_key}
                  onChange={set('ssh_key')}
                  style={{ minHeight: 120, fontSize: 11 }}
                />
              )}
            </div>

            {/* Package */}
            <div style={{ borderTop: `1px solid ${C.border}`, paddingTop: 18 }}>
              <SectionLabel>Package</SectionLabel>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                <Select label="Select Package" value={form.package_id} onChange={set('package_id')}>
                  <option value="">— Choose a Linux package —</option>
                  {packages.map(p => (
                    <option key={p.id} value={p.id}>{p.name}  v{p.version}</option>
                  ))}
                </Select>

                {selectedPkg && (
                  <div style={s.pkgPreview}>
                    <div style={{ fontSize: 11, fontFamily: 'Space Mono, monospace', color: C.accent, wordBreak: 'break-all' }}>
                      {selectedPkg.file_path}
                    </div>
                  </div>
                )}

                <Select label="Package Manager (leave blank to auto-detect)" value={form.package_manager} onChange={set('package_manager')}>
                  <option value="">Auto-detect</option>
                  <option value="apt-get">apt-get (Debian/Ubuntu)</option>
                  <option value="dnf">dnf (Fedora/RHEL 8+)</option>
                  <option value="yum">yum (CentOS/RHEL 7)</option>
                  <option value="zypper">zypper (openSUSE)</option>
                  <option value="rpm">rpm (direct RPM install)</option>
                  <option value="dpkg">dpkg (direct DEB install)</option>
                </Select>

                <div style={s.checkRow}>
                  <input
                    type="checkbox" id="usesudo"
                    checked={form.use_sudo}
                    onChange={(e) => setForm(f => ({ ...f, use_sudo: e.target.checked }))}
                  />
                  <label htmlFor="usesudo" style={{ fontSize: 13, color: C.muted, cursor: 'pointer' }}>
                    Use sudo for installation
                  </label>
                </div>
              </div>
            </div>

            {error && <Alert type="error">{error}</Alert>}

            <div style={s.infoBox}>
              <div style={{ fontSize: 11, fontWeight: 600, color: C.muted, marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Requirements</div>
              <div style={{ fontSize: 12, color: C.muted, lineHeight: 1.7 }}>
                • SSH port 22 open on target<br/>
                • sshpass + scp available on target<br/>
                • Target must reach file server<br/>
                • sudo available if not running as root
              </div>
            </div>

            <Button type="submit" loading={loading}>
              🚀 Deploy to Linux Server
            </Button>
          </form>
        </Card>

        {/* ── Status & Logs ─────────────────────────────────────────────── */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {deployment ? (
            <>
              <Card>
                <div style={s.statusHeader}>
                  <div>
                    <div style={{ fontSize: 13, color: C.muted, marginBottom: 4 }}>Deployment #{deployment.id}</div>
                    <div style={{ fontSize: 18, fontWeight: 700, color: C.text }}>{deployment.target_ip}</div>
                    <div style={{ fontSize: 12, color: C.muted, marginTop: 2 }}>User: {deployment.target_username}</div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <Badge status={deployment.status} />
                    {deployment.status === 'running' && (
                      <div style={{ fontSize: 11, color: C.accent, marginTop: 6 }}>● Running...</div>
                    )}
                  </div>
                </div>
                <div style={s.statRow}>
                  <StatItem label="Package"   value={selectedPkg?.name || `#${deployment.package_id}`} />
                  <StatItem label="Started"   value={deployment.started_at ? new Date(deployment.started_at).toLocaleTimeString() : '—'} />
                  <StatItem label="Completed" value={deployment.completed_at ? new Date(deployment.completed_at).toLocaleTimeString() : '—'} />
                </div>
              </Card>

              <Card>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: C.text }}>Deployment Logs</div>
                  <div style={{ fontSize: 11, color: C.muted }}>{logs.length} entries</div>
                </div>
                <LogTerminal logs={logs} height={360} />
              </Card>
            </>
          ) : (
            <Card style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: 200 }}>
              <div style={{ textAlign: 'center', color: C.muted }}>
                <div style={{ fontSize: 40, marginBottom: 12 }}>🐧</div>
                <div style={{ fontSize: 14 }}>Fill the form and click Deploy</div>
                <div style={{ fontSize: 12, marginTop: 4 }}>Deployment status and logs will appear here</div>
              </div>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}

function StatItem({ label, value }) {
  return (
    <div>
      <div style={{ fontSize: 11, color: '#6b7394', marginBottom: 2, textTransform: 'uppercase', letterSpacing: '0.06em' }}>{label}</div>
      <div style={{ fontSize: 13, fontFamily: 'Space Mono, monospace', color: '#e8eaf0' }}>{value}</div>
    </div>
  )
}

const s = {
  toggle: { display: 'flex', gap: 8, marginBottom: 14 },
  toggleBtn: {
    flex: 1, padding: '8px 12px', borderRadius: 8,
    border: `1px solid #1e2640`, background: 'transparent',
    color: '#6b7394', cursor: 'pointer', fontSize: 13, fontWeight: 500,
    fontFamily: "'DM Sans', sans-serif",
  },
  toggleActive: { background: `#00d4ff18`, borderColor: '#00d4ff', color: '#00d4ff' },
  pkgPreview: { padding: 10, background: '#0a0e1a', borderRadius: 8, border: `1px solid #1e2640` },
  checkRow: { display: 'flex', alignItems: 'center', gap: 8 },
  infoBox: { background: '#0a0e1a', borderRadius: 8, border: `1px solid #1e2640`, padding: '12px 14px' },
  statusHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 },
  statRow: { display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, paddingTop: 16, borderTop: `1px solid #1e2640` },
}
