// Shared UI primitives — dark industrial theme
import React from 'react'
import { Loader2 } from 'lucide-react'

const S = {
  card: {
    background: 'var(--surface)',
    border: '1px solid var(--border)',
    borderRadius: 12,
    padding: 24,
  },
  label: {
    display: 'block',
    fontSize: 11,
    fontWeight: 600,
    color: 'var(--muted)',
    textTransform: 'uppercase',
    letterSpacing: '.08em',
    marginBottom: 6,
  },
  input: {
    width: '100%',
    background: 'var(--bg)',
    border: '1px solid var(--border)',
    borderRadius: 7,
    padding: '9px 12px',
    color: 'var(--text)',
    fontSize: 13,
    fontFamily: 'var(--sans)',
    transition: 'border-color .15s',
  },
  select: {
    width: '100%',
    background: 'var(--bg)',
    border: '1px solid var(--border)',
    borderRadius: 7,
    padding: '9px 12px',
    color: 'var(--text)',
    fontSize: 13,
    fontFamily: 'var(--sans)',
    appearance: 'none',
    cursor: 'pointer',
  },
}

export function Card({ children, style, title, subtitle }) {
  return (
    <div style={{ ...S.card, ...style }}>
      {title && (
        <div style={{ marginBottom: subtitle ? 4 : 20 }}>
          <h2 style={{ fontSize: 16, fontWeight: 700, color: 'var(--text)' }}>{title}</h2>
          {subtitle && <p style={{ fontSize: 12, color: 'var(--muted)', marginTop: 3 }}>{subtitle}</p>}
        </div>
      )}
      {children}
    </div>
  )
}

export function PageHeader({ title, subtitle, action }) {
  return (
    <div style={{ marginBottom: 24, display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
      <div>
        <h1 style={{ fontSize: 22, fontWeight: 700, color: 'var(--text)', letterSpacing: '-.02em' }}>{title}</h1>
        {subtitle && <p style={{ fontSize: 13, color: 'var(--muted)', marginTop: 4 }}>{subtitle}</p>}
      </div>
      {action}
    </div>
  )
}

export function FormField({ label, hint, children, required }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <label style={S.label}>
        {label}{required && <span style={{ color: 'var(--danger)' }}> *</span>}
      </label>
      {children}
      {hint && <p style={{ fontSize: 11, color: 'var(--muted)', marginTop: 5 }}>{hint}</p>}
    </div>
  )
}

export function Input({ style, ...props }) {
  return <input style={{ ...S.input, ...style }} {...props} />
}

export function Textarea({ style, ...props }) {
  return <textarea style={{ ...S.input, resize: 'vertical', minHeight: 80, ...style }} {...props} />
}

export function Select({ style, children, ...props }) {
  return (
    <div style={{ position: 'relative' }}>
      <select style={{ ...S.select, ...style }} {...props}>{children}</select>
      <span style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--muted)', pointerEvents: 'none' }}>▾</span>
    </div>
  )
}

export function Button({ children, variant = 'primary', loading, style, icon: Icon, ...props }) {
  const variants = {
    primary: { background: 'var(--accent)', color: '#000', border: 'none' },
    secondary: { background: 'transparent', color: 'var(--text)', border: '1px solid var(--border)' },
    danger: { background: 'rgba(239,68,68,.12)', color: 'var(--danger)', border: '1px solid rgba(239,68,68,.25)' },
    success: { background: 'rgba(16,185,129,.12)', color: 'var(--success)', border: '1px solid rgba(16,185,129,.25)' },
    ghost: { background: 'transparent', color: 'var(--muted)', border: 'none' },
  }
  return (
    <button
      disabled={loading || props.disabled}
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 7,
        padding: '9px 16px', borderRadius: 7,
        fontSize: 13, fontWeight: 600, fontFamily: 'var(--sans)',
        cursor: loading || props.disabled ? 'not-allowed' : 'pointer',
        opacity: loading || props.disabled ? .6 : 1,
        transition: 'opacity .15s, filter .15s',
        ...variants[variant],
        ...style,
      }}
      {...props}
    >
      {loading ? <Loader2 size={14} style={{ animation: 'spin 1s linear infinite' }} /> : Icon ? <Icon size={14} /> : null}
      {children}
    </button>
  )
}

export function Badge({ status, children }) {
  return (
    <span className={`badge-${status}`} style={{
      display: 'inline-flex', alignItems: 'center', gap: 5,
      padding: '3px 9px', borderRadius: 20,
      fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.06em',
    }}>
      <span style={{ width: 5, height: 5, borderRadius: '50%', background: 'currentColor' }}
            className={status === 'running' ? 'pulse-dot' : ''} />
      {children}
    </span>
  )
}

export function Spinner({ size = 20 }) {
  return <Loader2 size={size} color="var(--accent)" style={{ animation: 'spin 1s linear infinite' }} />
}

export function Divider({ label }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '20px 0' }}>
      <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
      {label && <span style={{ fontSize: 11, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '.08em' }}>{label}</span>}
      <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
    </div>
  )
}

export function StatusDot({ status }) {
  const colors = { running: 'var(--success)', stopped: 'var(--muted)', failed: 'var(--danger)', starting: 'var(--warning)' }
  return (
    <span style={{
      display: 'inline-block', width: 7, height: 7,
      borderRadius: '50%', background: colors[status] || 'var(--muted)',
    }} className={status === 'running' ? 'pulse-dot' : ''} />
  )
}

export function EmptyState({ icon: Icon, title, subtitle }) {
  return (
    <div style={{ textAlign: 'center', padding: '60px 20px', color: 'var(--muted)' }}>
      {Icon && <Icon size={40} style={{ opacity: .3, marginBottom: 16 }} />}
      <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 6, color: 'var(--text)', opacity: .5 }}>{title}</div>
      {subtitle && <div style={{ fontSize: 13 }}>{subtitle}</div>}
    </div>
  )
}

export function Grid({ cols = 2, gap = 16, children, style }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: `repeat(${cols}, 1fr)`, gap, ...style }}>
      {children}
    </div>
  )
}

// Stat card for dashboard metrics
export function StatCard({ label, value, icon: Icon, color = 'var(--accent)' }) {
  return (
    <div style={{
      background: 'var(--surface)', border: '1px solid var(--border)',
      borderRadius: 10, padding: '16px 20px',
      display: 'flex', alignItems: 'center', gap: 14,
    }}>
      <div style={{
        width: 40, height: 40, borderRadius: 10,
        background: `rgba(${color === 'var(--accent)' ? '0,212,255' : color === 'var(--success)' ? '16,185,129' : '239,68,68'},.12)`,
        display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
      }}>
        <Icon size={18} color={color} />
      </div>
      <div>
        <div style={{ fontSize: 22, fontWeight: 700, fontFamily: 'var(--mono)', color: 'var(--text)' }}>{value}</div>
        <div style={{ fontSize: 11, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '.06em' }}>{label}</div>
      </div>
    </div>
  )
}

// ── Alert banner ─────────────────────────────────────────────────────────────
export function Alert({ type = 'info', children, style }) {
  const variants = {
    info:    { color: 'var(--accent)',   bg: 'rgba(0,212,255,.08)',    border: 'rgba(0,212,255,.2)' },
    success: { color: 'var(--success)',  bg: 'rgba(16,185,129,.08)',   border: 'rgba(16,185,129,.2)' },
    warning: { color: 'var(--warning)',  bg: 'rgba(245,158,11,.08)',   border: 'rgba(245,158,11,.2)' },
    error:   { color: 'var(--danger)',   bg: 'rgba(239,68,68,.08)',    border: 'rgba(239,68,68,.2)' },
  }
  const v = variants[type] || variants.info
  return (
    <div style={{
      padding: '10px 14px', borderRadius: 8,
      fontSize: 13, color: v.color,
      background: v.bg,
      border: `1px solid ${v.border}`,
      ...style,
    }}>
      {children}
    </div>
  )
}

// ── Section label (sub-heading inside a card) ─────────────────────────────────
export function SectionLabel({ children, style }) {
  return (
    <div style={{
      fontSize: 10, fontWeight: 700,
      color: 'var(--muted)',
      textTransform: 'uppercase',
      letterSpacing: '.1em',
      marginBottom: 12,
      paddingBottom: 8,
      borderBottom: '1px solid var(--border)',
      ...style,
    }}>
      {children}
    </div>
  )
}

// ── Log terminal — scrollable ANSI-style output box ───────────────────────────
export function LogTerminal({ logs = [], style }) {
  const bottomRef = React.useRef(null)

  React.useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [logs.length])

  const levelColor = (level = '') => {
    switch (level.toUpperCase()) {
      case 'ERROR':   return '#ef4444'
      case 'WARNING': return '#f59e0b'
      case 'SUCCESS': return '#10b981'
      default:        return '#64748b'
    }
  }

  return (
    <div className="log-terminal" style={{ ...style }}>
      {logs.length === 0 ? (
        <span style={{ color: 'var(--muted)' }}>Waiting for output...</span>
      ) : (
        logs.map((log, i) => {
          const entry = typeof log === 'string' ? { message: log, level: 'INFO' } : log
          return (
            <div key={i} style={{ marginBottom: 2 }}>
              <span style={{ color: '#374151', marginRight: 8, userSelect: 'none' }}>
                {entry.timestamp
                  ? new Date(entry.timestamp).toLocaleTimeString()
                  : ''}
              </span>
              <span style={{ color: levelColor(entry.level), marginRight: 8, fontWeight: 700 }}>
                [{(entry.level || 'INFO').toUpperCase().padEnd(7)}]
              </span>
              <span style={{ color: 'var(--text)' }}>{entry.message}</span>
            </div>
          )
        })
      )}
      <div ref={bottomRef} />
    </div>
  )
}
