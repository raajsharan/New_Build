import React, { useState } from 'react'
import { Outlet, NavLink, useNavigate } from 'react-router-dom'
import {
  Package, PackageOpen, Monitor, Terminal,
  Activity, History, LogOut, ChevronLeft, ChevronRight,
  Cpu, ShieldCheck
} from 'lucide-react'
import { useAuthStore } from '../hooks/useAuth'
import toast from 'react-hot-toast'

const NAV = [
  { label: 'Add Package',      to: '/packages/add',   icon: Package },
  { label: 'Manage Packages',  to: '/packages',        icon: PackageOpen },
  { divider: true },
  { label: 'Windows Deploy',   to: '/deploy/windows',  icon: Monitor },
  { label: 'Linux Deploy',     to: '/deploy/linux',    icon: Terminal },
  { divider: true },
  { label: 'Service Monitor',  to: '/services',        icon: Activity },
  { label: 'Deploy History',   to: '/history',         icon: History },
]

export default function Layout() {
  const [collapsed, setCollapsed] = useState(false)
  const { user, logout } = useAuthStore()
  const navigate = useNavigate()

  const handleLogout = () => {
    logout()
    toast.success('Logged out')
    navigate('/login')
  }

  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden' }}>
      {/* Sidebar */}
      <aside style={{
        width: collapsed ? 64 : 240,
        transition: 'width .2s ease',
        background: 'var(--surface)',
        borderRight: '1px solid var(--border)',
        display: 'flex',
        flexDirection: 'column',
        flexShrink: 0,
        overflow: 'hidden',
      }}>
        {/* Logo */}
        <div style={{
          padding: collapsed ? '20px 0' : '20px 18px',
          display: 'flex',
          alignItems: 'center',
          gap: 10,
          borderBottom: '1px solid var(--border)',
          height: 64,
          justifyContent: collapsed ? 'center' : 'flex-start',
        }}>
          <div style={{
            width: 32, height: 32, borderRadius: 8,
            background: 'linear-gradient(135deg, var(--accent), var(--accent2))',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            flexShrink: 0,
          }}>
            <Cpu size={16} color="#fff" />
          </div>
          {!collapsed && (
            <div>
              <div style={{ fontFamily: 'var(--mono)', fontWeight: 700, fontSize: 14, color: 'var(--accent)', letterSpacing: 1 }}>DEPLOYBOT</div>
              <div style={{ fontSize: 10, color: 'var(--muted)', marginTop: -2 }}>v1.0.0</div>
            </div>
          )}
        </div>

        {/* Nav items */}
        <nav style={{ flex: 1, overflowY: 'auto', padding: '8px 0' }}>
          {NAV.map((item, i) =>
            item.divider ? (
              <div key={i} style={{ height: 1, background: 'var(--border)', margin: '8px 12px' }} />
            ) : (
              <NavLink
                key={item.to}
                to={item.to}
                title={collapsed ? item.label : ''}
                style={({ isActive }) => ({
                  display: 'flex',
                  alignItems: 'center',
                  gap: 10,
                  padding: collapsed ? '10px 0' : '9px 16px',
                  justifyContent: collapsed ? 'center' : 'flex-start',
                  margin: '1px 8px',
                  borderRadius: 7,
                  textDecoration: 'none',
                  fontSize: 13,
                  fontWeight: 500,
                  color: isActive ? 'var(--accent)' : 'var(--muted)',
                  background: isActive ? 'rgba(0,212,255,.08)' : 'transparent',
                  transition: 'all .15s',
                })}
              >
                <item.icon size={16} style={{ flexShrink: 0 }} />
                {!collapsed && item.label}
              </NavLink>
            )
          )}
        </nav>

        {/* User + collapse */}
        <div style={{ borderTop: '1px solid var(--border)' }}>
          {!collapsed && user && (
            <div style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{
                width: 28, height: 28, borderRadius: '50%',
                background: 'linear-gradient(135deg,var(--accent2),var(--accent))',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 11, fontWeight: 700, color: '#fff', flexShrink: 0,
              }}>
                {user.username[0].toUpperCase()}
              </div>
              <div style={{ minWidth: 0 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{user.username}</div>
                {user.is_superuser && (
                  <div style={{ fontSize: 10, color: 'var(--accent)', display: 'flex', alignItems: 'center', gap: 3 }}>
                    <ShieldCheck size={10} /> Admin
                  </div>
                )}
              </div>
            </div>
          )}
          <button
            onClick={handleLogout}
            style={{
              width: '100%', padding: collapsed ? '12px 0' : '10px 16px',
              display: 'flex', alignItems: 'center', gap: 8,
              justifyContent: collapsed ? 'center' : 'flex-start',
              background: 'none', border: 'none', cursor: 'pointer',
              color: 'var(--muted)', fontSize: 13, fontWeight: 500,
              transition: 'color .15s',
            }}
            onMouseEnter={e => e.currentTarget.style.color = 'var(--danger)'}
            onMouseLeave={e => e.currentTarget.style.color = 'var(--muted)'}
          >
            <LogOut size={15} />
            {!collapsed && 'Logout'}
          </button>
          <button
            onClick={() => setCollapsed(c => !c)}
            style={{
              width: '100%', padding: '10px 0',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              background: 'none', border: 'none', cursor: 'pointer',
              color: 'var(--border)', transition: 'color .15s',
              borderTop: '1px solid var(--border)',
            }}
            onMouseEnter={e => e.currentTarget.style.color = 'var(--muted)'}
            onMouseLeave={e => e.currentTarget.style.color = 'var(--border)'}
          >
            {collapsed ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main style={{ flex: 1, overflow: 'auto', display: 'flex', flexDirection: 'column' }}>
        <div style={{ flex: 1, padding: 28 }} className="fade-in">
          <Outlet />
        </div>
      </main>
    </div>
  )
}
