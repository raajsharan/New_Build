// src/hooks/useAuth.js — Zustand auth store
import { create } from 'zustand'
import { authAPI } from '../utils/api'

export const useAuthStore = create((set) => ({
  user: null,
  token: localStorage.getItem('deploybot_token'),
  loading: false,

  login: async (username, password) => {
    set({ loading: true })
    try {
      const res = await authAPI.login(username, password)
      const token = res.data.access_token
      localStorage.setItem('deploybot_token', token)
      const me = await authAPI.me()
      set({ token, user: me.data, loading: false })
      return { ok: true }
    } catch (err) {
      set({ loading: false })
      return { ok: false, error: err?.response?.data?.detail || 'Login failed' }
    }
  },

  logout: () => {
    localStorage.removeItem('deploybot_token')
    set({ user: null, token: null })
  },

  fetchMe: async () => {
    try {
      const res = await authAPI.me()
      set({ user: res.data })
    } catch {
      localStorage.removeItem('deploybot_token')
      set({ user: null, token: null })
    }
  },
}))
