#!/usr/bin/env bash
# =============================================================================
# deploy.sh — Copy updated DeployBot files to /opt/deploybot and restart
# Run from the directory containing this script:  sudo bash deploy.sh
# =============================================================================
set -e

APP_DIR="/opt/deploybot"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "==> Copying backend files..."
cp -r "$SCRIPT_DIR/backend/"* "$APP_DIR/backend/"
chown -R deploybot:deploybot "$APP_DIR/backend"

echo "==> Installing Python dependencies..."
sudo -u deploybot "$APP_DIR/backend/venv/bin/pip" install -r "$APP_DIR/backend/requirements.txt" -q

echo "==> Building frontend..."
cp -r "$SCRIPT_DIR/frontend/"* "$APP_DIR/frontend/"
chown -R deploybot:deploybot "$APP_DIR/frontend"
cd "$APP_DIR/frontend"
sudo -u deploybot npm install --silent
sudo -u deploybot npm run build

echo "==> Restarting services..."
systemctl restart deploybot-api deploybot-worker
systemctl reload nginx

echo ""
echo "✅ DeployBot updated successfully!"
echo "   API health: $(curl -s http://localhost:8000/api/health)"
