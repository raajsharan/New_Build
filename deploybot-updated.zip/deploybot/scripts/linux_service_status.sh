#!/usr/bin/env bash
# =============================================================================
# linux_service_status.sh - Fetch and control Linux systemd services
# Usage: ./linux_service_status.sh --action list
#        ./linux_service_status.sh --action start   --service nginx
#        ./linux_service_status.sh --action stop    --service nginx
#        ./linux_service_status.sh --action restart --service nginx
#        ./linux_service_status.sh --action status  --service nginx
# =============================================================================

set -euo pipefail

ACTION="list"
SERVICE_NAME=""
FILTER=""
JSON_OUTPUT="true"
USE_SUDO="false"

while [[ $# -gt 0 ]]; do
    case "$1" in
        --action)  ACTION="$2";       shift 2 ;;
        --service) SERVICE_NAME="$2"; shift 2 ;;
        --filter)  FILTER="$2";       shift 2 ;;
        --no-json) JSON_OUTPUT="false"; shift  ;;
        --sudo)    USE_SUDO="true";   shift   ;;
        *) echo "Unknown arg: $1" >&2; exit 1 ;;
    esac
done

SUDO_CMD=""
[[ "$USE_SUDO" == "true" ]] && SUDO_CMD="sudo"

# ── Helpers ───────────────────────────────────────────────────────────────────

ts() { date -u '+%Y-%m-%dT%H:%M:%SZ'; }

json_escape() {
    # Minimal JSON string escape
    printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g; s/$/\\n/g' | tr -d '\n' | sed 's/\\n$//'
}

emit_error() {
    local msg="$1"
    echo "{\"success\":false,\"action\":\"$ACTION\",\"error\":\"$(json_escape "$msg")\"}"
    exit 1
}


# ── LIST ALL SERVICES ─────────────────────────────────────────────────────────

list_services() {
    # Build enabled/startup map from list-unit-files
    declare -A STARTUP_MAP
    while IFS= read -r line; do
        svc=$(echo "$line" | awk '{print $1}' | sed 's/\.service$//')
        state=$(echo "$line" | awk '{print $2}')
        STARTUP_MAP["$svc"]="$state"
    done < <(systemctl list-unit-files --type=service --no-pager --no-legend 2>/dev/null || true)

    # Build status map from list-units
    declare -A STATUS_MAP
    declare -A DESC_MAP
    while IFS= read -r line; do
        svc=$(echo "$line" | awk '{print $1}' | sed 's/\.service$//')
        sub=$(echo "$line" | awk '{print $4}')   # running/dead/exited/failed
        desc=$(echo "$line" | awk '{$1=$2=$3=$4=""; print $0}' | sed 's/^ *//')
        STATUS_MAP["$svc"]="$sub"
        DESC_MAP["$svc"]="$desc"
    done < <(systemctl list-units --type=service --all --no-pager --no-legend 2>/dev/null || true)

    # Merge and emit JSON
    echo "["
    local first=1
    local services_seen=()

    # Iterate through all known services (union of both sets)
    for svc in "${!STARTUP_MAP[@]}" "${!STATUS_MAP[@]}"; do
        # Deduplicate
        if [[ " ${services_seen[*]} " == *" $svc "* ]]; then
            continue
        fi
        services_seen+=("$svc")

        # Apply filter
        if [[ -n "$FILTER" ]] && [[ "$svc" != *"$FILTER"* ]]; then
            continue
        fi

        status="${STATUS_MAP[$svc]:-unknown}"
        # Map systemd sub-states to friendly names
        case "$status" in
            running)   status="running"  ;;
            dead|inactive) status="stopped" ;;
            failed)    status="failed"   ;;
            exited)    status="stopped"  ;;
            *)         status="unknown"  ;;
        esac

        startup="${STARTUP_MAP[$svc]:-unknown}"
        desc="${DESC_MAP[$svc]:-}"

        [[ $first -eq 0 ]] && echo ","
        first=0

        printf '  {"name":"%s","display_name":"%s","status":"%s","startup_type":"%s","description":"%s"}' \
            "$(json_escape "$svc")" \
            "$(json_escape "$svc")" \
            "$(json_escape "$status")" \
            "$(json_escape "$startup")" \
            "$(json_escape "$desc")"
    done

    echo ""
    echo "]"
}


if [[ "$ACTION" == "list" ]]; then
    SERVICES_JSON=$(list_services)
    COUNT=$(echo "$SERVICES_JSON" | grep -c '"name"' || echo 0)

    if [[ "$JSON_OUTPUT" == "true" ]]; then
        cat <<EOF
{
  "success": true,
  "action": "list",
  "hostname": "$(hostname)",
  "service_count": $COUNT,
  "fetched_at": "$(ts)",
  "services": $SERVICES_JSON
}
EOF
    else
        # Pretty table output
        echo "SERVICE STATUS ON $(hostname) — $(date)"
        echo "────────────────────────────────────────────────────────"
        printf "%-40s %-12s %-12s\n" "SERVICE NAME" "STATUS" "STARTUP"
        echo "────────────────────────────────────────────────────────"

        while IFS= read -r svc; do
            [[ -z "$svc" ]] && continue
            name=$(systemctl list-units --type=service --all --no-pager --no-legend 2>/dev/null | grep "^$svc" | awk '{print $1}' | head -1 || echo "$svc")
            active=$(systemctl is-active "$svc" 2>/dev/null || echo "unknown")
            enabled=$(systemctl is-enabled "$svc" 2>/dev/null || echo "unknown")
            printf "%-40s %-12s %-12s\n" "$svc" "$active" "$enabled"
        done < <(systemctl list-unit-files --type=service --no-pager --no-legend 2>/dev/null | awk '{print $1}' | sed 's/\.service$//')
    fi

    exit 0
fi


# ── SERVICE CONTROL ───────────────────────────────────────────────────────────

[[ -z "$SERVICE_NAME" ]] && emit_error "--service is required for action: $ACTION"

# Validate action
[[ "$ACTION" =~ ^(start|stop|restart|status)$ ]] || emit_error "Invalid action: $ACTION"

# Get current status before action
prev_status=$($SUDO_CMD systemctl is-active "${SERVICE_NAME}.service" 2>/dev/null || echo "unknown")

if [[ "$ACTION" != "status" ]]; then
    # Execute the control command
    if ! $SUDO_CMD systemctl "$ACTION" "${SERVICE_NAME}.service" 2>&1; then
        emit_error "systemctl $ACTION $SERVICE_NAME failed"
    fi
    sleep 1
fi

# Get new status
new_status=$($SUDO_CMD systemctl is-active "${SERVICE_NAME}.service" 2>/dev/null || echo "unknown")

# Get startup type
startup_type=$($SUDO_CMD systemctl is-enabled "${SERVICE_NAME}.service" 2>/dev/null || echo "unknown")

# Get description
description=$(systemctl show "${SERVICE_NAME}.service" --property=Description --value 2>/dev/null || echo "")

if [[ "$JSON_OUTPUT" == "true" ]]; then
    cat <<EOF
{
  "success": true,
  "action": "$ACTION",
  "service_name": "$(json_escape "$SERVICE_NAME")",
  "hostname": "$(hostname)",
  "prev_status": "$(json_escape "$prev_status")",
  "new_status": "$(json_escape "$new_status")",
  "startup_type": "$(json_escape "$startup_type")",
  "description": "$(json_escape "$description")",
  "message": "Action '$ACTION' completed successfully",
  "timestamp": "$(ts)"
}
EOF
else
    echo "[$ACTION] $SERVICE_NAME : $prev_status -> $new_status"
fi

exit 0
