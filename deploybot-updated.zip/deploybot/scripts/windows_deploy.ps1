# =============================================================================
# windows_deploy.ps1 - Silent software deployment script for Windows
# Usage: .\windows_deploy.ps1 -PackagePath "\\fileserver\share\app.msi" `
#                              -ShareUser "svc_deploy" -SharePass "pass" `
#                              -ExtraArgs "/LANG=en"
# =============================================================================

[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string]$PackagePath,       # UNC path: \\server\share\package.msi or .exe

    [Parameter(Mandatory=$false)]
    [string]$ShareUser = "",    # Domain\Username for file share auth

    [Parameter(Mandatory=$false)]
    [string]$SharePass = "",    # File share password

    [Parameter(Mandatory=$false)]
    [string]$ExtraArgs = "",    # Additional installer arguments

    [Parameter(Mandatory=$false)]
    [string]$LogFile = "C:\Temp\deploy_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"
)

# ── Setup ──────────────────────────────────────────────────────────────────────

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

if (!(Test-Path "C:\Temp")) {
    New-Item -ItemType Directory -Path "C:\Temp" | Out-Null
}

function Write-Log {
    param([string]$Level = "INFO", [string]$Message)
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "[$ts] [$Level] $Message"
    Write-Output $line
    Add-Content -Path $LogFile -Value $line
}

Write-Log "INFO" "===================================================="
Write-Log "INFO" " DeployBot Windows Deployment Script"
Write-Log "INFO" "===================================================="
Write-Log "INFO" "Package  : $PackagePath"
Write-Log "INFO" "Log file : $LogFile"


# ── Step 1: Map Network Share (if credentials provided) ───────────────────────

$TempDrive = $null
if ($ShareUser -and $SharePass) {
    Write-Log "INFO" "Mapping network share..."
    $ShareDir = Split-Path -Parent $PackagePath

    # Remove any existing TempShare drive
    if (Get-PSDrive -Name TempShare -ErrorAction SilentlyContinue) {
        Remove-PSDrive -Name TempShare -Force
    }

    $SecurePass = ConvertTo-SecureString $SharePass -AsPlainText -Force
    $Cred = New-Object System.Management.Automation.PSCredential($ShareUser, $SecurePass)

    try {
        New-PSDrive -Name TempShare -PSProvider FileSystem -Root $ShareDir `
            -Credential $Cred -ErrorAction Stop | Out-Null
        $TempDrive = "TempShare"
        Write-Log "INFO" "Share mapped successfully: $ShareDir"
    } catch {
        Write-Log "WARNING" "Could not map share ($($_.Exception.Message)) — trying direct UNC path"
    }
}


# ── Step 2: Copy Package Locally ───────────────────────────────────────────────

$FileName = Split-Path -Leaf $PackagePath
$LocalPath = "C:\Temp\$FileName"

Write-Log "INFO" "Copying package to local temp: $LocalPath"
try {
    if ($TempDrive) {
        Copy-Item -Path "TempShare:\$FileName" -Destination $LocalPath -Force
    } else {
        Copy-Item -Path $PackagePath -Destination $LocalPath -Force
    }
    Write-Log "INFO" "Package copied successfully ($('{0:N2}' -f ((Get-Item $LocalPath).Length / 1MB)) MB)"
} catch {
    Write-Log "ERROR" "Failed to copy package: $($_.Exception.Message)"
    exit 1
} finally {
    if ($TempDrive -and (Get-PSDrive -Name TempShare -ErrorAction SilentlyContinue)) {
        Remove-PSDrive -Name TempShare -Force
    }
}


# ── Step 3: Detect Installer Type and Install ──────────────────────────────────

$Extension = [System.IO.Path]::GetExtension($LocalPath).ToLower()
Write-Log "INFO" "Installer type detected: $Extension"

function Invoke-Installer {
    param([string]$FilePath, [string]$Arguments)

    Write-Log "INFO" "Running: $FilePath $Arguments"
    $proc = Start-Process -FilePath $FilePath -ArgumentList $Arguments `
        -Wait -PassThru -NoNewWindow
    return $proc.ExitCode
}

$ExitCode = 0

switch ($Extension) {
    ".msi" {
        $Args = "/i `"$LocalPath`" /quiet /norestart /l*v `"$LogFile.msi.log`" $ExtraArgs"
        $ExitCode = Invoke-Installer "msiexec.exe" $Args
    }
    ".exe" {
        # Common silent flags — adjust per installer (NSIS, InnoSetup, InstallShield)
        $SilentArgs = "/S /silent /quiet /norestart $ExtraArgs"
        $ExitCode = Invoke-Installer $LocalPath $SilentArgs
    }
    ".ps1" {
        Write-Log "INFO" "Executing PowerShell installer script..."
        & powershell.exe -ExecutionPolicy Bypass -File $LocalPath $ExtraArgs
        $ExitCode = $LASTEXITCODE
    }
    default {
        Write-Log "ERROR" "Unsupported installer type: $Extension"
        exit 1
    }
}


# ── Step 4: Interpret Exit Code ────────────────────────────────────────────────

Write-Log "INFO" "Installer exited with code: $ExitCode"

switch ($ExitCode) {
    0    { Write-Log "INFO" "✅ Installation completed successfully" }
    3010 { Write-Log "INFO" "✅ Installation succeeded — reboot required (code 3010)" }
    1602 { Write-Log "ERROR" "❌ Installation cancelled by user (code 1602)"; exit 1 }
    1603 { Write-Log "ERROR" "❌ Fatal error during installation (code 1603)"; exit 1 }
    1618 { Write-Log "ERROR" "❌ Another install is in progress (code 1618)"; exit 1 }
    default {
        if ($ExitCode -ne 0) {
            Write-Log "ERROR" "❌ Installation failed with unexpected exit code: $ExitCode"
            exit $ExitCode
        }
    }
}


# ── Step 5: Cleanup ────────────────────────────────────────────────────────────

Write-Log "INFO" "Cleaning up temporary files..."
Remove-Item -Path $LocalPath -Force -ErrorAction SilentlyContinue
Write-Log "INFO" "🎉 Windows deployment script completed. Log: $LogFile"
exit 0
