#!/usr/bin/env bash
# =============================================================================
# linux_deploy.sh - Silent software deployment script for Linux
# Usage: sudo ./linux_deploy.sh --package /path/to/package.deb \
#                                --source-host 192.168.1.10 \
#                                --source-user svc_deploy \
#                                --source-pass "password"
# =============================================================================

set -euo pipefail

# ── Defaults ──────────────────────────────────────────────────────────────────
PACKAGE_PATH=""
SOURCE_HOST=""
SOURCE_USER=""
SOURCE_PASS=""
PKG_MGR=""          # Auto-detect if empty
TEMP_DIR="/tmp/deploybot"
LOG_FILE="/var/log/deploybot/deploy_$(date +%Y%m%d_%H%M%S).log"
USE_SUDO="true"

# ── Colours ───────────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; NC='\033[0m'

# ── Logging ───────────────────────────────────────────────────────────────────
mkdir -p "$(dirname "$LOG_FILE")" "$TEMP_DIR"

log() {
    local level="$1"; shift
    local msg="$*"
    local ts
    ts=$(date '+%Y-%m-%d %H:%M:%S')
    local line="[$ts] [$level] $msg"
    echo -e "$line" | tee -a "$LOG_FILE"
}

info()    { log "INFO   " "${CYAN}$*${NC}"; }
success() { log "SUCCESS" "${GREEN}$*${NC}"; }
warning() { log "WARNING" "${YELLOW}$*${NC}"; }
error()   { log "ERROR  " "${RED}$*${NC}"; }
die()     { error "$*"; exit 1; }

# ── Argument Parsing ──────────────────────────────────────────────────────────
while [[ $# -gt 0 ]]; do
    case "$1" in
        --package)       PACKAGE_PATH="$2"; shift 2 ;;
        --source-host)   SOURCE_HOST="$2";  shift 2 ;;
        --source-user)   SOURCE_USER="$2";  shift 2 ;;
        --source-pass)   SOURCE_PASS="$2";  shift 2 ;;
        --pkg-mgr)       PKG_MGR="$2";      shift 2 ;;
        --no-sudo)       USE_SUDO="false";  shift   ;;
        *) die "Unknown argument: $1" ;;
    esac
done

[[ -z "$PACKAGE_PATH" ]] && die "--package is required"

SUDO=""
[[ "$USE_SUDO" == "true" ]] && SUDO="sudo"

info "===================================================="
info " DeployBot Linux Deployment Script"
info "===================================================="
info "Package  : $PACKAGE_PATH"
info "Log file : $LOG_FILE"


# ── Step 1: Detect Package Manager ───────────────────────────────────────────

detect_pkg_mgr() {
    if   command -v apt-get &>/dev/null; then echo "apt-get"
    elif command -v dnf     &>/dev/null; then echo "dnf"
    elif command -v yum     &>/dev/null; then echo "yum"
    elif command -v zypper  &>/dev/null; then echo "zypper"
    elif command -v pacman  &>/dev/null; then echo "pacman"
    else echo "unknown"
    fi
}

if [[ -z "$PKG_MGR" ]]; then
    PKG_MGR=$(detect_pkg_mgr)
fi
info "Package manager: $PKG_MGR"


# ── Step 2: Fetch Package from File Server ────────────────────────────────────

FILE_NAME=$(basename "$PACKAGE_PATH")
LOCAL_PATH="$TEMP_DIR/$FILE_NAME"

if [[ -n "$SOURCE_HOST" && -n "$SOURCE_USER" ]]; then
    info "Fetching package via SCP from $SOURCE_HOST..."

    if command -v sshpass &>/dev/null && [[ -n "$SOURCE_PASS" ]]; then
        # SCP with password
        SSHPASS="$SOURCE_PASS" sshpass -e scp \
            -o StrictHostKeyChecking=no \
            -o ConnectTimeout=30 \
            "${SOURCE_USER}@${SOURCE_HOST}:${PACKAGE_PATH}" \
            "$LOCAL_PATH" || die "SCP failed"
    else
        # SSH key auth (key must be in agent or ~/.ssh/)
        scp -o StrictHostKeyChecking=no -o ConnectTimeout=30 \
            "${SOURCE_USER}@${SOURCE_HOST}:${PACKAGE_PATH}" \
            "$LOCAL_PATH" || die "SCP failed"
    fi
    success "Package downloaded to $LOCAL_PATH"

elif [[ -f "$PACKAGE_PATH" ]]; then
    # Local path — just symlink or use directly
    cp "$PACKAGE_PATH" "$LOCAL_PATH"
    success "Package copied from local path"

else
    die "Package not found: $PACKAGE_PATH (provide --source-host if on remote)"
fi

# Verify the file exists and is non-empty
[[ -s "$LOCAL_PATH" ]] || die "Downloaded file is empty or missing: $LOCAL_PATH"
info "Package size: $(du -sh "$LOCAL_PATH" | cut -f1)"


# ── Step 3: Install Package ───────────────────────────────────────────────────

EXT="${FILE_NAME##*.}"
info "Installing package (.$EXT) with $PKG_MGR..."

install_deb() {
    info "Installing .deb package..."
    $SUDO DEBIAN_FRONTEND=noninteractive dpkg -i "$LOCAL_PATH" 2>&1 | tee -a "$LOG_FILE" || {
        warning "dpkg reported errors — attempting apt-get -f install to fix dependencies..."
        $SUDO DEBIAN_FRONTEND=noninteractive apt-get install -f -y 2>&1 | tee -a "$LOG_FILE"
    }
}

install_rpm() {
    info "Installing .rpm package..."
    case "$PKG_MGR" in
        dnf) $SUDO dnf install -y "$LOCAL_PATH" 2>&1 | tee -a "$LOG_FILE" ;;
        yum) $SUDO yum install -y "$LOCAL_PATH" 2>&1 | tee -a "$LOG_FILE" ;;
        *)   $SUDO rpm -Uvh --nodeps "$LOCAL_PATH" 2>&1 | tee -a "$LOG_FILE" ;;
    esac
}

install_tarball() {
    info "Extracting tarball..."
    EXTRACT_DIR="$TEMP_DIR/extracted"
    mkdir -p "$EXTRACT_DIR"
    tar -xzf "$LOCAL_PATH" -C "$EXTRACT_DIR" 2>&1 | tee -a "$LOG_FILE"

    if [[ -f "$EXTRACT_DIR/install.sh" ]]; then
        info "Running bundled install.sh..."
        chmod +x "$EXTRACT_DIR/install.sh"
        $SUDO bash "$EXTRACT_DIR/install.sh" 2>&1 | tee -a "$LOG_FILE"
    else
        warning "No install.sh found — archive extracted to $EXTRACT_DIR"
    fi
}

case "$EXT" in
    deb)        install_deb ;;
    rpm)        install_rpm ;;
    tar|gz|tgz) install_tarball ;;
    sh|bin)
        info "Running shell installer..."
        chmod +x "$LOCAL_PATH"
        $SUDO bash "$LOCAL_PATH" --silent --quiet 2>&1 | tee -a "$LOG_FILE"
        ;;
    *)
        die "Unsupported package format: .$EXT"
        ;;
esac


# ── Step 4: Verify Installation ───────────────────────────────────────────────

EXIT_CODE=${PIPESTATUS[0]:-0}
if [[ $EXIT_CODE -eq 0 ]]; then
    success "✅ Package installed successfully!"
else
    die "❌ Installation failed with exit code $EXIT_CODE"
fi


# ── Step 5: Cleanup ───────────────────────────────────────────────────────────

info "Cleaning up temporary files..."
rm -f "$LOCAL_PATH"
rm -rf "$TEMP_DIR/extracted" 2>/dev/null || true

success "🎉 Linux deployment completed! Log: $LOG_FILE"
exit 0
