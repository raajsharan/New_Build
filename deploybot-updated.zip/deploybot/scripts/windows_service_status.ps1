# =============================================================================
# windows_service_status.ps1 - Fetch and control Windows services
# Usage: .\windows_service_status.ps1 -Action list
#        .\windows_service_status.ps1 -Action start   -ServiceName "wuauserv"
#        .\windows_service_status.ps1 -Action stop    -ServiceName "wuauserv"
#        .\windows_service_status.ps1 -Action restart -ServiceName "wuauserv"
# =============================================================================

[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [ValidateSet("list","start","stop","restart","status")]
    [string]$Action,

    [Parameter(Mandatory=$false)]
    [string]$ServiceName = "",

    [Parameter(Mandatory=$false)]
    [string]$Filter = "",         # Name filter substring for list action

    [Parameter(Mandatory=$false)]
    [switch]$JsonOutput           # Output results as JSON
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Write-JsonResult {
    param($Data)
    Write-Output ($Data | ConvertTo-Json -Depth 5 -Compress)
}

# ── STATUS MAP ─────────────────────────────────────────────────────────────────
$StartupMap = @{
    2 = "automatic"; 3 = "manual"; 4 = "disabled"; 0 = "boot"; 1 = "system"
}

# ── LIST ALL SERVICES ──────────────────────────────────────────────────────────
if ($Action -eq "list") {
    try {
        $services = Get-Service | ForEach-Object {
            $svc = $_
            # Get startup type from WMI (more reliable than .StartType on older OS)
            $wmi = $null
            try {
                $wmi = Get-WmiObject -Class Win32_Service -Filter "Name='$($svc.ServiceName)'" -ErrorAction SilentlyContinue
            } catch {}

            $startType = if ($wmi) { $wmi.StartMode.ToLower() } else { "unknown" }
            $desc       = if ($wmi) { $wmi.Description } else { "" }

            [PSCustomObject]@{
                name         = $svc.ServiceName
                display_name = $svc.DisplayName
                status       = $svc.Status.ToString().ToLower()
                startup_type = $startType
                description  = $desc
                can_pause    = $svc.CanPauseAndContinue
                can_stop     = $svc.CanStop
            }
        }

        # Apply name filter if provided
        if ($Filter) {
            $services = $services | Where-Object {
                $_.name -like "*$Filter*" -or $_.display_name -like "*$Filter*"
            }
        }

        $result = @{
            success      = $true
            action       = "list"
            service_count = ($services | Measure-Object).Count
            services     = @($services)
            fetched_at   = (Get-Date -Format "o")
            hostname     = $env:COMPUTERNAME
        }

        if ($JsonOutput) {
            Write-JsonResult $result
        } else {
            $services | Format-Table name, display_name, status, startup_type -AutoSize
        }

    } catch {
        Write-JsonResult @{ success = $false; error = $_.Exception.Message }
        exit 1
    }
}


# ── SERVICE CONTROL (start / stop / restart / status) ─────────────────────────
elseif ($Action -in @("start","stop","restart","status")) {
    if (-not $ServiceName) {
        Write-Error "ServiceName is required for action: $Action"
        exit 1
    }

    try {
        $svc = Get-Service -Name $ServiceName -ErrorAction Stop
    } catch {
        Write-JsonResult @{
            success      = $false
            action       = $Action
            service_name = $ServiceName
            error        = "Service not found: $ServiceName"
        }
        exit 1
    }

    $previousStatus = $svc.Status.ToString()

    try {
        switch ($Action) {
            "start" {
                if ($svc.Status -eq "Running") {
                    Write-JsonResult @{
                        success    = $true; action = "start"
                        service_name = $ServiceName
                        message    = "Service is already running"
                        new_status = "running"
                    }
                    exit 0
                }
                Start-Service -Name $ServiceName -ErrorAction Stop
                Start-Sleep -Seconds 2
            }
            "stop" {
                if ($svc.Status -eq "Stopped") {
                    Write-JsonResult @{
                        success    = $true; action = "stop"
                        service_name = $ServiceName
                        message    = "Service is already stopped"
                        new_status = "stopped"
                    }
                    exit 0
                }
                Stop-Service -Name $ServiceName -Force -ErrorAction Stop
                Start-Sleep -Seconds 2
            }
            "restart" {
                Restart-Service -Name $ServiceName -Force -ErrorAction Stop
                Start-Sleep -Seconds 3
            }
            "status" {
                # Just report — no action
            }
        }

        # Refresh status
        $svc.Refresh()
        $newStatus = $svc.Status.ToString().ToLower()

        $wmi = Get-WmiObject -Class Win32_Service -Filter "Name='$ServiceName'" -EA SilentlyContinue
        $result = @{
            success      = $true
            action       = $Action
            service_name = $ServiceName
            display_name = $svc.DisplayName
            prev_status  = $previousStatus.ToLower()
            new_status   = $newStatus
            startup_type = if ($wmi) { $wmi.StartMode.ToLower() } else { "unknown" }
            message      = "Action '$Action' completed successfully"
            hostname     = $env:COMPUTERNAME
            timestamp    = (Get-Date -Format "o")
        }

        if ($JsonOutput) {
            Write-JsonResult $result
        } else {
            Write-Output "[$Action] $ServiceName : $previousStatus -> $newStatus"
        }

    } catch {
        $errMsg = $_.Exception.Message
        Write-JsonResult @{
            success      = $false
            action       = $Action
            service_name = $ServiceName
            error        = $errMsg
        }
        exit 1
    }
}
