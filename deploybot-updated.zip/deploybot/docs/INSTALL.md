# DeployBot — Full Ubuntu Server Installation Guide
> Ubuntu 22.04 LTS or 24.04 LTS · No Docker · Bare-metal setup

---

## Table of Contents
1. [Prerequisites](#1-prerequisites)
2. [System Packages](#2-system-packages)
3. [PostgreSQL 16](#3-postgresql-16)
4. [Redis 7](#4-redis-7)
5. [Node.js 20 (Frontend build)](#5-nodejs-20)
6. [Application User](#6-create-application-user)
7. [Deploy Application Files](#7-deploy-application-files)
8. [Python Environment](#8-python-virtual-environment)
9. [Configure .env](#9-configure-env)
10. [Generate Secrets](#10-generate-secrets)
11. [Build Frontend](#11-build-frontend)
12. [Nginx](#12-configure-nginx)
13. [Systemd Services](#13-register-systemd-services)
14. [Firewall (UFW)](#14-configure-firewall)
15. [First Login](#15-first-login--verification)
16. [Useful Commands](#16-day-to-day-management-commands)
17. [Troubleshooting](#17-troubleshooting)

---

## 1. Prerequisites

- Ubuntu 22.04 or 24.04 server (2 CPU, 4 GB RAM minimum)
- A non-root user with `sudo` rights
- SSH access to the server
- Your DeployBot project files transferred to the server

Transfer files from your local machine:
```bash
scp -r ./deploybot  youruser@SERVER_IP:/home/youruser/
```

---

## 2. System Packages

```bash
sudo apt-get update && sudo apt-get upgrade -y

sudo apt-get install -y \
    curl wget git unzip build-essential \
    software-properties-common apt-transport-https \
    ca-certificates gnupg lsb-release \
    net-tools ufw sshpass \
    python3.11 python3.11-venv python3.11-dev python3-pip \
    libpq-dev          # PostgreSQL C headers (for psycopg2)
```

Verify Python:
```bash
python3.11 --version
# Python 3.11.x
```

---

## 3. PostgreSQL 16

### Install
```bash
# Add official PostgreSQL repository
sudo sh -c 'echo "deb https://apt.postgresql.org/pub/repos/apt $(lsb_release -cs)-pgdg main" \
    > /etc/apt/sources.list.d/pgdg.list'

wget --quiet -O - https://www.postgresql.org/media/keys/ACCC4CF8.asc | sudo apt-key add -

sudo apt-get update
sudo apt-get install -y postgresql-16 postgresql-client-16
```

### Start & enable
```bash
sudo systemctl enable postgresql
sudo systemctl start postgresql
sudo systemctl status postgresql   # should show: active (running)
```

### Create database and user
```bash
sudo -u postgres psql
```
Inside the psql shell:
```sql
-- ⚠️  Change 'StrongPassword123!' to your own secure password
CREATE USER deploybot WITH PASSWORD 'StrongPassword123!';
CREATE DATABASE deploybot_db OWNER deploybot;
GRANT ALL PRIVILEGES ON DATABASE deploybot_db TO deploybot;

-- Verify
\l
\q
```

### Test connection
```bash
psql -U deploybot -h 127.0.0.1 -d deploybot_db -c "SELECT version();"
# Enter your password → should print PostgreSQL version
```

---

## 4. Redis 7

### Install
```bash
sudo apt-get install -y redis-server
```

### Secure Redis (bind to localhost + set password)
```bash
sudo nano /etc/redis/redis.conf
```

Find and change these lines:
```
# FIND:    bind 127.0.0.1 -::1
# ENSURE:  bind 127.0.0.1
bind 127.0.0.1

# FIND:    # requirepass foobared
# CHANGE to (use your own password):
requirepass YourRedisPassword123!

# FIND:    supervised no
# CHANGE:
supervised systemd
```

Save and restart:
```bash
sudo systemctl enable redis-server
sudo systemctl restart redis-server
sudo systemctl status redis-server   # should show: active (running)
```

### Test Redis
```bash
redis-cli -a YourRedisPassword123! ping
# PONG  ← success
```

---

## 5. Node.js 20

```bash
# Add NodeSource repo
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Verify
node --version    # v20.x.x
npm  --version    # 10.x.x
```

---

## 6. Create Application User

Running the app as a dedicated non-root system user limits blast radius if anything goes wrong:

```bash
# Create user with home at /opt/deploybot
sudo useradd --system --shell /bin/bash \
    --home-dir /opt/deploybot \
    --create-home \
    deploybot

# Create log directory
sudo mkdir -p /opt/deploybot/logs

# Set ownership
sudo chown -R deploybot:deploybot /opt/deploybot
```

---

## 7. Deploy Application Files

```bash
# Copy your project into the app directory
sudo cp -r /home/youruser/deploybot /opt/deploybot/app

# Fix ownership
sudo chown -R deploybot:deploybot /opt/deploybot/app

# Verify structure
ls /opt/deploybot/app/
# backend/  frontend/  scripts/  docs/
```

---

## 8. Python Virtual Environment

```bash
cd /opt/deploybot/app/backend

# Create venv
sudo -u deploybot python3.11 -m venv venv

# Activate (for testing manually)
source venv/bin/activate

# Install all Python dependencies
sudo -u deploybot venv/bin/pip install --upgrade pip wheel setuptools
sudo -u deploybot venv/bin/pip install -r requirements.txt

# Verify FastAPI is installed
sudo -u deploybot venv/bin/python -c "import fastapi; print(fastapi.__version__)"
```

---

## 9. Configure .env

### Generate the two required secrets first

**JWT Secret Key:**
```bash
openssl rand -hex 32
# Copy the output — use it as SECRET_KEY below
```

**Fernet Encryption Key:**
```bash
sudo -u deploybot /opt/deploybot/app/backend/venv/bin/python3 -c \
    "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
# Copy the output — use it as ENCRYPTION_KEY below
```

### Write the .env file
```bash
sudo -u deploybot nano /opt/deploybot/app/backend/.env
```

Paste and fill in ALL values:
```env
# ── Application ───────────────────────────────────────────────────────────────
APP_NAME=DeployBot
APP_VERSION=1.0.0
DEBUG=false
# Put your server's actual IP or domain here (no trailing slash)
ALLOWED_ORIGINS=["http://192.168.1.100","https://deploybot.yourcompany.com"]

# ── Database ──────────────────────────────────────────────────────────────────
DATABASE_URL=postgresql://deploybot:StrongPassword123!@localhost:5432/deploybot_db

# ── Redis / Celery ────────────────────────────────────────────────────────────
REDIS_URL=redis://:YourRedisPassword123!@localhost:6379/0
CELERY_BROKER_URL=redis://:YourRedisPassword123!@localhost:6379/0
CELERY_RESULT_BACKEND=redis://:YourRedisPassword123!@localhost:6379/1

# ── JWT (output of: openssl rand -hex 32) ────────────────────────────────────
SECRET_KEY=PASTE_YOUR_64_CHAR_HEX_HERE

# ── Fernet (output of python command above) ───────────────────────────────────
ENCRYPTION_KEY=PASTE_YOUR_FERNET_KEY_HERE

# ── Shared file server ────────────────────────────────────────────────────────
FILE_SERVER_HOST=192.168.1.50
FILE_SERVER_SHARE=\\\\192.168.1.50\\packages
FILE_SERVER_USERNAME=DOMAIN\\svc_deploy
FILE_SERVER_PASSWORD=YourFileServerPassword

# ── Logging ───────────────────────────────────────────────────────────────────
LOG_LEVEL=INFO
LOG_DIR=/opt/deploybot/logs
```

### Lock down .env permissions (critical!)
```bash
sudo chmod 600 /opt/deploybot/app/backend/.env
sudo chown deploybot:deploybot /opt/deploybot/app/backend/.env

# Verify — only owner can read
ls -la /opt/deploybot/app/backend/.env
# -rw------- 1 deploybot deploybot ...
```

---

## 10. Generate Secrets

> Already done in Step 9 — recap for reference:

| Secret | Command |
|--------|---------|
| `SECRET_KEY` | `openssl rand -hex 32` |
| `ENCRYPTION_KEY` | `python3 -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"` |

---

## 11. Build Frontend

```bash
cd /opt/deploybot/app/frontend

# Install npm packages
sudo -u deploybot npm install

# Set the API base URL to your server (used in production build)
# Edit vite.config.js if needed, or set via env:
export VITE_API_BASE_URL=http://YOUR_SERVER_IP

# Build for production
sudo -u deploybot npm run build

# Verify the dist folder was created
ls /opt/deploybot/app/frontend/dist/
# index.html  assets/  ...
```

**Update Vite config to proxy API during build:**
```bash
sudo -u deploybot nano /opt/deploybot/app/frontend/vite.config.js
```

Ensure it contains:
```js
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/api': 'http://127.0.0.1:8000',
    },
  },
})
```

---

## 12. Configure Nginx

### Install Nginx
```bash
sudo apt-get install -y nginx
sudo systemctl enable nginx
```

### Install DeployBot site config
```bash
sudo cp /opt/deploybot/app/docs/deploybot.nginx \
        /etc/nginx/sites-available/deploybot

# Edit the server_name with your actual IP or domain
sudo nano /etc/nginx/sites-available/deploybot
# Change: server_name YOUR_SERVER_IP_OR_DOMAIN;
# To:     server_name 192.168.1.100;     (or your domain)

# Enable the site
sudo ln -sf /etc/nginx/sites-available/deploybot \
            /etc/nginx/sites-enabled/deploybot

# Disable default site
sudo rm -f /etc/nginx/sites-enabled/default

# Test config
sudo nginx -t
# nginx: configuration file /etc/nginx/nginx.conf test is successful

# Reload
sudo systemctl reload nginx
```

---

## 13. Register Systemd Services

### FastAPI backend
```bash
sudo cp /opt/deploybot/app/docs/deploybot-api.service \
        /etc/systemd/system/deploybot-api.service

sudo systemctl daemon-reload
sudo systemctl enable deploybot-api
sudo systemctl start  deploybot-api

# Check it started correctly
sudo systemctl status deploybot-api
sudo journalctl -u deploybot-api -n 50 --no-pager
```

Expected output:
```
● deploybot-api.service - DeployBot FastAPI Backend
     Loaded: loaded (/etc/systemd/system/deploybot-api.service; enabled)
     Active: active (running) since ...
```

### Celery worker
```bash
sudo cp /opt/deploybot/app/docs/deploybot-worker.service \
        /etc/systemd/system/deploybot-worker.service

sudo systemctl daemon-reload
sudo systemctl enable deploybot-worker
sudo systemctl start  deploybot-worker

sudo systemctl status deploybot-worker
sudo journalctl -u deploybot-worker -n 50 --no-pager
```

### Verify all services are running
```bash
sudo systemctl status postgresql redis-server nginx deploybot-api deploybot-worker
```

All five should show **active (running)**.

---

## 14. Configure Firewall

```bash
# Allow SSH (don't lock yourself out!)
sudo ufw allow OpenSSH

# Allow HTTP (and HTTPS if using SSL)
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# Block direct access to backend port from outside
# (Nginx proxies /api internally — no need to expose 8000 publicly)
sudo ufw deny 8000/tcp

# Block Redis and PostgreSQL from external access
sudo ufw deny 5432/tcp
sudo ufw deny 6379/tcp

# Enable firewall
sudo ufw enable
sudo ufw status verbose
```

---

## 15. First Login & Verification

### Quick health check
```bash
# API is responding
curl http://localhost:8000/api/health
# {"status":"ok","app":"DeployBot","version":"1.0.0"}

# Via Nginx
curl http://YOUR_SERVER_IP/api/health
```

### Open in browser
```
http://YOUR_SERVER_IP
```

**Default login:**
| Field | Value |
|-------|-------|
| Username | `admin` |
| Password | `Admin@1234` |

> ⚠️ **Change the password immediately after first login!**

---

## 16. Day-to-Day Management Commands

```bash
# ── View live logs ──────────────────────────────────────────────────────────
sudo journalctl -u deploybot-api    -f   # API logs (live)
sudo journalctl -u deploybot-worker -f   # Celery worker logs (live)
sudo journalctl -u nginx            -f   # Nginx logs

# ── Restart services after code changes ─────────────────────────────────────
sudo systemctl restart deploybot-api
sudo systemctl restart deploybot-worker

# ── Check service status ────────────────────────────────────────────────────
sudo systemctl status deploybot-api
sudo systemctl status deploybot-worker

# ── Rebuild frontend after UI changes ───────────────────────────────────────
cd /opt/deploybot/app/frontend
sudo -u deploybot npm run build
sudo systemctl reload nginx

# ── Database access ─────────────────────────────────────────────────────────
sudo -u postgres psql deploybot_db
# or:
psql -U deploybot -h 127.0.0.1 deploybot_db

# ── Useful SQL queries ───────────────────────────────────────────────────────
# psql> SELECT id, username, is_active FROM users;
# psql> SELECT id, status, target_ip, created_at FROM deployments ORDER BY id DESC LIMIT 10;
# psql> SELECT COUNT(*) FROM deployment_logs WHERE level = 'ERROR';

# ── Redis CLI ───────────────────────────────────────────────────────────────
redis-cli -a YourRedisPassword123! info keyspace
redis-cli -a YourRedisPassword123! keys "celery*"

# ── Celery worker inspect ───────────────────────────────────────────────────
cd /opt/deploybot/app/backend
source venv/bin/activate
celery -A tasks.deployment_tasks.celery_app inspect active
celery -A tasks.deployment_tasks.celery_app inspect stats

# ── Application log files ────────────────────────────────────────────────────
tail -f /opt/deploybot/logs/deploybot.log
tail -f /opt/deploybot/logs/celery-worker.log
```

---

## 17. Troubleshooting

### ❌ `deploybot-api` fails to start
```bash
sudo journalctl -u deploybot-api -n 100 --no-pager
```
Common causes:
- Wrong `DATABASE_URL` password → check `/opt/deploybot/app/backend/.env`
- PostgreSQL not running → `sudo systemctl start postgresql`
- Port 8000 already in use → `sudo lsof -i :8000`
- Python import error → `cd /opt/deploybot/app/backend && sudo -u deploybot venv/bin/python main.py`

### ❌ Cannot connect to database
```bash
sudo systemctl status postgresql
# Check pg_hba.conf allows local connections:
sudo nano /etc/postgresql/16/main/pg_hba.conf
# Ensure this line exists:
# local   all   deploybot   md5
sudo systemctl reload postgresql
```

### ❌ Redis connection refused
```bash
sudo systemctl status redis-server
redis-cli -a YourRedisPassword123! ping
# Check bind address:
grep "^bind" /etc/redis/redis.conf
# Should be: bind 127.0.0.1
```

### ❌ Celery worker not processing jobs
```bash
sudo journalctl -u deploybot-worker -n 50
# Test manually:
cd /opt/deploybot/app/backend && source venv/bin/activate
celery -A tasks.deployment_tasks.celery_app worker --loglevel=debug
```

### ❌ Frontend shows blank page or 404
```bash
sudo nginx -t                          # Test config
ls /opt/deploybot/app/frontend/dist/   # Verify build exists
sudo cat /var/log/nginx/deploybot_error.log
```

### ❌ API returns 401 on all requests
- Token expired → log in again
- `SECRET_KEY` changed → all tokens invalidated, users must re-login

### ❌ WinRM connection refused on Windows target
On the Windows target server, run (as Administrator):
```powershell
Enable-PSRemoting -Force
Set-Item WSMan:\localhost\Service\Auth\Basic -Value $true
Set-Item WSMan:\localhost\Service\AllowUnencrypted -Value $true
netsh advfirewall firewall add rule name="WinRM HTTP" dir=in action=allow protocol=TCP localport=5985
```

### ❌ SSH deployment fails — permission denied
```bash
# Test SSH manually from the DeployBot server:
ssh -v username@TARGET_IP
# If using password auth, ensure target sshd allows it:
# PasswordAuthentication yes  (in /etc/ssh/sshd_config on target)
```

---

## Updating DeployBot

```bash
# 1. Copy new files
sudo cp -r /path/to/new/deploybot/* /opt/deploybot/app/
sudo chown -R deploybot:deploybot /opt/deploybot/app/

# 2. Update Python dependencies
cd /opt/deploybot/app/backend
sudo -u deploybot venv/bin/pip install -r requirements.txt --upgrade

# 3. Rebuild frontend
cd /opt/deploybot/app/frontend
sudo -u deploybot npm install && sudo -u deploybot npm run build

# 4. Restart services
sudo systemctl restart deploybot-api deploybot-worker
sudo systemctl reload nginx

# 5. Verify
curl http://localhost:8000/api/health
```
