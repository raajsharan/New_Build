#!/usr/bin/env bash
# =============================================================================
# DeployBot — Complete Ubuntu Server Setup (No Docker)
# Tested on: Ubuntu 22.04 LTS / 24.04 LTS
# Run as root or a sudo-enabled user
# =============================================================================

# ─────────────────────────────────────────────────────────────────────────────
# STEP 0 — System update
# ─────────────────────────────────────────────────────────────────────────────
sudo apt-get update && sudo apt-get upgrade -y
sudo apt-get install -y \
    curl wget git unzip build-essential \
    software-properties-common apt-transport-https \
    ca-certificates gnupg lsb-release \
    net-tools ufw


# ─────────────────────────────────────────────────────────────────────────────
# STEP 1 — Install Python 3.11
# ─────────────────────────────────────────────────────────────────────────────
sudo apt-get install -y python3.11 python3.11-venv python3.11-dev python3-pip
# Verify
python3.11 --version


# ─────────────────────────────────────────────────────────────────────────────
# STEP 2 — Install PostgreSQL 16
# ─────────────────────────────────────────────────────────────────────────────
# Add official PostgreSQL APT repo
sudo sh -c 'echo "deb https://apt.postgresql.org/pub/repos/apt $(lsb_release -cs)-pgdg main" \
    > /etc/apt/sources.list.d/pgdg.list'
wget --quiet -O - https://www.postgresql.org/media/keys/ACCC4CF8.asc | sudo apt-key add -
sudo apt-get update
sudo apt-get install -y postgresql-16 postgresql-client-16 postgresql-contrib-16

# Start & enable PostgreSQL
sudo systemctl enable postgresql
sudo systemctl start postgresql

# Create DB user and database
sudo -u postgres psql << 'SQL'
CREATE USER deploybot WITH PASSWORD 'CHANGE_THIS_DB_PASSWORD';
CREATE DATABASE deploybot_db OWNER deploybot;
GRANT ALL PRIVILEGES ON DATABASE deploybot_db TO deploybot;
\q
SQL

# Verify connection
sudo -u postgres psql -c "\l" | grep deploybot_db


# ─────────────────────────────────────────────────────────────────────────────
# STEP 3 — Install Redis 7
# ─────────────────────────────────────────────────────────────────────────────
sudo apt-get install -y redis-server

# Secure Redis — bind to localhost only, disable external access
sudo sed -i 's/^bind .*/bind 127.0.0.1 -::1/' /etc/redis/redis.conf
sudo sed -i 's/^# requirepass .*/requirepass CHANGE_THIS_REDIS_PASSWORD/' /etc/redis/redis.conf
sudo sed -i 's/^supervised no/supervised systemd/' /etc/redis/redis.conf

sudo systemctl enable redis-server
sudo systemctl restart redis-server

# Verify Redis
redis-cli -a CHANGE_THIS_REDIS_PASSWORD ping   # should return PONG


# ─────────────────────────────────────────────────────────────────────────────
# STEP 4 — Install Node.js 20 (for frontend build)
# ─────────────────────────────────────────────────────────────────────────────
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
# Verify
node --version && npm --version


# ─────────────────────────────────────────────────────────────────────────────
# STEP 5 — Install Nginx (serves frontend + proxies API)
# ─────────────────────────────────────────────────────────────────────────────
sudo apt-get install -y nginx
sudo systemctl enable nginx
sudo systemctl start nginx


# ─────────────────────────────────────────────────────────────────────────────
# STEP 6 — Create application user (no login shell, for security)
# ─────────────────────────────────────────────────────────────────────────────
sudo useradd --system --shell /bin/bash --home /opt/deploybot --create-home deploybot
sudo mkdir -p /opt/deploybot/logs
sudo chown -R deploybot:deploybot /opt/deploybot


# ─────────────────────────────────────────────────────────────────────────────
# STEP 7 — Deploy application files
# ─────────────────────────────────────────────────────────────────────────────
# Copy your project files (adjust path as needed)
sudo cp -r /path/to/deploybot /opt/deploybot/app
sudo chown -R deploybot:deploybot /opt/deploybot/app


# ─────────────────────────────────────────────────────────────────────────────
# STEP 8 — Python virtual environment + dependencies
# ─────────────────────────────────────────────────────────────────────────────
cd /opt/deploybot/app/backend
sudo -u deploybot python3.11 -m venv venv
sudo -u deploybot /opt/deploybot/app/backend/venv/bin/pip install --upgrade pip wheel
sudo -u deploybot /opt/deploybot/app/backend/venv/bin/pip install -r requirements.txt

# Install sshpass (needed by Linux deployment SSH copy)
sudo apt-get install -y sshpass


# ─────────────────────────────────────────────────────────────────────────────
# STEP 9 — Configure environment variables
# ─────────────────────────────────────────────────────────────────────────────
# Generate secrets first:
#   SECRET_KEY:      openssl rand -hex 32
#   ENCRYPTION_KEY:  python3.11 -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"

sudo -u deploybot tee /opt/deploybot/app/backend/.env > /dev/null << 'ENVEOF'
# ── Application ───────────────────────────────────────────────────────────────
APP_NAME=DeployBot
APP_VERSION=1.0.0
DEBUG=false
ALLOWED_ORIGINS=["http://YOUR_SERVER_IP","https://YOUR_DOMAIN"]

# ── Database ──────────────────────────────────────────────────────────────────
DATABASE_URL=postgresql://deploybot:CHANGE_THIS_DB_PASSWORD@localhost:5432/deploybot_db

# ── Redis / Celery ────────────────────────────────────────────────────────────
REDIS_URL=redis://:CHANGE_THIS_REDIS_PASSWORD@localhost:6379/0
CELERY_BROKER_URL=redis://:CHANGE_THIS_REDIS_PASSWORD@localhost:6379/0
CELERY_RESULT_BACKEND=redis://:CHANGE_THIS_REDIS_PASSWORD@localhost:6379/1

# ── JWT (generate with: openssl rand -hex 32) ─────────────────────────────────
SECRET_KEY=REPLACE_WITH_64_CHAR_HEX

# ── Fernet encryption (generate as above) ────────────────────────────────────
ENCRYPTION_KEY=REPLACE_WITH_FERNET_KEY

# ── Shared file server ────────────────────────────────────────────────────────
FILE_SERVER_HOST=192.168.1.50
FILE_SERVER_SHARE=\\\\192.168.1.50\\packages
FILE_SERVER_USERNAME=domain\\svc_deploy
FILE_SERVER_PASSWORD=REPLACE_WITH_FILE_SERVER_PASSWORD

# ── Logging ───────────────────────────────────────────────────────────────────
LOG_LEVEL=INFO
LOG_DIR=/opt/deploybot/logs
ENVEOF

# Lock down permissions — only deploybot user can read this file
sudo chmod 600 /opt/deploybot/app/backend/.env
