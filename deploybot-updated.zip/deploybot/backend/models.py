"""
models.py - SQLAlchemy ORM models.
Tables: users, packages, deployments, deployment_logs, service_checks
"""

from datetime import datetime
from sqlalchemy import (
    Column, Integer, String, Text, DateTime, Boolean,
    Enum, ForeignKey, JSON
)
from sqlalchemy.orm import relationship
import enum
from database import Base


# ── Enums ─────────────────────────────────────────────────────────────────────

class OSType(str, enum.Enum):
    windows = "windows"
    linux = "linux"

class DeploymentStatus(str, enum.Enum):
    pending   = "pending"
    running   = "running"
    success   = "success"
    failed    = "failed"
    cancelled = "cancelled"

class ServiceAction(str, enum.Enum):
    start   = "start"
    stop    = "stop"
    restart = "restart"


# ── Models ────────────────────────────────────────────────────────────────────

class User(Base):
    """Admin users who can log in and use DeployBot."""
    __tablename__ = "users"

    id            = Column(Integer, primary_key=True, index=True)
    username      = Column(String(64), unique=True, nullable=False, index=True)
    email         = Column(String(128), unique=True, nullable=False)
    hashed_password = Column(String(256), nullable=False)
    is_active     = Column(Boolean, default=True)
    is_superuser  = Column(Boolean, default=False)
    created_at    = Column(DateTime, default=datetime.utcnow)
    last_login    = Column(DateTime, nullable=True)

    deployments   = relationship("Deployment", back_populates="deployed_by_user")


class Package(Base):
    """Software packages registered in the system."""
    __tablename__ = "packages"

    id          = Column(Integer, primary_key=True, index=True)
    name        = Column(String(128), nullable=False, index=True)
    version     = Column(String(64),  nullable=False)
    file_path   = Column(String(512), nullable=False)   # Path on shared file server
    os_type     = Column(Enum(OSType), nullable=False)
    description = Column(Text, nullable=True)
    checksum    = Column(String(128), nullable=True)     # SHA256 of package file
    created_at  = Column(DateTime, default=datetime.utcnow)
    updated_at  = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by  = Column(Integer, ForeignKey("users.id"), nullable=True)

    deployments = relationship("Deployment", back_populates="package")


class Deployment(Base):
    """Records of each deployment job."""
    __tablename__ = "deployments"

    id              = Column(Integer, primary_key=True, index=True)
    package_id      = Column(Integer, ForeignKey("packages.id"), nullable=False)
    target_ip       = Column(String(64),  nullable=False)
    target_username = Column(String(128), nullable=False)
    # Encrypted credential stored as ciphertext — never plaintext
    target_password_enc = Column(Text, nullable=True)
    ssh_key_enc     = Column(Text, nullable=True)         # For Linux SSH key auth
    os_type         = Column(Enum(OSType), nullable=False)
    status          = Column(Enum(DeploymentStatus), default=DeploymentStatus.pending)
    celery_task_id  = Column(String(256), nullable=True)  # Background task reference
    started_at      = Column(DateTime, nullable=True)
    completed_at    = Column(DateTime, nullable=True)
    deployed_by     = Column(Integer, ForeignKey("users.id"), nullable=True)
    extra_options   = Column(JSON, nullable=True)         # Silent flags, args, etc.
    created_at      = Column(DateTime, default=datetime.utcnow)

    package          = relationship("Package", back_populates="deployments")
    deployed_by_user = relationship("User", back_populates="deployments")
    logs             = relationship("DeploymentLog", back_populates="deployment",
                                   order_by="DeploymentLog.timestamp")


class DeploymentLog(Base):
    """Streaming log entries for a deployment job."""
    __tablename__ = "deployment_logs"

    id            = Column(Integer, primary_key=True, index=True)
    deployment_id = Column(Integer, ForeignKey("deployments.id"), nullable=False)
    level         = Column(String(16), default="INFO")   # INFO | WARNING | ERROR
    message       = Column(Text, nullable=False)
    timestamp     = Column(DateTime, default=datetime.utcnow)

    deployment    = relationship("Deployment", back_populates="logs")


class ServiceCheck(Base):
    """Audit log for service status checks and control actions."""
    __tablename__ = "service_checks"

    id          = Column(Integer, primary_key=True, index=True)
    server_ip   = Column(String(64),  nullable=False)
    os_type     = Column(Enum(OSType), nullable=False)
    username    = Column(String(128), nullable=False)
    action      = Column(String(32),  nullable=False)   # list | start | stop | restart
    service_name = Column(String(256), nullable=True)
    result      = Column(JSON, nullable=True)           # Service list or action result
    success     = Column(Boolean, default=True)
    error_msg   = Column(Text, nullable=True)
    performed_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at  = Column(DateTime, default=datetime.utcnow)
