"""
schemas.py - Pydantic v2 request/response schemas.
Passwords/keys are write-only (never returned in responses).
"""

from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, EmailStr, Field, field_validator
import enum


# ── Shared Enums ──────────────────────────────────────────────────────────────

class OSType(str, enum.Enum):
    windows = "windows"
    linux   = "linux"

class DeploymentStatus(str, enum.Enum):
    pending   = "pending"
    running   = "running"
    success   = "success"
    failed    = "failed"
    cancelled = "cancelled"


# ── Auth ──────────────────────────────────────────────────────────────────────

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int

class TokenData(BaseModel):
    username: Optional[str] = None

class UserCreate(BaseModel):
    username: str = Field(..., min_length=3, max_length=64)
    email: EmailStr
    password: str = Field(..., min_length=8)
    is_superuser: bool = False

class UserOut(BaseModel):
    id: int
    username: str
    email: str
    is_active: bool
    is_superuser: bool
    created_at: datetime
    last_login: Optional[datetime]

    model_config = {"from_attributes": True}

class LoginRequest(BaseModel):
    username: str
    password: str


# ── Package ───────────────────────────────────────────────────────────────────

class PackageCreate(BaseModel):
    name: str        = Field(..., min_length=1, max_length=128)
    version: str     = Field(..., min_length=1, max_length=64)
    file_path: str   = Field(..., min_length=1, max_length=512,
                              description="Full UNC or absolute path on file server")
    os_type: OSType
    description: Optional[str] = None

class PackageUpdate(BaseModel):
    name: Optional[str]        = None
    version: Optional[str]     = None
    file_path: Optional[str]   = None
    os_type: Optional[OSType]  = None
    description: Optional[str] = None

class PackageOut(BaseModel):
    id: int
    name: str
    version: str
    file_path: str
    os_type: OSType
    description: Optional[str]
    checksum: Optional[str]
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


# ── Deployment ────────────────────────────────────────────────────────────────

class WindowsDeployRequest(BaseModel):
    package_id: int
    target_ip: str       = Field(..., description="Target Windows server IP or hostname")
    username: str        = Field(..., min_length=1)
    password: str        = Field(..., min_length=1, description="Write-only — never returned")
    extra_args: Optional[str] = Field(None, description="Additional installer arguments")

class LinuxDeployRequest(BaseModel):
    package_id: int
    target_ip: str       = Field(..., description="Target Linux server IP or hostname")
    username: str        = Field(..., min_length=1)
    password: Optional[str] = None
    ssh_key: Optional[str]  = Field(None, description="PEM private key content (write-only)")
    use_sudo: bool          = True
    package_manager: Optional[str] = Field(
        None, description="Override auto-detected: apt | yum | dnf | rpm | deb"
    )

    @field_validator("ssh_key", "password", mode="before")
    @classmethod
    def at_least_one_auth(cls, v, info):
        # Validation happens at router level for cross-field check
        return v

class DeploymentLogOut(BaseModel):
    id: int
    level: str
    message: str
    timestamp: datetime

    model_config = {"from_attributes": True}

class DeploymentOut(BaseModel):
    id: int
    package_id: int
    target_ip: str
    target_username: str
    os_type: OSType
    status: DeploymentStatus
    celery_task_id: Optional[str]
    started_at: Optional[datetime]
    completed_at: Optional[datetime]
    created_at: datetime
    logs: List[DeploymentLogOut] = []

    model_config = {"from_attributes": True}


# ── Service Monitoring ────────────────────────────────────────────────────────

class ServiceQueryRequest(BaseModel):
    server_ip: str    = Field(..., description="Target server IP or hostname")
    os_type: OSType
    username: str     = Field(..., min_length=1)
    password: Optional[str] = None
    ssh_key: Optional[str]  = None

class ServiceActionRequest(ServiceQueryRequest):
    service_name: str = Field(..., min_length=1)
    action: str       = Field(..., pattern="^(start|stop|restart)$")

class ServiceInfo(BaseModel):
    name: str
    display_name: Optional[str]
    status: str                  # running | stopped | unknown
    startup_type: Optional[str]  # automatic | manual | disabled | static
    description: Optional[str]

class ServiceListResponse(BaseModel):
    server_ip: str
    os_type: OSType
    services: List[ServiceInfo]
    fetched_at: datetime

class ServiceActionResponse(BaseModel):
    server_ip: str
    service_name: str
    action: str
    success: bool
    message: str
    new_status: Optional[str]


# ── Generic Responses ─────────────────────────────────────────────────────────

class MessageResponse(BaseModel):
    message: str
    detail: Optional[str] = None

class PaginatedPackages(BaseModel):
    total: int
    items: List[PackageOut]
    page: int
    page_size: int
