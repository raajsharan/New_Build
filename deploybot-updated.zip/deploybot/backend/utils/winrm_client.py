"""
utils/winrm_client.py - WinRM/PowerShell client for Windows deployment and service management.
Uses pywinrm with NTLM authentication.
"""

import logging
from typing import Optional, Tuple

import winrm

logger = logging.getLogger(__name__)


class WinRMClient:
    """WinRM client for executing PowerShell commands on Windows servers."""

    def __init__(
        self,
        host: str,
        username: str,
        password: str,
        port: int = 5985,
        transport: str = "ntlm",
        use_ssl: bool = False,
        read_timeout_sec: int = 120,
        operation_timeout_sec: int = 120,
    ):
        self.host     = host
        self.username = username
        self.password = password
        self.port     = port
        self.transport = transport
        self.use_ssl  = use_ssl
        self._session: Optional[winrm.Session] = None

        scheme = "https" if use_ssl else "http"
        self._endpoint = f"{scheme}://{host}:{port}/wsman"
        self._read_timeout      = read_timeout_sec
        self._operation_timeout = operation_timeout_sec

    # ── Connection ────────────────────────────────────────────────────────────

    def connect(self) -> None:
        """Create WinRM session (connection is lazy — tested on first command)."""
        self._session = winrm.Session(
            target=self._endpoint,
            auth=(self.username, self.password),
            transport=self.transport,
            read_timeout_sec=self._read_timeout,
            operation_timeout_sec=self._operation_timeout,
        )
        logger.info(f"WinRM session created for {self.host}:{self.port}")

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *args):
        self._session = None

    # ── Command Execution ─────────────────────────────────────────────────────

    def run_ps(self, script: str) -> Tuple[int, str, str]:
        """
        Run a PowerShell script block.
        Returns (exit_code, stdout, stderr).
        """
        if not self._session:
            raise RuntimeError("Not connected — call connect() first")

        logger.debug(f"WinRM PS [{self.host}]: {script[:120]}...")
        result = self._session.run_ps(script)
        exit_code = result.status_code
        stdout = result.std_out.decode("utf-8", errors="replace").strip()
        stderr = result.std_err.decode("utf-8", errors="replace").strip()
        return exit_code, stdout, stderr

    def run_cmd(self, command: str, args: list = None) -> Tuple[int, str, str]:
        """Run a CMD command (non-PowerShell)."""
        if not self._session:
            raise RuntimeError("Not connected")

        result = self._session.run_cmd(command, args or [])
        return (
            result.status_code,
            result.std_out.decode("utf-8", errors="replace").strip(),
            result.std_err.decode("utf-8", errors="replace").strip(),
        )

    # ── Service Management ────────────────────────────────────────────────────

    def list_services(self) -> list[dict]:
        """
        Fetch all Windows services via Get-Service.
        Returns list of dicts: {name, display_name, status, startup_type}
        """
        script = r"""
Get-Service | Select-Object Name, DisplayName, Status, StartType |
ConvertTo-Json -Depth 2
"""
        exit_code, out, err = self.run_ps(script)
        if exit_code != 0:
            raise RuntimeError(f"Get-Service failed: {err}")

        import json
        raw = json.loads(out)
        # Handle single-object vs array response from PowerShell
        if isinstance(raw, dict):
            raw = [raw]

        services = []
        status_map = {1: "stopped", 4: "running", 2: "starting", 3: "stopping"}
        startup_map = {0: "boot", 1: "system", 2: "automatic", 3: "manual", 4: "disabled"}

        for svc in raw:
            status_int  = svc.get("Status", {}).get("value__", 0) if isinstance(svc.get("Status"), dict) else svc.get("Status", 0)
            startup_int = svc.get("StartType", {}).get("value__", 3) if isinstance(svc.get("StartType"), dict) else svc.get("StartType", 3)

            services.append({
                "name": svc.get("Name", ""),
                "display_name": svc.get("DisplayName", ""),
                "status": status_map.get(int(status_int), str(status_int)),
                "startup_type": startup_map.get(int(startup_int), str(startup_int)),
                "description": "",
            })

        return services

    def control_service(self, service_name: str, action: str) -> Tuple[bool, str]:
        """
        Start/Stop/Restart a Windows service via PowerShell.
        Returns (success, message).
        """
        action_lower = action.lower()
        ps_cmd_map = {
            "start":   f"Start-Service   -Name '{service_name}' -ErrorAction Stop",
            "stop":    f"Stop-Service    -Name '{service_name}' -Force -ErrorAction Stop",
            "restart": f"Restart-Service -Name '{service_name}' -Force -ErrorAction Stop",
        }
        if action_lower not in ps_cmd_map:
            raise ValueError(f"Invalid action: {action}")

        script = f"""
try {{
    {ps_cmd_map[action_lower]}
    $svc = Get-Service -Name '{service_name}'
    Write-Output "OK:$($svc.Status)"
}} catch {{
    Write-Error $_.Exception.Message
    exit 1
}}
"""
        exit_code, out, err = self.run_ps(script)
        success = exit_code == 0
        message = out if success else err
        return success, message

    def get_service_status(self, service_name: str) -> str:
        """Return current status string for a named service."""
        script = f"(Get-Service -Name '{service_name}').Status.ToString()"
        exit_code, out, _ = self.run_ps(script)
        if exit_code != 0:
            return "unknown"
        return out.lower()

    # ── File Operations ───────────────────────────────────────────────────────

    def copy_from_share(
        self,
        share_path: str,
        share_username: str,
        share_password: str,
        destination: str,
    ) -> Tuple[bool, str]:
        """
        Map a network share and copy a file to local destination.
        E.g.: \\\\fileserver\\packages\\app.msi → C:\\Temp\\app.msi
        """
        share_dir = "\\".join(share_path.replace("/", "\\").split("\\")[:-1])
        file_name = share_path.replace("/", "\\").split("\\")[-1]

        script = f"""
$cred = New-Object System.Management.Automation.PSCredential (
    '{share_username}',
    (ConvertTo-SecureString '{share_password}' -AsPlainText -Force)
)
try {{
    New-PSDrive -Name TempShare -PSProvider FileSystem `
        -Root '{share_dir}' -Credential $cred -ErrorAction Stop | Out-Null
    Copy-Item -Path "TempShare:\\{file_name}" -Destination '{destination}' -Force
    Remove-PSDrive -Name TempShare
    Write-Output "OK"
}} catch {{
    Write-Error $_.Exception.Message
    exit 1
}}
"""
        exit_code, out, err = self.run_ps(script)
        return exit_code == 0, out if exit_code == 0 else err

    def install_msi(self, msi_path: str, extra_args: str = "") -> Tuple[bool, str]:
        """Silent MSI install using msiexec."""
        script = f"""
$proc = Start-Process msiexec.exe -ArgumentList '/i "{msi_path}" /quiet /norestart {extra_args}' `
    -Wait -PassThru -NoNewWindow
if ($proc.ExitCode -eq 0 -or $proc.ExitCode -eq 3010) {{
    Write-Output "Install succeeded (exit code: $($proc.ExitCode))"
}} else {{
    Write-Error "Install failed with exit code: $($proc.ExitCode)"
    exit $proc.ExitCode
}}
"""
        exit_code, out, err = self.run_ps(script)
        return exit_code == 0, out if exit_code == 0 else err

    def install_exe(self, exe_path: str, silent_args: str = "/S /silent /quiet") -> Tuple[bool, str]:
        """Silent EXE install."""
        script = f"""
$proc = Start-Process '{exe_path}' -ArgumentList '{silent_args}' `
    -Wait -PassThru -NoNewWindow
if ($proc.ExitCode -eq 0 -or $proc.ExitCode -eq 3010) {{
    Write-Output "Install succeeded (exit code: $($proc.ExitCode))"
}} else {{
    Write-Error "Install failed with exit code: $($proc.ExitCode)"
    exit $proc.ExitCode
}}
"""
        exit_code, out, err = self.run_ps(script)
        return exit_code == 0, out if exit_code == 0 else err
