"""
utils/ssh_client.py - SSH/SCP utilities for Linux deployment and service management.
Uses Paramiko for SSH connectivity.
"""

import io
import logging
import os
import stat
from typing import Optional, Generator, Tuple

import paramiko

logger = logging.getLogger(__name__)


class SSHClient:
    """Context-manager SSH client wrapping Paramiko."""

    def __init__(
        self,
        host: str,
        username: str,
        password: Optional[str] = None,
        ssh_key_content: Optional[str] = None,
        port: int = 22,
        timeout: int = 30,
    ):
        self.host    = host
        self.port    = port
        self.username = username
        self.password = password
        self.ssh_key_content = ssh_key_content
        self.timeout = timeout
        self._client: Optional[paramiko.SSHClient] = None

    # ── Connection Lifecycle ──────────────────────────────────────────────────

    def connect(self) -> None:
        """Open SSH connection."""
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        connect_kwargs = dict(
            hostname=self.host,
            port=self.port,
            username=self.username,
            timeout=self.timeout,
            allow_agent=False,
            look_for_keys=False,
        )

        if self.ssh_key_content:
            # Load private key from string content (PEM)
            pkey = paramiko.RSAKey.from_private_key(io.StringIO(self.ssh_key_content))
            connect_kwargs["pkey"] = pkey
        elif self.password:
            connect_kwargs["password"] = self.password
        else:
            raise ValueError("Either password or ssh_key must be provided")

        client.connect(**connect_kwargs)
        self._client = client
        logger.info(f"SSH connected to {self.host}:{self.port} as {self.username}")

    def disconnect(self) -> None:
        """Close SSH connection."""
        if self._client:
            self._client.close()
            self._client = None

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *args):
        self.disconnect()

    # ── Command Execution ─────────────────────────────────────────────────────

    def exec(self, command: str, timeout: int = 120) -> Tuple[int, str, str]:
        """
        Execute a command and return (exit_code, stdout, stderr).
        Raises RuntimeError if not connected.
        """
        if not self._client:
            raise RuntimeError("Not connected — call connect() first")

        logger.debug(f"SSH exec [{self.host}]: {command}")
        stdin, stdout, stderr = self._client.exec_command(command, timeout=timeout)
        exit_code = stdout.channel.recv_exit_status()
        out = stdout.read().decode("utf-8", errors="replace").strip()
        err = stderr.read().decode("utf-8", errors="replace").strip()
        return exit_code, out, err

    def exec_sudo(self, command: str, timeout: int = 120) -> Tuple[int, str, str]:
        """Execute command with sudo (requires passwordless sudo or password auth)."""
        sudo_cmd = f"sudo -S {command}"
        if self.password:
            sudo_cmd = f"echo '{self.password}' | sudo -S {command}"
        return self.exec(sudo_cmd, timeout=timeout)

    # ── File Transfer ─────────────────────────────────────────────────────────

    def upload_file(self, local_path: str, remote_path: str) -> None:
        """Upload a local file to the remote server via SFTP."""
        if not self._client:
            raise RuntimeError("Not connected")
        sftp = self._client.open_sftp()
        try:
            sftp.put(local_path, remote_path)
            logger.info(f"Uploaded {local_path} → {self.host}:{remote_path}")
        finally:
            sftp.close()

    def upload_string(self, content: str, remote_path: str) -> None:
        """Write string content directly to a remote file via SFTP."""
        if not self._client:
            raise RuntimeError("Not connected")
        sftp = self._client.open_sftp()
        try:
            with sftp.open(remote_path, "w") as f:
                f.write(content)
        finally:
            sftp.close()

    # ── Service Management ────────────────────────────────────────────────────

    def list_services(self) -> list[dict]:
        """
        Fetch all systemd services.
        Returns list of dicts: {name, status, startup_type, description}
        """
        # List all units with their state and description
        cmd = (
            "systemctl list-units --type=service --all --no-pager "
            "--output=json 2>/dev/null || "
            "systemctl list-units --type=service --all --no-pager "
            "--no-legend | awk '{print $1,$3,$4}'"
        )
        exit_code, out, err = self.exec(cmd)

        services = []
        # Try JSON first (systemd >= 230), fallback to text parsing
        try:
            import json
            units = json.loads(out)
            for unit in units:
                name = unit.get("unit", "").replace(".service", "")
                services.append({
                    "name": name,
                    "display_name": unit.get("description", name),
                    "status": unit.get("sub", "unknown"),   # running/dead/exited
                    "startup_type": unit.get("load", "unknown"),
                    "description": unit.get("description", ""),
                })
        except Exception:
            # Fallback: parse text output
            for line in out.splitlines():
                parts = line.split()
                if len(parts) >= 3:
                    services.append({
                        "name": parts[0].replace(".service", ""),
                        "display_name": parts[0].replace(".service", ""),
                        "status": parts[2] if len(parts) > 2 else "unknown",
                        "startup_type": "unknown",
                        "description": " ".join(parts[3:]) if len(parts) > 3 else "",
                    })

        # Also fetch enabled/disabled state per service
        exit_code2, enabled_out, _ = self.exec(
            "systemctl list-unit-files --type=service --no-pager --no-legend"
        )
        enabled_map = {}
        for line in enabled_out.splitlines():
            parts = line.split()
            if len(parts) >= 2:
                svc_name = parts[0].replace(".service", "")
                enabled_map[svc_name] = parts[1]  # enabled | disabled | static | masked

        for svc in services:
            if svc["name"] in enabled_map:
                svc["startup_type"] = enabled_map[svc["name"]]

        return services

    def control_service(self, service_name: str, action: str) -> Tuple[bool, str]:
        """
        Start/stop/restart a systemd service.
        Returns (success, message).
        """
        if action not in ("start", "stop", "restart", "status"):
            raise ValueError(f"Invalid service action: {action}")

        cmd = f"systemctl {action} {service_name}.service"
        exit_code, out, err = self.exec_sudo(cmd)

        success = exit_code == 0
        message = out or err or f"systemctl {action} exited with code {exit_code}"
        return success, message

    def get_service_status(self, service_name: str) -> str:
        """Return current status (running/stopped/unknown) of a service."""
        exit_code, out, _ = self.exec(
            f"systemctl is-active {service_name}.service 2>/dev/null"
        )
        status_map = {
            "active": "running",
            "inactive": "stopped",
            "failed": "failed",
            "activating": "starting",
            "deactivating": "stopping",
        }
        return status_map.get(out.strip(), "unknown")


# ── Detect Package Manager ────────────────────────────────────────────────────

def detect_package_manager(client: SSHClient) -> str:
    """Probe the remote Linux system for available package managers."""
    managers = ["apt-get", "dnf", "yum", "zypper", "pacman"]
    for mgr in managers:
        exit_code, _, _ = client.exec(f"which {mgr} 2>/dev/null")
        if exit_code == 0:
            return mgr
    return "unknown"
