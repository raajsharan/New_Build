"""
utils/encryption.py - Fernet symmetric encryption for credentials.

Credentials (passwords, SSH keys) are NEVER stored in plaintext.
They are encrypted before DB insert and decrypted only in worker tasks.
"""

from cryptography.fernet import Fernet, InvalidToken
from config import settings


def _get_fernet() -> Fernet:
    """Return a Fernet instance using the configured key."""
    key = settings.ENCRYPTION_KEY
    if len(key) != 44:
        raise ValueError(
            "ENCRYPTION_KEY must be a valid Fernet key (44 chars). "
            "Generate one with: python -c \"from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())\""
        )
    return Fernet(key.encode())


def encrypt_credential(plaintext: str) -> str:
    """Encrypt a plaintext credential → base64 ciphertext string."""
    if not plaintext:
        return ""
    f = _get_fernet()
    return f.encrypt(plaintext.encode()).decode()


def decrypt_credential(ciphertext: str) -> str:
    """Decrypt a ciphertext credential → plaintext string."""
    if not ciphertext:
        return ""
    try:
        f = _get_fernet()
        return f.decrypt(ciphertext.encode()).decode()
    except InvalidToken as e:
        raise ValueError(f"Failed to decrypt credential: {e}")
