"""
tasks/deployment_tasks.py - Celery background tasks for Windows and Linux deployments.
Tasks update the Deployment record and stream logs to DeploymentLog table.
"""

import os
import logging
import tempfile
from datetime import datetime
from typing import Optional

from celery import Celery
from sqlalchemy.orm import Session

# Local imports (tasks run in worker process — same PYTHONPATH as app)
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from config import settings
from database import SessionLocal
import models
from utils.encryption import decrypt_credential
from utils.ssh_client import SSHClient, detect_package_manager
from utils.winrm_client import WinRMClient

logger = logging.getLogger(__name__)

# ── Celery App ────────────────────────────────────────────────────────────────

celery_app = Celery(
    "deploybot",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
)

celery_app.conf.update(
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    task_acks_late=True,               # Re-queue on worker crash
    worker_prefetch_multiplier=1,      # One task per worker at a time
    result_expires=86400,              # Keep results 24 hours
)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _get_db() -> Session:
    return SessionLocal()


def _log(db: Session, deployment_id: int, level: str, message: str) -> None:
    """Persist a log entry and print for worker stdout."""
    entry = models.DeploymentLog(
        deployment_id=deployment_id,
        level=level.upper(),
        message=message,
    )
    db.add(entry)
    db.commit()
    print(f"[{level.upper()}] [{deployment_id}] {message}")


def _set_status(db: Session, deployment: models.Deployment, status: str) -> None:
    deployment.status = status
    if status == models.DeploymentStatus.running and not deployment.started_at:
        deployment.started_at = datetime.utcnow()
    if status in (models.DeploymentStatus.success, models.DeploymentStatus.failed):
        deployment.completed_at = datetime.utcnow()
    db.commit()


# ── Windows Deployment Task ───────────────────────────────────────────────────

@celery_app.task(bind=True, max_retries=0, name="tasks.deploy_windows")
def deploy_windows(
    self,
    deployment_id: int,
    share_username: str,
    share_password_enc: str,
) -> dict:
    """
    Background task: deploy a package to a Windows server via WinRM.
    Steps:
      1. Connect via WinRM (NTLM)
      2. Copy package from shared file server → C:\\Temp\\
      3. Install silently (MSI or EXE)
      4. Report result
    """
    db = _get_db()
    try:
        dep = db.query(models.Deployment).get(deployment_id)
        if not dep:
            return {"error": "Deployment record not found"}

        pkg = dep.package
        _set_status(db, dep, models.DeploymentStatus.running)
        _log(db, dep.id, "INFO", f"🚀 Starting Windows deployment of {pkg.name} v{pkg.version} → {dep.target_ip}")

        # Decrypt credentials
        target_password = decrypt_credential(dep.target_password_enc)
        share_password  = decrypt_credential(share_password_enc)

        # Step 1: Connect WinRM
        _log(db, dep.id, "INFO", f"🔌 Connecting via WinRM to {dep.target_ip}...")
        with WinRMClient(
            host=dep.target_ip,
            username=dep.target_username,
            password=target_password,
        ) as winrm:
            _log(db, dep.id, "INFO", "✅ WinRM connection established")

            # Step 2: Ensure temp dir
            winrm.run_ps("if (!(Test-Path C:\\Temp)) { New-Item -ItemType Directory C:\\Temp | Out-Null }")
            file_name   = pkg.file_path.replace("\\", "/").split("/")[-1]
            dest_path   = f"C:\\Temp\\{file_name}"
            share_dir   = "\\".join(pkg.file_path.replace("/", "\\").split("\\")[:-1])

            _log(db, dep.id, "INFO", f"📦 Copying package from file server: {pkg.file_path}")
            success, msg = winrm.copy_from_share(
                share_path=pkg.file_path,
                share_username=share_username,
                share_password=share_password,
                destination=dest_path,
            )
            if not success:
                raise RuntimeError(f"File copy failed: {msg}")
            _log(db, dep.id, "INFO", f"✅ Package copied to {dest_path}")

            # Step 3: Install
            extra_args = (dep.extra_options or {}).get("extra_args", "")
            ext = file_name.lower().split(".")[-1]

            _log(db, dep.id, "INFO", f"⚙️  Installing package ({ext}) silently...")
            if ext == "msi":
                success, msg = winrm.install_msi(dest_path, extra_args)
            else:
                success, msg = winrm.install_exe(dest_path, extra_args or "/S /silent /quiet")

            if not success:
                raise RuntimeError(f"Installation failed: {msg}")

            _log(db, dep.id, "INFO", f"✅ Installation complete: {msg}")

            # Cleanup
            winrm.run_ps(f"Remove-Item '{dest_path}' -Force -ErrorAction SilentlyContinue")
            _log(db, dep.id, "INFO", "🧹 Cleaned up temp files")

        _set_status(db, dep, models.DeploymentStatus.success)
        _log(db, dep.id, "INFO", f"🎉 Windows deployment of {pkg.name} completed successfully!")
        return {"status": "success", "deployment_id": deployment_id}

    except Exception as exc:
        logger.exception(f"Windows deployment {deployment_id} failed")
        try:
            _set_status(db, dep, models.DeploymentStatus.failed)
            _log(db, dep.id, "ERROR", f"❌ Deployment failed: {exc}")
        except Exception:
            pass
        return {"status": "failed", "error": str(exc)}
    finally:
        db.close()


# ── Linux Deployment Task ─────────────────────────────────────────────────────

@celery_app.task(bind=True, max_retries=0, name="tasks.deploy_linux")
def deploy_linux(
    self,
    deployment_id: int,
    share_host: str,
    share_username: str,
    share_password_enc: str,
    package_manager_override: Optional[str] = None,
) -> dict:
    """
    Background task: deploy a package to a Linux server via SSH.
    Steps:
      1. SSH connect to target
      2. SCP/SFTP package from shared server (or mount NFS/SMB)
      3. Install via detected package manager
      4. Report result
    """
    db = _get_db()
    try:
        dep = db.query(models.Deployment).get(deployment_id)
        if not dep:
            return {"error": "Deployment record not found"}

        pkg = dep.package
        _set_status(db, dep, models.DeploymentStatus.running)
        _log(db, dep.id, "INFO", f"🚀 Starting Linux deployment of {pkg.name} v{pkg.version} → {dep.target_ip}")

        # Decrypt credentials
        target_password = decrypt_credential(dep.target_password_enc) if dep.target_password_enc else None
        ssh_key         = decrypt_credential(dep.ssh_key_enc) if dep.ssh_key_enc else None
        share_password  = decrypt_credential(share_password_enc)

        file_name    = pkg.file_path.replace("\\", "/").split("/")[-1]
        remote_path  = f"/tmp/{file_name}"

        with SSHClient(
            host=dep.target_ip,
            username=dep.target_username,
            password=target_password,
            ssh_key_content=ssh_key,
        ) as ssh:
            _log(db, dep.id, "INFO", "✅ SSH connection established")

            # Step 1: Detect package manager
            pkg_mgr = package_manager_override or detect_package_manager(ssh)
            _log(db, dep.id, "INFO", f"🔍 Detected package manager: {pkg_mgr}")

            # Step 2: Copy package via SCP from shared server
            _log(db, dep.id, "INFO", f"📦 Fetching package from file server {share_host}...")

            # Strategy: sshpass + scp if share is SSH-based, or smbclient for SMB
            # Adjust the copy strategy based on your environment:
            scp_cmd = (
                f"sshpass -p '{share_password}' scp -o StrictHostKeyChecking=no "
                f"{share_username}@{share_host}:{pkg.file_path} {remote_path} 2>&1"
            )
            exit_code, out, err = ssh.exec(scp_cmd, timeout=300)

            if exit_code != 0:
                # Fallback: try wget/curl if share exposes HTTP
                _log(db, dep.id, "WARNING", f"SCP failed ({err}), trying wget fallback...")
                wget_url = f"http://{share_host}/{pkg.file_path.lstrip('/')}"
                exit_code, out, err = ssh.exec(f"wget -q -O {remote_path} '{wget_url}'", timeout=300)
                if exit_code != 0:
                    raise RuntimeError(f"Could not fetch package: {err}")

            _log(db, dep.id, "INFO", f"✅ Package downloaded to {remote_path}")

            # Step 3: Install
            _log(db, dep.id, "INFO", f"⚙️  Installing with {pkg_mgr}...")
            install_cmd = _build_install_cmd(pkg_mgr, remote_path, file_name)
            exit_code, out, err = ssh.exec_sudo(install_cmd, timeout=300)

            output = out or err
            for line in output.splitlines():
                _log(db, dep.id, "INFO", line)

            if exit_code != 0:
                raise RuntimeError(f"Installation failed (exit {exit_code}): {err}")

            # Cleanup
            ssh.exec(f"rm -f {remote_path}")
            _log(db, dep.id, "INFO", "🧹 Cleaned up temp files")

        _set_status(db, dep, models.DeploymentStatus.success)
        _log(db, dep.id, "INFO", f"🎉 Linux deployment of {pkg.name} completed successfully!")
        return {"status": "success", "deployment_id": deployment_id}

    except Exception as exc:
        logger.exception(f"Linux deployment {deployment_id} failed")
        try:
            _set_status(db, dep, models.DeploymentStatus.failed)
            _log(db, dep.id, "ERROR", f"❌ Deployment failed: {exc}")
        except Exception:
            pass
        return {"status": "failed", "error": str(exc)}
    finally:
        db.close()


def _build_install_cmd(pkg_mgr: str, file_path: str, file_name: str) -> str:
    """Build the appropriate install command for the detected package manager."""
    ext = file_name.lower().split(".")[-1]
    cmds = {
        # DEB-based systems
        "apt-get": f"DEBIAN_FRONTEND=noninteractive apt-get install -y {file_path}" if ext == "deb"
                   else f"DEBIAN_FRONTEND=noninteractive apt-get install -y {file_path}",
        # RPM-based
        "dnf": f"dnf install -y {file_path}",
        "yum": f"yum install -y {file_path}",
        # Others
        "zypper": f"zypper --non-interactive install {file_path}",
        "rpm":    f"rpm -Uvh --nodeps {file_path}",
        "dpkg":   f"dpkg -i {file_path} && apt-get install -f -y",
    }
    # Fallback: run directly (tar.gz, sh installer, etc.)
    fallback = f"chmod +x {file_path} && {file_path} --silent --quiet 2>&1 || bash {file_path}"
    return cmds.get(pkg_mgr, fallback)
