"""
auth.py - JWT authentication, password hashing, and FastAPI dependencies.
Uses HS256 JWT tokens with bcrypt password hashing.
"""

from datetime import datetime, timedelta
from typing import Optional

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from passlib.context import CryptContext
from sqlalchemy.orm import Session

from config import settings
from database import get_db
import models
import schemas

# ── Crypto Setup ──────────────────────────────────────────────────────────────

pwd_context   = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")


# ── Password Utilities ────────────────────────────────────────────────────────

def hash_password(plain: str) -> str:
    return pwd_context.hash(plain)

def verify_password(plain: str, hashed: str) -> bool:
    return pwd_context.verify(plain, hashed)


# ── Token Utilities ───────────────────────────────────────────────────────────

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """Create a signed JWT access token."""
    to_encode = data.copy()
    expire = datetime.utcnow() + (
        expires_delta or timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    to_encode.update({"exp": expire, "iat": datetime.utcnow()})
    return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)


def decode_token(token: str) -> schemas.TokenData:
    """Decode and validate a JWT; raise 401 on failure."""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
        return schemas.TokenData(username=username)
    except JWTError:
        raise credentials_exception


# ── FastAPI Dependencies ──────────────────────────────────────────────────────

def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db),
) -> models.User:
    """Dependency: resolve JWT → User model (raises 401 if invalid)."""
    token_data = decode_token(token)
    user = db.query(models.User).filter(
        models.User.username == token_data.username
    ).first()
    if user is None or not user.is_active:
        raise HTTPException(status_code=401, detail="Inactive or unknown user")
    return user


def require_superuser(current_user: models.User = Depends(get_current_user)) -> models.User:
    """Dependency: require superuser/admin role."""
    if not current_user.is_superuser:
        raise HTTPException(status_code=403, detail="Superuser privileges required")
    return current_user


# ── DB Helpers ────────────────────────────────────────────────────────────────

def authenticate_user(db: Session, username: str, password: str) -> Optional[models.User]:
    """Return User if credentials are valid, else None."""
    user = db.query(models.User).filter(models.User.username == username).first()
    if not user or not verify_password(password, user.hashed_password):
        return None
    return user


def create_initial_admin(db: Session) -> None:
    """Create the default admin user if no users exist yet."""
    if db.query(models.User).count() == 0:
        admin = models.User(
            username="admin",
            email="admin@deploybot.local",
            hashed_password=hash_password("Admin@1234"),  # CHANGE on first login
            is_active=True,
            is_superuser=True,
        )
        db.add(admin)
        db.commit()
        print("✅ Default admin created — username: admin / password: Admin@1234")
        print("⚠️  Please change the password immediately after first login!")
