"""
routers/services.py - Service monitoring and control endpoints.
Supports Windows (WinRM/PowerShell) and Linux (SSH/systemctl).
Credentials are NOT stored — they are used per-request only.
"""

from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from database import get_db
from auth import get_current_user
import models
import schemas
from utils.ssh_client import SSHClient
from utils.winrm_client import WinRMClient

router = APIRouter(prefix="/api/services", tags=["Service Monitoring"])


def _auth_check(payload: schemas.ServiceQueryRequest) -> None:
    """Validate that at least one auth method is provided."""
    if not payload.password and not payload.ssh_key:
        raise HTTPException(
            status_code=400,
            detail="Provide either password or ssh_key"
        )


# ── List Services ─────────────────────────────────────────────────────────────

@router.post("/list", response_model=schemas.ServiceListResponse)
def list_services(
    payload: schemas.ServiceQueryRequest,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    """
    Fetch all services from the target server.
    Credentials are used in-memory only — never stored.
    """
    _auth_check(payload)

    try:
        if payload.os_type == schemas.OSType.windows:
            with WinRMClient(
                host=payload.server_ip,
                username=payload.username,
                password=payload.password,
            ) as winrm:
                raw_services = winrm.list_services()

        else:  # Linux
            with SSHClient(
                host=payload.server_ip,
                username=payload.username,
                password=payload.password,
                ssh_key_content=payload.ssh_key,
            ) as ssh:
                raw_services = ssh.list_services()

        services = [schemas.ServiceInfo(**s) for s in raw_services]

        # Audit log
        _audit(db, payload, action="list", success=True, result={"count": len(services)},
               user_id=current_user.id)

        return schemas.ServiceListResponse(
            server_ip=payload.server_ip,
            os_type=payload.os_type,
            services=services,
            fetched_at=datetime.utcnow(),
        )

    except Exception as exc:
        _audit(db, payload, action="list", success=False, error=str(exc), user_id=current_user.id)
        raise HTTPException(status_code=500, detail=f"Failed to fetch services: {exc}")


# ── Service Control (Start / Stop / Restart) ──────────────────────────────────

@router.post("/control", response_model=schemas.ServiceActionResponse)
def control_service(
    payload: schemas.ServiceActionRequest,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    """
    Perform start / stop / restart on a specific service.
    Returns new service status after action.
    """
    _auth_check(payload)

    try:
        if payload.os_type == schemas.OSType.windows:
            with WinRMClient(
                host=payload.server_ip,
                username=payload.username,
                password=payload.password,
            ) as winrm:
                success, message = winrm.control_service(payload.service_name, payload.action)
                new_status = winrm.get_service_status(payload.service_name) if success else None

        else:  # Linux
            with SSHClient(
                host=payload.server_ip,
                username=payload.username,
                password=payload.password,
                ssh_key_content=payload.ssh_key,
            ) as ssh:
                success, message = ssh.control_service(payload.service_name, payload.action)
                new_status = ssh.get_service_status(payload.service_name) if success else None

        _audit(
            db, payload, action=payload.action, success=success,
            service_name=payload.service_name,
            result={"message": message, "new_status": new_status},
            error=None if success else message,
            user_id=current_user.id,
        )

        if not success:
            raise HTTPException(status_code=500, detail=message)

        return schemas.ServiceActionResponse(
            server_ip=payload.server_ip,
            service_name=payload.service_name,
            action=payload.action,
            success=True,
            message=message,
            new_status=new_status,
        )

    except HTTPException:
        raise
    except Exception as exc:
        _audit(db, payload, action=payload.action, success=False,
               service_name=getattr(payload, "service_name", ""),
               error=str(exc), user_id=current_user.id)
        raise HTTPException(status_code=500, detail=f"Service action failed: {exc}")


# ── Helpers ───────────────────────────────────────────────────────────────────

def _audit(
    db: Session,
    payload: schemas.ServiceQueryRequest,
    action: str,
    success: bool,
    result: dict = None,
    error: str = None,
    service_name: str = None,
    user_id: int = None,
) -> None:
    """Write a service check audit record (fire-and-forget)."""
    try:
        entry = models.ServiceCheck(
            server_ip=payload.server_ip,
            os_type=payload.os_type,
            username=payload.username,
            action=action,
            service_name=service_name,
            result=result,
            success=success,
            error_msg=error,
            performed_by=user_id,
        )
        db.add(entry)
        db.commit()
    except Exception:
        pass  # Never let audit failure break the main flow
