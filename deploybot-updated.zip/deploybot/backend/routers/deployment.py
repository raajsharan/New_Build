"""
routers/deployment.py - Deployment trigger and status endpoints.
Credentials are encrypted before being stored or passed to Celery.
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from database import get_db
from auth import get_current_user
from utils.encryption import encrypt_credential
from config import settings
import models
import schemas
from tasks.deployment_tasks import celery_app, deploy_windows, deploy_linux

router = APIRouter(prefix="/api/deployments", tags=["Deployments"])


# ── Trigger Deployments ───────────────────────────────────────────────────────

@router.post("/windows", response_model=schemas.DeploymentOut, status_code=202)
def trigger_windows_deployment(
    payload: schemas.WindowsDeployRequest,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    """
    Queue a Windows deployment job.
    Password is encrypted before storage — never stored in plaintext.
    """
    pkg = db.query(models.Package).get(payload.package_id)
    if not pkg:
        raise HTTPException(status_code=404, detail="Package not found")
    if pkg.os_type != models.OSType.windows:
        raise HTTPException(status_code=400, detail="Package is not for Windows")

    # Create DB record with encrypted credential
    dep = models.Deployment(
        package_id=payload.package_id,
        target_ip=payload.target_ip,
        target_username=payload.username,
        target_password_enc=encrypt_credential(payload.password),
        os_type=models.OSType.windows,
        status=models.DeploymentStatus.pending,
        deployed_by=current_user.id,
        extra_options={"extra_args": payload.extra_args or ""},
    )
    db.add(dep)
    db.commit()
    db.refresh(dep)

    # Dispatch Celery task (pass encrypted share password — never plaintext over task args)
    task = deploy_windows.delay(
        deployment_id=dep.id,
        share_username=settings.FILE_SERVER_USERNAME,
        share_password_enc=encrypt_credential(settings.FILE_SERVER_PASSWORD),
    )
    dep.celery_task_id = task.id
    db.commit()
    db.refresh(dep)

    return dep


@router.post("/linux", response_model=schemas.DeploymentOut, status_code=202)
def trigger_linux_deployment(
    payload: schemas.LinuxDeployRequest,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    """
    Queue a Linux deployment job.
    Either password or ssh_key must be provided.
    """
    if not payload.password and not payload.ssh_key:
        raise HTTPException(
            status_code=400,
            detail="Provide either password or ssh_key for authentication"
        )

    pkg = db.query(models.Package).get(payload.package_id)
    if not pkg:
        raise HTTPException(status_code=404, detail="Package not found")
    if pkg.os_type != models.OSType.linux:
        raise HTTPException(status_code=400, detail="Package is not for Linux")

    dep = models.Deployment(
        package_id=payload.package_id,
        target_ip=payload.target_ip,
        target_username=payload.username,
        target_password_enc=encrypt_credential(payload.password) if payload.password else None,
        ssh_key_enc=encrypt_credential(payload.ssh_key) if payload.ssh_key else None,
        os_type=models.OSType.linux,
        status=models.DeploymentStatus.pending,
        deployed_by=current_user.id,
        extra_options={
            "use_sudo": payload.use_sudo,
            "package_manager": payload.package_manager,
        },
    )
    db.add(dep)
    db.commit()
    db.refresh(dep)

    task = deploy_linux.delay(
        deployment_id=dep.id,
        share_host=settings.FILE_SERVER_HOST,
        share_username=settings.FILE_SERVER_USERNAME,
        share_password_enc=encrypt_credential(settings.FILE_SERVER_PASSWORD),
        package_manager_override=payload.package_manager,
    )
    dep.celery_task_id = task.id
    db.commit()
    db.refresh(dep)

    return dep


# ── Status & Logs ─────────────────────────────────────────────────────────────

@router.get("/", response_model=list[schemas.DeploymentOut])
def list_deployments(
    limit: int = 50,
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    """Return the most recent deployments."""
    return (
        db.query(models.Deployment)
        .order_by(models.Deployment.created_at.desc())
        .limit(limit)
        .all()
    )


@router.get("/{deployment_id}", response_model=schemas.DeploymentOut)
def get_deployment(
    deployment_id: int,
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    dep = db.query(models.Deployment).get(deployment_id)
    if not dep:
        raise HTTPException(status_code=404, detail="Deployment not found")
    return dep


@router.get("/{deployment_id}/logs", response_model=list[schemas.DeploymentLogOut])
def get_deployment_logs(
    deployment_id: int,
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    """Return all log entries for a deployment (ordered by timestamp)."""
    dep = db.query(models.Deployment).get(deployment_id)
    if not dep:
        raise HTTPException(status_code=404, detail="Deployment not found")
    return dep.logs


@router.delete("/{deployment_id}/cancel", response_model=schemas.MessageResponse)
def cancel_deployment(
    deployment_id: int,
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    """Cancel a pending deployment (cannot cancel running jobs)."""
    dep = db.query(models.Deployment).get(deployment_id)
    if not dep:
        raise HTTPException(status_code=404, detail="Deployment not found")
    if dep.status not in (models.DeploymentStatus.pending,):
        raise HTTPException(status_code=409, detail=f"Cannot cancel — status is '{dep.status}'")

    # Revoke Celery task
    if dep.celery_task_id:
        celery_app.control.revoke(dep.celery_task_id, terminate=False)

    dep.status = models.DeploymentStatus.cancelled
    db.commit()
    return schemas.MessageResponse(message=f"Deployment #{deployment_id} cancelled")
