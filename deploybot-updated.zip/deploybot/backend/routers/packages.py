"""
routers/packages.py - Package management CRUD endpoints.
"""

from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import or_

from database import get_db
from auth import get_current_user
import models
import schemas

router = APIRouter(prefix="/api/packages", tags=["Packages"])


@router.post("/", response_model=schemas.PackageOut, status_code=201)
def create_package(
    payload: schemas.PackageCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    """Register a new software package."""
    pkg = models.Package(
        name=payload.name,
        version=payload.version,
        file_path=payload.file_path,
        os_type=payload.os_type,
        description=payload.description,
        created_by=current_user.id,
    )
    db.add(pkg)
    db.commit()
    db.refresh(pkg)
    return pkg


@router.get("/", response_model=schemas.PaginatedPackages)
def list_packages(
    search: Optional[str] = Query(None, description="Search by name or description"),
    os_type: Optional[str] = Query(None, description="Filter by OS: windows | linux"),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    """List packages with optional search and OS filter."""
    query = db.query(models.Package)

    if search:
        q = f"%{search}%"
        query = query.filter(
            or_(models.Package.name.ilike(q), models.Package.description.ilike(q))
        )
    if os_type:
        query = query.filter(models.Package.os_type == os_type)

    total  = query.count()
    items  = query.order_by(models.Package.created_at.desc()) \
                  .offset((page - 1) * page_size) \
                  .limit(page_size) \
                  .all()

    return schemas.PaginatedPackages(total=total, items=items, page=page, page_size=page_size)


@router.get("/{package_id}", response_model=schemas.PackageOut)
def get_package(
    package_id: int,
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    pkg = db.query(models.Package).get(package_id)
    if not pkg:
        raise HTTPException(status_code=404, detail="Package not found")
    return pkg


@router.put("/{package_id}", response_model=schemas.PackageOut)
def update_package(
    package_id: int,
    payload: schemas.PackageUpdate,
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    pkg = db.query(models.Package).get(package_id)
    if not pkg:
        raise HTTPException(status_code=404, detail="Package not found")

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(pkg, field, value)

    db.commit()
    db.refresh(pkg)
    return pkg


@router.delete("/{package_id}", response_model=schemas.MessageResponse)
def delete_package(
    package_id: int,
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    pkg = db.query(models.Package).get(package_id)
    if not pkg:
        raise HTTPException(status_code=404, detail="Package not found")

    # Check if package has active deployments
    active = db.query(models.Deployment).filter(
        models.Deployment.package_id == package_id,
        models.Deployment.status.in_(["pending", "running"]),
    ).count()
    if active > 0:
        raise HTTPException(
            status_code=409,
            detail=f"Cannot delete — package has {active} active deployment(s)"
        )

    db.delete(pkg)
    db.commit()
    return schemas.MessageResponse(message=f"Package '{pkg.name}' deleted successfully")
