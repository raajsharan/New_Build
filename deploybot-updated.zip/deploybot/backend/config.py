"""
config.py - Application configuration using Pydantic Settings.
ALLOWED_ORIGINS accepts comma-separated string or JSON array in .env
"""

from pydantic_settings import BaseSettings
from functools import lru_cache
from typing import List


class Settings(BaseSettings):
    # ── Application ──────────────────────────────────────────────────────────
    APP_NAME: str = "DeployBot"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False
    # Accepts plain comma-separated: http://1.2.3.4,https://domain.com
    ALLOWED_ORIGINS: str = "http://localhost:5173,http://localhost:3000"

    # ── Database ─────────────────────────────────────────────────────────────
    DATABASE_URL: str = "postgresql://deploybot:deploybot_pass@localhost:5432/deploybot_db"

    # ── Redis / Celery ────────────────────────────────────────────────────────
    REDIS_URL: str = "redis://localhost:6379/0"
    CELERY_BROKER_URL: str = "redis://localhost:6379/0"
    CELERY_RESULT_BACKEND: str = "redis://localhost:6379/1"

    # ── Authentication ────────────────────────────────────────────────────────
    SECRET_KEY: str = "CHANGE_THIS_TO_A_RANDOM_64_CHAR_SECRET"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 480

    # ── Credential Encryption (Fernet) ────────────────────────────────────────
    ENCRYPTION_KEY: str = "CHANGE_THIS_TO_A_FERNET_KEY"

    # ── Shared File Server ────────────────────────────────────────────────────
    FILE_SERVER_HOST: str = ""
    FILE_SERVER_SHARE: str = ""
    FILE_SERVER_USERNAME: str = ""
    FILE_SERVER_PASSWORD: str = ""

    # ── Logging ───────────────────────────────────────────────────────────────
    LOG_LEVEL: str = "INFO"
    LOG_DIR: str = "./logs"

    def get_allowed_origins(self) -> List[str]:
        """Parse ALLOWED_ORIGINS — accepts comma-separated or JSON array."""
        val = self.ALLOWED_ORIGINS.strip()
        if val.startswith("["):
            import json
            try:
                return json.loads(val)
            except Exception:
                pass
        return [o.strip() for o in val.split(",") if o.strip()]

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True


@lru_cache()
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
